package uz.sanalar.app;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.drawable.Icon;
import android.os.Build;

import org.json.JSONObject;

import java.util.Calendar;

/**
 * Taymer: ilova yopilsa ham ishlaydi. Bildirishnomada tizim o'zi orqaga sanaydi (chronometer),
 * Pauza / Bekor tugmalari bor, vaqt tugaganda budilnik chaladi. Android 16 da holat panelida "jonli" tabletka chiqadi.
 */
final class TimerN {
    static final int ID = 7003;
    static final int CODE = 7773;
    static final String CH = "timer";

    static SharedPreferences sp(Context c) {
        return Store.p(c);
    }

    private static void channel(Context c) {
        if (Build.VERSION.SDK_INT < 26) return;
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        NotificationChannel ch = new NotificationChannel(CH, "Taymer", NotificationManager.IMPORTANCE_DEFAULT);
        ch.setSound(null, null);
        ch.enableVibration(false);
        ch.setShowBadge(false);
        ch.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
        nm.createNotificationChannel(ch);
    }

    private static PendingIntent endPi(Context c) {
        Intent in = new Intent(c, TimerReceiver.class).putExtra("act", "end");
        return PendingIntent.getBroadcast(c, CODE, in, Store.flags());
    }

    private static PendingIntent actPi(Context c, String act, int code) {
        Intent in = new Intent(c, TimerReceiver.class).putExtra("act", act);
        return PendingIntent.getBroadcast(c, code, in, Store.flags());
    }

    private static void cancelAlarm(Context c) {
        try {
            Store.am(c).cancel(endPi(c));
        } catch (Throwable t) {
        }
    }

    private static void setAlarm(Context c, long end) {
        try {
            AlarmManager am = Store.am(c);
            PendingIntent show = PendingIntent.getActivity(c, 3, new Intent(c, MainActivity.class), Store.flags());
            am.setAlarmClock(new AlarmManager.AlarmClockInfo(end, show), endPi(c));
        } catch (Throwable t) {
            try {
                AlarmManager am = Store.am(c);
                Store.setExact(am, end, endPi(c), Store.canExact(am));
            } catch (Throwable t2) {
            }
        }
    }

    /** JS dan: {"run":bool,"end":ms,"left":ms,"dur":ms,"done":bool} */
    static synchronized void sync(Context c, String json) {
        try {
            JSONObject o = new JSONObject(json);
            boolean run = o.optBoolean("run", false), done = o.optBoolean("done", false);
            long end = (long) o.optDouble("end", 0), left = (long) o.optDouble("left", 0), dur = (long) o.optDouble("dur", 0);
            if (run && end > System.currentTimeMillis()) {
                start(c, end, dur);
            } else if (!run && !done && left > 0 && left < dur) {
                pause(c, left, dur, false);
            } else {
                off(c, done ? "done" : "off");
            }
        } catch (Throwable t) {
        }
    }

    static void start(Context c, long end, long dur) {
        sp(c).edit().putString("tm_s", "run").putLong("tm_end", end).putLong("tm_dur", dur).putLong("tm_left", 0).apply();
        cancelAlarm(c);
        setAlarm(c, end);
        post(c);
    }

    static void pause(Context c, long left, long dur, boolean fromNotif) {
        sp(c).edit().putString("tm_s", "pause").putLong("tm_left", left).putLong("tm_dur", dur).putLong("tm_end", 0).apply();
        cancelAlarm(c);
        post(c);
    }

    static void off(Context c, String state) {
        sp(c).edit().putString("tm_s", state).putLong("tm_end", 0).apply();
        cancelAlarm(c);
        try {
            ((NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE)).cancel(ID);
        } catch (Throwable t) {
        }
    }

    /** Bildirishnoma tugmalari. */
    static synchronized void act(Context c, String act) {
        SharedPreferences p = sp(c);
        String s = p.getString("tm_s", "off");
        long now = System.currentTimeMillis();
        if ("pause".equals(act) && "run".equals(s)) {
            long left = Math.max(1000, p.getLong("tm_end", now) - now);
            pause(c, left, p.getLong("tm_dur", left), true);
        } else if ("resume".equals(act) && "pause".equals(s)) {
            long left = p.getLong("tm_left", 0), dur = p.getLong("tm_dur", left);
            if (left > 0) start(c, now + left, dur);
        } else if ("cancel".equals(act)) {
            off(c, "off");
        } else if ("end".equals(act) && "run".equals(s)) {
            off(c, "done");
            try {
                Calendar x = Calendar.getInstance();
                String t = String.format("%02d:%02d", x.get(Calendar.HOUR_OF_DAY), x.get(Calendar.MINUTE));
                boolean ok = AlarmService.ring(c, null, t, "Taymer tugadi", 0, false);
                if (!ok) Notif.show(c, 7004, "alarm", "Taymer", "Vaqt tugadi");
            } catch (Throwable t) {
            }
        }
    }

    static String state(Context c) {
        SharedPreferences p = sp(c);
        try {
            JSONObject o = new JSONObject();
            String s = p.getString("tm_s", "off");
            long end = p.getLong("tm_end", 0);
            if ("run".equals(s) && end <= System.currentTimeMillis() - 2000) s = "done";
            o.put("s", s).put("end", end).put("left", p.getLong("tm_left", 0)).put("dur", p.getLong("tm_dur", 0));
            return o.toString();
        } catch (Throwable t) {
            return "{\"s\":\"off\"}";
        }
    }

    private static void post(Context c) {
        try {
            if (!Notif.canShow(c, CH)) return;
            channel(c);
            SharedPreferences p = sp(c);
            boolean run = "run".equals(p.getString("tm_s", "off"));
            Notification.Builder b = Notif.builder(c, CH);
            Notif.brand(c, b)
                    .setContentTitle("Taymer")
                    .setContentIntent(PendingIntent.getActivity(c, 4, new Intent(c, MainActivity.class), Store.flags()))
                    .setOngoing(true)
                    .setOnlyAlertOnce(true)
                    .setColor(Notif.COLOR)
                    .setCategory(Notification.CATEGORY_PROGRESS)
                    .setVisibility(Notification.VISIBILITY_PUBLIC);
            if (Build.VERSION.SDK_INT < 26) b.setPriority(Notification.PRIORITY_LOW);
            Icon ic = Icon.createWithResource(c, R.drawable.ic_stat);
            if (run) {
                long end = p.getLong("tm_end", 0);
                b.setWhen(end).setShowWhen(true).setUsesChronometer(true);
                if (Build.VERSION.SDK_INT >= 24) b.setChronometerCountDown(true);
                b.setContentText("Ishlamoqda");
                b.addAction(new Notification.Action.Builder(ic, "Pauza", actPi(c, "pause", 1)).build());
            } else {
                long left = p.getLong("tm_left", 0);
                b.setShowWhen(false).setContentText("Pauza: " + fmt(left));
                b.addAction(new Notification.Action.Builder(ic, "Davom", actPi(c, "resume", 2)).build());
            }
            b.addAction(new Notification.Action.Builder(ic, "Bekor", actPi(c, "cancel", 3)).build());
            // Android 16: holat panelida jonli tabletka (ruxsat/qurilma qo'llamasa e'tiborsiz qoladi)
            if (Build.VERSION.SDK_INT >= 36) {
                try {
                    Notification.Builder.class.getMethod("setRequestPromotedOngoing", boolean.class).invoke(b, true);
                } catch (Throwable t) {
                }
                try {
                    if (!run) Notification.Builder.class.getMethod("setShortCriticalText", CharSequence.class).invoke(b, fmt(p.getLong("tm_left", 0)));
                } catch (Throwable t) {
                }
            }
            ((NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE)).notify(ID, b.build());
        } catch (Throwable t) {
        }
    }

    private static String fmt(long ms) {
        long t = (ms + 999) / 1000, h = t / 3600, m = t % 3600 / 60, s = t % 60;
        return (h > 0 ? h + ":" + String.format("%02d", m) : String.format("%02d", m)) + ":" + String.format("%02d", s);
    }

    /** Telefon qayta yoqilganda: ishlayotgan taymer tiklanadi. */
    static void restore(Context c) {
        try {
            SharedPreferences p = sp(c);
            if ("run".equals(p.getString("tm_s", "off"))) {
                long end = p.getLong("tm_end", 0);
                if (end > System.currentTimeMillis()) start(c, end, p.getLong("tm_dur", 0));
                else act(c, "end");
            } else if ("pause".equals(p.getString("tm_s", "off"))) post(c);
        } catch (Throwable t) {
        }
    }
}
