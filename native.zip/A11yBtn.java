package uz.sanalar.app;

import android.content.ComponentName;
import android.content.ContentResolver;
import android.content.Context;
import android.content.pm.PackageManager;
import android.provider.Settings;

/**
 * Tizimning "Maxsus imkoniyatlar" yordamchi (suzuvchi) tugmasini / tezkor yorliqni bu xizmat uchun olib tashlaydi.
 * Faqat shu xizmat ro'yxatlardan olib tashlanadi (boshqa xizmatlar tegilmaydi). WRITE_SECURE_SETTINGS berilgan bo'lsa ishlaydi.
 */
final class A11yBtn {
    private static final String[] KEYS = {
            "accessibility_button_targets",          // suzuvchi tugma / navigatsiya tugmasi
            "accessibility_shortcut_target_service", // ovoz tugmalari yorlig'i
            "accessibility_qs_targets"               // tezkor sozlamalar plitkasi
    };
    private static long last = 0;

    static void hide(Context c) {
        try {
            long now = System.currentTimeMillis();
            if (now - last < 20000) return;
            last = now;
            if (c.checkCallingOrSelfPermission("android.permission.WRITE_SECURE_SETTINGS") != PackageManager.PERMISSION_GRANTED) return;
            ContentResolver cr = c.getContentResolver();
            ComponentName me = new ComponentName(c, BlkService.class);
            String full = me.flattenToString(), shrt = me.flattenToShortString();
            for (String k : KEYS) {
                String v = Settings.Secure.getString(cr, k);
                if (v == null || v.length() == 0) continue;
                StringBuilder sb = new StringBuilder();
                boolean ch = false;
                for (String p : v.split(":")) {
                    if (p.length() == 0) continue;
                    if (p.equals(full) || p.equals(shrt)) {
                        ch = true;
                        continue;
                    }
                    if (sb.length() > 0) sb.append(':');
                    sb.append(p);
                }
                if (ch) Settings.Secure.putString(cr, k, sb.toString());
            }
        } catch (Throwable t) {
        }
    }
}
