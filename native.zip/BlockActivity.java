package uz.sanalar.app;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.json.JSONObject;

/** Bloklangan ilova ustidan chiqadigan oyna. */
public class BlockActivity extends Activity {
    static volatile boolean UP = false;

    @Override
    protected void onResume() {
        super.onResume();
        UP = true;
    }

    @Override
    protected void onPause() {
        UP = false;
        super.onPause();
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        String t = "Bu ilova bloklangan", sub = "Hozir bu ilovadan foydalana olmaysiz", btn = "Bosh ekranga";
        try {
            JSONObject o = new JSONObject(Blk.p(this).getString("blk_txt", "{}"));
            t = o.optString("t", t);
            sub = o.optString("s", sub);
            btn = o.optString("b", btn);
        } catch (Exception e) {
        }
        boolean lim = getIntent().getBooleanExtra("lim", false);
        if (lim) {
            t = "Kunlik limit tugadi";
            try {
                t = new JSONObject(Blk.p(this).getString("blk_txt", "{}")).optString("lt", t);
            } catch (Exception e) {
            }
        }
        boolean nsfw = getIntent().getBooleanExtra("nsfw", false);
        if (nsfw) {
            t = "Nomaqbul kontent to'xtatildi";
            sub = "Filtr bu qidiruv yoki sahifani yopdi";
            try {
                JSONObject o = new JSONObject(Blk.p(this).getString("blk_txt", "{}"));
                t = o.optString("nt", t);
                sub = o.optString("ns", sub);
            } catch (Exception e) {
            }
        }
        long until = getIntent().getLongExtra("until", 0);
        if (until > 0 && until != Long.MAX_VALUE) {
            long m = Math.max(1, (until - System.currentTimeMillis() + 59999) / 60000);
            sub = m >= 60 ? "Yana " + (m / 60) + " soat " + (m % 60) + " daqiqa bloklangan" : "Yana " + m + " daqiqa bloklangan";
        } else if (until == Long.MAX_VALUE) {
            sub = "Bu ilova butunlay bloklangan";
        }
        String site = getIntent().getStringExtra("site");
        if (site != null) t = "Bu sayt bloklangan";
        String name = site == null ? "" : site;
        try {
            String pk = getIntent().getStringExtra("pkg");
            if (pk == null) throw new Exception();
            PackageManager pm = getPackageManager();
            name = pm.getApplicationInfo(pk, 0).loadLabel(pm).toString();
        } catch (Exception e) {
        }
        float d = getResources().getDisplayMetrics().density;
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setPadding((int) (28 * d), (int) (28 * d), (int) (28 * d), (int) (28 * d));
        root.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{Color.parseColor("#0a1622"), Color.parseColor("#12392f")}));
        TextView ic = new TextView(this);
        ic.setText("⛔");
        ic.setTextSize(54);
        ic.setGravity(Gravity.CENTER);
        TextView tt = new TextView(this);
        tt.setText(t);
        tt.setTextColor(Color.WHITE);
        tt.setTextSize(24);
        tt.setTypeface(Typeface.DEFAULT_BOLD);
        tt.setGravity(Gravity.CENTER);
        tt.setPadding(0, (int) (14 * d), 0, (int) (6 * d));
        TextView nm = new TextView(this);
        nm.setText(name);
        nm.setTextColor(Color.parseColor("#7fd6a8"));
        nm.setTextSize(18);
        nm.setGravity(Gravity.CENTER);
        TextView sb = new TextView(this);
        sb.setText(sub);
        sb.setTextColor(Color.parseColor("#b8c7d4"));
        sb.setTextSize(15);
        sb.setGravity(Gravity.CENTER);
        sb.setPadding(0, (int) (8 * d), 0, (int) (28 * d));
        Button bt = new Button(this);
        bt.setText(btn);
        bt.setAllCaps(false);
        bt.setTextColor(Color.WHITE);
        GradientDrawable g = new GradientDrawable();
        g.setColor(Color.parseColor("#1f8a5b"));
        g.setCornerRadius(28 * d);
        bt.setBackground(g);
        bt.setPadding((int) (36 * d), (int) (12 * d), (int) (36 * d), (int) (12 * d));
        bt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                home();
            }
        });
        root.addView(ic);
        root.addView(tt);
        root.addView(nm);
        root.addView(sb);
        root.addView(bt);
        setContentView(root);
    }

    private void home() {
        Intent h = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(h);
        finish();
    }

    @Override
    public void onBackPressed() {
        home();
    }

    @Override
    protected void onNewIntent(Intent i) {
        super.onNewIntent(i);
        setIntent(i);
        recreate();
    }
}
