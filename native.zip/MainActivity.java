package uz.sanalar.app;

import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;

import com.getcapacitor.BridgeActivity;

import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

public class MainActivity extends BridgeActivity {
    static final int RQ_SOUND = 4711;
    static final int RQ_VPN = 4712;
    /** Ilova "Home" tugmasi orqali ochildimi (launcher rejimi) */
    static boolean HOME = false;

    static boolean isHomeIntent(Intent i) {
        return i != null && Intent.ACTION_MAIN.equals(i.getAction()) && i.hasCategory(Intent.CATEGORY_HOME);
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        overridePendingTransition(0, 0);
        if (isHomeIntent(intent)) {
            HOME = true;
            try {
                getBridge().getWebView().evaluateJavascript("try{window.hmHome&&hmHome()}catch(e){}", null);
            } catch (Throwable t) {
            }
        }
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        final android.content.SharedPreferences cp = getSharedPreferences("crashlog", MODE_PRIVATE);
        final Thread.UncaughtExceptionHandler old = Thread.getDefaultUncaughtExceptionHandler();
        Thread.setDefaultUncaughtExceptionHandler(new Thread.UncaughtExceptionHandler() {
            @Override
            public void uncaughtException(Thread t, Throwable e) {
                try {
                    java.io.StringWriter sw = new java.io.StringWriter();
                    e.printStackTrace(new java.io.PrintWriter(sw));
                    String x = sw.toString();
                    cp.edit().putString("last", x.length() > 3000 ? x.substring(0, 3000) : x).commit();
                } catch (Throwable z) {
                }
                if (old != null) old.uncaughtException(t, e);
            }
        });
        super.onCreate(savedInstanceState);
        HOME = isHomeIntent(getIntent());
        try {
            final String last = cp.getString("last", null);
            if (last != null) {
                cp.edit().remove("last").apply();
                new android.app.AlertDialog.Builder(this).setTitle("Xato (skrinshot oling)").setMessage(last).setPositiveButton("OK", null).show();
            }
        } catch (Throwable e) {
        }
        /* orqaga tugmasi: avval ilova ichidagi eng yuqori qatlamni yopadi, faqat bosh ekranda chiqadi */
        getOnBackPressedDispatcher().addCallback(this, new androidx.activity.OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                try {
                    getBridge().getWebView().evaluateJavascript(
                            "(function(){try{return window.nativeBack?window.nativeBack():'exit';}catch(e){return 'exit';}})()",
                            new android.webkit.ValueCallback<String>() {
                                @Override
                                public void onReceiveValue(String v) {
                                    if (v != null && v.contains("exit")) finish();
                                }
                            });
                } catch (Throwable t) {
                    finish();
                }
            }
        });
        Notif.channels(this);
        try {
            getWindow().setWindowAnimations(R.style.LauncherNoAnim); // Home bosilganda qalqib chiqish animatsiyasi yo'q
        } catch (Throwable t) {
        }
        try {
            // Gorizontal holatda kamera chuqurchasi tomonidagi "ajralgan" yo'l yo'qoladi: oyna butun ekranni egallaydi
            if (android.os.Build.VERSION.SDK_INT >= 28) {
                android.view.WindowManager.LayoutParams lp = getWindow().getAttributes();
                lp.layoutInDisplayCutoutMode = android.view.WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
                getWindow().setAttributes(lp);
            }
        } catch (Throwable t) {
        }
        // Bildirishnoma ruxsati endi ilk ochilishda o'zi so'ralmaydi: tartib Google kirish -> ruxsatlar oynasi -> parol (ruxsatlar oynasi so'raydi)
        api = new NativeApi(this);
        getBridge().getWebView().addJavascriptInterface(api, "AndroidAlarm");
        lkRegister();
        Store.scheduleAlarms(this);
        Store.scheduleNotifs(this);
    }

    @Override
    public void onResume() {
        super.onResume();
        lkSync();
        // sayt filtri yoqilgan va VPN ruxsati berilgan bo'lsa, VPN (DNS filtr) to'xtab qolgan bo'lsa qayta ishga tushadi
        try {
            Blk.purgeOld(this);
        } catch (Throwable t) {
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == GAuth.REQ) {
            GAuth.onResult(this, resultCode, data);
            return;
        }
        if (requestCode == RQ_VPN) {
            if (resultCode == RESULT_OK) {
                SiteBlk.setVpn(this, true);
                SiteBlk.setNoVpn(this, true);
                SiteBlk.setOn(this, true);
                SiteVpn.start(this);
            }
            try {
                getBridge().getWebView().evaluateJavascript("try{window.sbRefresh&&sbRefresh()}catch(e){}", null);
            } catch (Throwable t) {
            }
            return;
        }
        if (requestCode == RQ_SOUND) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null) {
                importSound(data.getData());
            }
            return;
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    /** Tanlangan musiqani ilova xotirasiga ko'chiradi (ruxsat yo'qolsa ham ishlashi uchun). */
    private void importSound(final Uri u) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                String name = "Musiqa";
                Cursor c = null;
                try {
                    c = getContentResolver().query(u, null, null, null, null);
                    if (c != null && c.moveToFirst()) {
                        int i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                        if (i >= 0 && c.getString(i) != null) name = c.getString(i);
                    }
                } catch (Exception e) {
                } finally {
                    if (c != null) c.close();
                }
                boolean ok = false;
                File tmp = new File(getFilesDir(), "alarm_sound.tmp");
                InputStream in = null;
                FileOutputStream out = null;
                try {
                    in = getContentResolver().openInputStream(u);
                    out = new FileOutputStream(tmp);
                    byte[] b = new byte[65536];
                    int n;
                    long tot = 0;
                    while (in != null && (n = in.read(b)) > 0) {
                        out.write(b, 0, n);
                        tot += n;
                        if (tot > 40L * 1024 * 1024) throw new IOException("juda katta");
                    }
                    ok = tot > 0;
                } catch (Exception e) {
                    ok = false;
                } finally {
                    try {
                        if (in != null) in.close();
                    } catch (Exception e) {
                    }
                    try {
                        if (out != null) out.close();
                    } catch (Exception e) {
                    }
                }
                if (ok) {
                    File f = Store.sndFile(MainActivity.this);
                    f.delete();
                    ok = tmp.renameTo(f);
                    if (ok) Store.p(MainActivity.this).edit().putString(Store.SNDN, name).apply();
                } else {
                    tmp.delete();
                }
                final String js = "window.onSoundPicked&&onSoundPicked(" + JSONObject.quote(name) + "," + (ok ? "true" : "false") + ")";
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            getBridge().getWebView().evaluateJavascript(js, null);
                        } catch (Exception e) {
                        }
                    }
                });
            }
        }).start();
    }

    /* ---------- Qulf ekrani ustida timeline (Madeena asosiy ekran bo'lganda) ---------- */
    private NativeApi api;
    private boolean lkVis = false;
    private long lkStopAt = 0;
    private android.content.BroadcastReceiver lkRcv;

    @Override
    public void onStart() {
        super.onStart();
        lkVis = true;
    }

    @Override
    public void onPause() {
        try {
            getBridge().getWebView().evaluateJavascript("try{window.vaultFlush&&window.vaultFlush()}catch(e){}", null);
        } catch (Throwable t) {
        }
        super.onPause();
    }

    @Override
    public void onStop() {
        super.onStop();
        lkVis = false;
        lkStopAt = System.currentTimeMillis();
    }

    @Override
    public void onDestroy() {
        try {
            if (lkRcv != null) unregisterReceiver(lkRcv);
        } catch (Throwable t) {
        }
        super.onDestroy();
    }

    /** Oyna qulf ekrani ustida ko'rinishini yoqadi/o'chiradi */
    void lkWin(final boolean on) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                try {
                    if (android.os.Build.VERSION.SDK_INT >= 27) {
                        setShowWhenLocked(on);
                    } else if (on) {
                        getWindow().addFlags(android.view.WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED);
                    } else {
                        getWindow().clearFlags(android.view.WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED);
                    }
                } catch (Throwable t) {
                }
            }
        });
    }

    /** Telefon hozir qulfli (qulf ekrani ko'rinib turibdi)mi */
    private boolean lkLocked() {
        try {
            android.app.KeyguardManager km = (android.app.KeyguardManager) getSystemService(android.content.Context.KEYGUARD_SERVICE);
            return km != null && km.isKeyguardLocked();
        } catch (Throwable t) {
            return false;
        }
    }

    /** Sahifaga qulf holatini bildiradi. Sahifa tayyor va Madeena asosiy ekran bo'lsagina oyna qulf ustida ko'rinadi. */
    void lkSync() {
        lkSync(lkLocked());
    }

    void lkSync(boolean locked) {
        try {
            if (api == null || !api.homeDefault()) {
                lkWin(false);
                return;
            }
            getBridge().getWebView().evaluateJavascript(
                    "(function(){try{return window.lkSync?window.lkSync(" + (locked ? "true" : "false") + "):'0';}catch(e){return '0';}})()",
                    new android.webkit.ValueCallback<String>() {
                        @Override
                        public void onReceiveValue(String v) {
                            lkWin(v != null && v.contains("1"));
                        }
                    });
        } catch (Throwable t) {
        }
    }

    /** Telefon qulfdan chiqdi: oddiy holatga qaytadi (oyna bayrog'i o'zgarmaydi) */
    void lkUnlocked() {
        try {
            getBridge().getWebView().evaluateJavascript("try{window.lkSync&&lkSync(false)}catch(e){}", null);
        } catch (Throwable t) {
        }
    }

    /** Ekran o'chganda: sahifani qulf rejimiga o'tkazadi */
    private void lkOff() {
        try {
            if (!(lkVis || System.currentTimeMillis() - lkStopAt < 1500)) return;
            lkSync(true);
        } catch (Throwable t) {
        }
    }

    private void lkRegister() {
        try {
            lkRcv = new android.content.BroadcastReceiver() {
                @Override
                public void onReceive(android.content.Context c, Intent i) {
                    String ac = i == null ? null : i.getAction();
                    if (Intent.ACTION_SCREEN_OFF.equals(ac)) lkOff();
                    else if (Intent.ACTION_USER_PRESENT.equals(ac)) lkUnlocked();
                }
            };
            android.content.IntentFilter f = new android.content.IntentFilter();
            f.addAction(Intent.ACTION_SCREEN_OFF);
            f.addAction(Intent.ACTION_USER_PRESENT);
            registerReceiver(lkRcv, f);
        } catch (Throwable t) {
        }
    }
}
