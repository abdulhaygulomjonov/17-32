package uz.sanalar.app;

import android.accessibilityservice.AccessibilityService;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

import android.content.Context;
import android.provider.Settings;
import android.content.pm.ResolveInfo;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.Toast;

import org.json.JSONObject;

import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/** Blok yoqilganda: tanlangan ilovalar ochilsa to'xtatadi; "qattiq rejim" - o'chirish sahifalarini yopadi. */
public class BlkService extends AccessibilityService {
    private long lastBlock = 0, lastGuard = 0, lastTickEl = 0;
    private String limWarn = "";
    /** O'rnatuvchi (installer) oxirgi ochilgan ekrani o'chirish ekranimi (yangilash/o'rnatish emas). */
    private boolean instUninstall = false;
    private String label = "madeena";
    /** Ishlayotgan xizmat nusxasi (ekranni qulflash uchun) */
    static BlkService INST;
    @Override
    public void onConfigurationChanged(android.content.res.Configuration c) {
        super.onConfigurationChanged(c);
    }

    /** 1 - qulflandi, 0 - xizmat yoqilmagan, -1 - Android 9 dan past */
    static int lock() {
        BlkService s = INST;
        if (s == null) return 0;
        if (Build.VERSION.SDK_INT < 28) return -1;
        try {
            return s.performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN) ? 1 : 0;
        } catch (Exception e) {
            return 0;
        }
    }

    /** Tizimning "oxirgi ilovalar" oynasini ochadi: 1 - ochildi, 0 - xizmat yoqilmagan yoki bajarilmadi */
    static int recents() {
        BlkService s = INST;
        if (s == null) return 0;
        try {
            return s.performGlobalAction(GLOBAL_ACTION_RECENTS) ? 1 : 0;
        } catch (Exception e) {
            return 0;
        }
    }

    @Override
    public boolean onUnbind(Intent intent) {
        if (INST == this) INST = null;
        Lim.flush(this);
        dtHide();
        hideBar();
        Sess.gray(this, false);
        return super.onUnbind(intent);
    }

    @Override
    public void onDestroy() {
        if (INST == this) INST = null;
        dtHide();
        hideBar();
        Sess.gray(this, false);
        super.onDestroy();
    }

    @Override
    protected void onServiceConnected() {
        INST = this;
        try {
            label = getApplicationInfo().loadLabel(getPackageManager()).toString().toLowerCase(Locale.ROOT);
        } catch (Exception e) {
        }
        // sayt bloklash yoqilgan bo'lsa, VPN (DNS filtr) to'xtab qolgan bo'lsa qayta ishga tushadi
        try {
            if (SiteBlk.on(this) && SiteBlk.vpn(this) && !SiteVpn.running && android.net.VpnService.prepare(this) == null) SiteVpn.start(this);
        } catch (Throwable t) {
        }
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent e) {
        try {
            if (e == null) return;
            CharSequence pc = e.getPackageName();
            if (pc == null) return;
            String pkg = pc.toString();
            int t = e.getEventType();
            // Madeena o'z ichida klaviatura ochsa (PIN kiritish, so'z qo'shish va h.k.), klaviatura
            // oynasi boshqa ilova sifatida hisoblanib, Madeenaning o'zini bloklab qo'ymasin.
            if (pkg.equals(getPackageName())) {
                selfFg = true;
            } else if (isImeWindow(e)) {
                if (selfFg) return;
            } else {
                selfFg = false;
            }
            if (rcPkg != null && !pkg.equals(getPackageName()) && (t == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED || t == AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED) && rcEvent()) return;
            if (!pkg.equals(getPackageName()) && (Filtr.on(this) || Blk.on(this) || SiteBlk.on(this)) && (menuLong(e, pkg) || iconMenuGuard(e, pkg))) return;
            if (!pkg.equals(getPackageName()) && dtGuard(e, pkg)) return;
            if (!pkg.equals(getPackageName())) vpnHeal();
            if (!pkg.equals(getPackageName()) && vpnGuard(e, pkg, t)) return;
            if (pkg.equals(getPackageName())) {
                // Madeena (launcher) oldiga chiqdi: oldingi ilovadan chiqilgan
                if (t == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
                    CharSequence cn = e.getClassName();
                    if (cn != null && cn.toString().contains("MainActivity")) sxLeave();
                }
                return;
            }
            boolean fx = Focus.active(this), blk = Blk.on(this), sx = Sess.relevant(this), al = Filtr.on(this);
            if (!fx && !blk && !sx && !al) return;
            if (al && t == AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED) {
                alErase(e);
                return;
            }
            if (al && (t == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED || t == AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED || t == AccessibilityEvent.TYPE_VIEW_SCROLLED)) {
                if (!quickWords(e, pkg)) alScreenSoon();
            }
            if (t != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED && t != AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED) return;
            long now = System.currentTimeMillis();
            if (sx && sessGuard(pkg, t, e, now)) return;
            if (!fx && !blk && !al) return;
            if (fx && focusGuard(pkg, t, now)) return;
            if (!blk && !al) return;
            if (blk && Blk.pkgs(this).contains(pkg)) {
                if (now - lastBlock < 900) return;
                lastBlock = now;
                Intent i = new Intent(this, BlockActivity.class).putExtra("pkg", pkg)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NO_ANIMATION);
                startActivity(i);
                return;
            }
            if (isInstaller(pkg)) {
                // Yangilash/o'rnatish oynasini TO'SMAYMIZ; faqat o'chirish ekranini yopamiz.
                if (t == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
                    CharSequence cn = e.getClassName();
                    instUninstall = cn != null && cn.toString().toLowerCase(Locale.ROOT).contains("uninstall");
                }
                if (!instUninstall && !looksUninstall(root(e))) return;
                if (now - lastGuard < 250) return;
                lastGuard = now;
                guard(e);
                return;
            }
            if (isSys(pkg)) {
                if (now - lastGuard < 250) return;
                lastGuard = now;
                if (dateGuard(e)) return;
                if (PermGate.active(this)) return; // Madeena ichidan "Ruxsat berish" bosilgan: shu ruxsat sahifasi vaqtincha ochiq
                guard(e);
            }
        } catch (Throwable ex) {
        }
    }

    /** Oxirgi nodavlat (klaviatura bo'lmagan) old plan oyna Madeenaning o'zi bo'lganmi */
    private boolean selfFg = false;

    /** Berilgan hodisa oynasi klaviatura (IME) ekaniga qaraydi — qaysi ishlab chiqaruvchi klaviaturasi bo'lishidan qat'i nazar. */
    private boolean isImeWindow(AccessibilityEvent e) {
        try {
            int wid = e.getWindowId();
            if (wid < 0) return false;
            java.util.List<android.view.accessibility.AccessibilityWindowInfo> ws = getWindows();
            if (ws == null) return false;
            boolean r = false;
            for (android.view.accessibility.AccessibilityWindowInfo w : ws) {
                if (w == null) continue;
                if (!r && w.getId() == wid && w.getType() == android.view.accessibility.AccessibilityWindowInfo.TYPE_INPUT_METHOD) r = true;
                try {
                    w.recycle();
                } catch (Throwable t2) {
                }
            }
            return r;
        } catch (Throwable t) {
            return false;
        }
    }

    private long lastFocus = 0;

    /** Focus strict mode: true bo'lsa hodisa qayta ishlandi. */
    private boolean focusGuard(String pkg, int t, long now) {
        if (t != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return false;
        if (Focus.mode(this, "apps") && Focus.pkgs(this).contains(pkg)) {
            if (now - lastFocus < 700) return true;
            lastFocus = now;
            startActivity(new Intent(this, BlockActivity.class).putExtra("pkg", pkg)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NO_ANIMATION));
            return true;
        }
        boolean lock = Focus.mode(this, "lock"), exit = Focus.mode(this, "exit");
        if (!lock && !exit) return false;
        if (allowed(pkg)) return false;
        if (!lock && !isHome(pkg)) return false;
        if (now - lastFocus < 500) return true;
        lastFocus = now;
        startActivity(new Intent(this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT
                | Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_NO_ANIMATION));
        return true;
    }

    private boolean allowed(String p) {
        return p.equals("android") || p.startsWith("com.android.systemui") || p.contains("inputmethod") || p.contains("keyboard")
                || p.contains("latin") || p.contains("incallui") || p.contains("dialer") || p.contains("telecom") || p.contains("emergency");
    }

    private boolean isHome(String p) {
        if (p.contains("launcher") || p.contains("recents") || p.contains("home")) return true;
        try {
            android.content.pm.ResolveInfo r = getPackageManager().resolveActivity(new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME), 0);
            return r != null && r.activityInfo != null && p.equals(r.activityInfo.packageName);
        } catch (Exception e) {
            return false;
        }
    }

    private boolean isInstaller(String p) {
        return p.contains("packageinstaller");
    }

    /** Sinfi noma'lum bo'lsa, ekran matnidan "o'chirish" ekranini aniqlaydi. */
    private boolean looksUninstall(AccessibilityNodeInfo n) {
        return scanUn(n, 0, new int[]{0});
    }

    private boolean scanUn(AccessibilityNodeInfo n, int d, int[] cnt) {
        if (n == null || d > 40 || cnt[0] > 600) return false;
        cnt[0]++;
        CharSequence a = n.getText();
        if (a != null) {
            String x = a.toString().toLowerCase(Locale.ROOT);
            if (x.contains("uninstall") || x.contains("удалить") || x.contains("удаление")
                    || x.contains("o'chir") || x.contains("o’chir") || x.contains("o‘chir")
                    || x.contains("kaldır")) return true;
        }
        for (int i = 0; i < n.getChildCount(); i++) {
            AccessibilityNodeInfo c = n.getChild(i);
            if (c != null && scanUn(c, d + 1, cnt)) return true;
        }
        return false;
    }

    /* ---- Bosh ekranda ilova ikonkasi uzoq bosilganda chiqadigan "App info / Uninstall" menyusi ---- */
    private long lastMenuScan = 0;

    private static boolean menuUninstallText(CharSequence a) {
        if (a == null || a.length() > 40) return false;
        String x = a.toString().toLowerCase(Locale.ROOT);
        return x.contains("uninstall") || x.contains("\u0443\u0434\u0430\u043b\u0438\u0442\u044c") || x.contains("o'chir") || x.contains("o\u2019chir")
                || x.contains("o\u2018chir") || x.contains("o\u02BBchir") || x.contains("kald\u0131r");
    }

    private void menuCollect(AccessibilityNodeInfo n, int d, int[] cnt, java.util.ArrayList<AccessibilityNodeInfo> un, java.util.ArrayList<AccessibilityNodeInfo> ic) {
        if (n == null || d > 40 || cnt[0] > 900) return;
        cnt[0]++;
        CharSequence a = n.getText(), b = n.getContentDescription();
        if (menuUninstallText(a) || menuUninstallText(b)) {
            un.add(n);
        } else {
            String x = a != null ? a.toString().toLowerCase(Locale.ROOT) : "";
            String y = b != null ? b.toString().toLowerCase(Locale.ROOT) : "";
            if (label.length() > 0 && (x.contains(label) || y.contains(label))) ic.add(n);
        }
        for (int i = 0; i < n.getChildCount(); i++) menuCollect(n.getChild(i), d + 1, cnt, un, ic);
    }

    private long menuHot = 0;

    /** Bosh ekranda Madeena ikonkasi uzoq bosilsa (menyu chiqishi bilan) darhol "Orqaga" yuboradi, 0.1 va 0.3 soniyada yana. */
    private boolean menuLong(AccessibilityEvent e, String pkg) {
        try {
            if (e.getEventType() != AccessibilityEvent.TYPE_VIEW_LONG_CLICKED || !homeApp(pkg)) return false;
            boolean mine = false;
            String lb = label != null && label.length() > 2 ? label : "madeena";
            CharSequence d = e.getContentDescription();
            if (d != null && d.toString().toLowerCase(Locale.ROOT).contains(lb)) mine = true;
            java.util.List<CharSequence> tl = e.getText();
            if (!mine && tl != null) {
                for (CharSequence c : tl) {
                    if (c != null && c.toString().toLowerCase(Locale.ROOT).contains(lb)) mine = true;
                }
            }
            if (!mine) {
                AccessibilityNodeInfo s = e.getSource();
                if (s != null) {
                    CharSequence a = s.getText(), b = s.getContentDescription();
                    if ((a != null && a.toString().toLowerCase(Locale.ROOT).contains(lb)) || (b != null && b.toString().toLowerCase(Locale.ROOT).contains(lb))) mine = true;
                }
            }
            if (!mine) return false;
            menuHot = System.currentTimeMillis();
            performGlobalAction(GLOBAL_ACTION_BACK);
            android.os.Handler mh = new android.os.Handler(android.os.Looper.getMainLooper());
            Runnable back = new Runnable() {
                @Override
                public void run() {
                    try {
                        performGlobalAction(GLOBAL_ACTION_BACK);
                    } catch (Throwable x) {
                    }
                }
            };
            mh.postDelayed(back, 100);
            mh.postDelayed(back, 300);
            return true;
        } catch (Throwable ex) {
        }
        return false;
    }

    /** Faqat SHU ilovaning ikonkasi uzoq bosilganda menyu (O'chirish) ikonka yonida chiqadi: uni darhol yopamiz.
     *  Menyu va ikonka bir-biriga yopishib turgani bo'yicha shu ilovaniki ekani aniqlanadi (boshqa ilovalar menyusiga tegmaydi). */
    private boolean iconMenuGuard(AccessibilityEvent e, String pkg) {
        try {
            int t = e.getEventType();
            if (t != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED && t != AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED) return false;
            if (!homeApp(pkg)) return false;
            long now = System.currentTimeMillis();
            if (now - lastMenuScan < 120) return false;
            lastMenuScan = now;
            AccessibilityNodeInfo r = root(e);
            if (r == null) return false;
            java.util.ArrayList<AccessibilityNodeInfo> un = new java.util.ArrayList<AccessibilityNodeInfo>();
            java.util.ArrayList<AccessibilityNodeInfo> ic = new java.util.ArrayList<AccessibilityNodeInfo>();
            menuCollect(r, 0, new int[]{0}, un, ic);
            if (un.isEmpty()) return false;
            if (ic.isEmpty()) {
                // menyu alohida oyna bo'lsa, ikonka boshqa oynada turadi: barcha oynalar qidiriladi
                try {
                    java.util.List<android.view.accessibility.AccessibilityWindowInfo> ws = getWindows();
                    if (ws != null) {
                        for (android.view.accessibility.AccessibilityWindowInfo w : ws) {
                            AccessibilityNodeInfo wr = w.getRoot();
                            if (wr != null) menuCollect(wr, 0, new int[]{0}, new java.util.ArrayList<AccessibilityNodeInfo>(), ic);
                        }
                    }
                } catch (Throwable x) {
                }
            }
            if (now - menuHot < 3000) {
                // Madeena ikonkasi hozirgina uzoq bosilgan: chiqqan menyu darhol yopiladi
                lastMenuScan = now - 60;
                performGlobalAction(GLOBAL_ACTION_BACK);
                return true;
            }
            if (ic.isEmpty()) return false;
            int gap = (int) (32 * getResources().getDisplayMetrics().density);
            for (AccessibilityNodeInfo u : un) {
                android.graphics.Rect ub = new android.graphics.Rect();
                u.getBoundsInScreen(ub);
                if (ub.isEmpty()) continue;
                for (AccessibilityNodeInfo i : ic) {
                    android.graphics.Rect ib = new android.graphics.Rect();
                    i.getBoundsInScreen(ib);
                    if (ib.isEmpty()) continue;
                    int vg = ib.top >= ub.bottom ? ib.top - ub.bottom : (ub.top >= ib.bottom ? ub.top - ib.bottom : 0);
                    boolean hx = ib.right > ub.left - gap && ib.left < ub.right + gap;
                    if (vg <= gap && hx) {
                        lastMenuScan = now - 60;
                        performGlobalAction(GLOBAL_ACTION_BACK);
                        return true;
                    }
                }
            }
        } catch (Throwable ex) {
        }
        return false;
    }

    /* ---- "Sana va vaqt" va Maxsus imkoniyatlardagi "Madeena bloklash": Sozlamalarda qatori bosilmaydi (teginish yutiladi), ochilib qolsa darhol yopiladi ---- */
    private final java.util.ArrayList<View> dtViews = new java.util.ArrayList<View>();
    private long dtScanAt = 0;
    private boolean dtPending = false;
    private AccessibilityEvent dtLast = null;

    /** Sozlamalarda ham xuddi "Sana va vaqt" kabi yopiladigan qatorlar: VPN va Private DNS. */
    private static final String[] NB = {"vpn", "private dns", "dns", "xususiy dns", "shaxsiy dns", "vpn va dns", "частный dns", "özel dns", "ozel dns"};

    private static boolean dtTitle(String x) {
        for (String k : DT) if (x.equals(k)) return true;
        for (String k : NB) if (x.equals(k)) return true;
        // Maxsus imkoniyatlar ro'yxatidagi shu ilovaning xizmat qatori ("Madeena bloklash")
        return x.contains("madeena bloklash");
    }

    /** Toolbar sarlavhasida "Madeena bloklash" bo'lsa - xizmat sahifasi ochilgan. */
    private boolean scanTitleSvc(AccessibilityNodeInfo n, int d, int[] cnt) {
        if (n == null || d > 40 || cnt[0] > 600) return false;
        cnt[0]++;
        String id = n.getViewIdResourceName();
        CharSequence tx = n.getText();
        if (id != null && tx != null) {
            String i = id.toLowerCase(Locale.ROOT);
            if ((i.contains("toolbar") || i.contains("action_bar") || i.contains("app_bar")) && tx.toString().toLowerCase(Locale.ROOT).contains("madeena bloklash")) return true;
        }
        for (int i = 0; i < n.getChildCount(); i++) {
            if (scanTitleSvc(n.getChild(i), d + 1, cnt)) return true;
        }
        return false;
    }

    private void dtCollect(AccessibilityNodeInfo n, int d, int[] cnt, java.util.ArrayList<android.graphics.Rect> out, int W, int H) {
        if (n == null || d > 40 || cnt[0] > 900 || out.size() >= 6) return;
        cnt[0]++;
        CharSequence tx = n.getText();
        if (tx != null && tx.length() <= 30 && dtTitle(tx.toString().trim().toLowerCase(Locale.ROOT))) {
            String id = n.getViewIdResourceName();
            String i = id == null ? "" : id.toLowerCase(Locale.ROOT);
            if (!(i.contains("toolbar") || i.contains("action_bar") || i.contains("app_bar") || i.contains("collapsing"))) {
                AccessibilityNodeInfo p = n, row = null;
                for (int g = 0; p != null && g < 5; g++, p = p.getParent()) {
                    if (p.isClickable()) {
                        row = p;
                        break;
                    }
                }
                android.graphics.Rect b = new android.graphics.Rect();
                if (row != null) row.getBoundsInScreen(b);
                if (row == null || b.isEmpty() || b.height() > H * 0.2) {
                    // qator topilmasa: yozuvning o'zi atrofini butun kenglikda yopamiz
                    n.getBoundsInScreen(b);
                    int pad = (int) (16 * getResources().getDisplayMetrics().density);
                    b.left = 0;
                    b.right = W;
                    b.top = b.top - pad;
                    b.bottom = b.bottom + pad;
                }
                if (!b.isEmpty()) out.add(b);
            }
        }
        for (int i = 0; i < n.getChildCount(); i++) dtCollect(n.getChild(i), d + 1, cnt, out, W, H);
    }

    private void dtHide() {
        try {
            for (View v : dtViews) {
                try {
                    if (wm != null) wm.removeView(v);
                } catch (Throwable ex) {
                }
            }
        } catch (Throwable ex) {
        }
        dtViews.clear();
    }

    private void dtApply(java.util.ArrayList<android.graphics.Rect> rs) {
        try {
            if (wm == null) wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
            while (dtViews.size() > rs.size()) {
                View v = dtViews.remove(dtViews.size() - 1);
                try {
                    wm.removeView(v);
                } catch (Throwable ex) {
                }
            }
            for (int i = 0; i < rs.size(); i++) {
                android.graphics.Rect b = rs.get(i);
                if (i < dtViews.size()) {
                    View v = dtViews.get(i);
                    WindowManager.LayoutParams lp = (WindowManager.LayoutParams) v.getLayoutParams();
                    if (lp.x != b.left || lp.y != b.top || lp.width != b.width() || lp.height != b.height()) {
                        lp.x = b.left;
                        lp.y = b.top;
                        lp.width = b.width();
                        lp.height = b.height();
                        wm.updateViewLayout(v, lp);
                    }
                } else {
                    View v = new View(this);
                    v.setClickable(true);
                    v.setOnTouchListener(new View.OnTouchListener() {
                        public boolean onTouch(View a, android.view.MotionEvent m) {
                            return true; // teginish yutiladi: hech qanday reaksiya bo'lmaydi
                        }
                    });
                    v.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
                    WindowManager.LayoutParams lp = new WindowManager.LayoutParams(b.width(), b.height(),
                            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                                    | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                            PixelFormat.TRANSLUCENT);
                    lp.gravity = Gravity.TOP | Gravity.LEFT;
                    lp.x = b.left;
                    lp.y = b.top;
                    wm.addView(v, lp);
                    dtViews.add(v);
                }
            }
        } catch (Throwable ex) {
        }
    }

    private void dtScan() {
        dtPending = false;
        dtScanAt = System.currentTimeMillis();
        try {
            if (!(Filtr.on(this) || Blk.on(this) || Lim.on(this))) {
                dtHide();
                return;
            }
            AccessibilityNodeInfo r = getRootInActiveWindow();
            CharSequence pc = r == null ? null : r.getPackageName();
            if (r == null || pc == null || !pc.toString().contains("settings")) return;
            android.util.DisplayMetrics dm = getResources().getDisplayMetrics();
            java.util.ArrayList<android.graphics.Rect> rs = new java.util.ArrayList<android.graphics.Rect>();
            dtCollect(r, 0, new int[]{0}, rs, dm.widthPixels, dm.heightPixels);
            if (rs.isEmpty()) dtHide();
            else dtApply(rs);
        } catch (Throwable ex) {
        }
    }

    /** true - hodisa shu yerda qayta ishlandi. */
    private boolean dtGuard(AccessibilityEvent e, String pkg) {
        try {
            if (!(Filtr.on(this) || Blk.on(this) || Lim.on(this))) {
                if (!dtViews.isEmpty()) dtHide();
                return false;
            }
            int t = e.getEventType();
            if (!pkg.contains("settings")) {
                // Sozlamalardan chiqildi: yopuvchi qatlam olib tashlanadi (tizim paneli va klaviatura hisobga olinmaydi)
                if (t == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED && !dtViews.isEmpty() && !pkg.startsWith("com.android.systemui")
                        && !pkg.contains("inputmethod") && !pkg.contains("keyboard") && !pkg.contains("latin")) dtHide();
                return false;
            }
            if (t != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED && t != AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED
                    && t != AccessibilityEvent.TYPE_VIEW_SCROLLED) return false;
            // 1) "Sana va vaqt" oynasi ochilib qolgan bo'lsa (qidiruv, boshqa yo'l orqali) - darhol yopamiz
            CharSequence cn = e.getClassName();
            boolean opened = cn != null && (cn.toString().toLowerCase(Locale.ROOT).contains("datetime") || cn.toString().toLowerCase(Locale.ROOT).contains("privatedns") || cn.toString().toLowerCase(Locale.ROOT).contains("vpnsettings"));
            if (!opened && t == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
                AccessibilityNodeInfo rr = root(e);
                opened = scanTitle(rr, 0, new int[]{0}) || scanTitleSvc(rr, 0, new int[]{0});
            }
            if (opened) {
                dtHide();
                performGlobalAction(GLOBAL_ACTION_HOME);
                return true;
            }
            // 2) ro'yxatdagi "Sana va vaqt" qatori ustiga ko'rinmas qatlam qo'yiladi: bosganda hech narsa bo'lmaydi
            long now = System.currentTimeMillis();
            if (now - dtScanAt >= 100) {
                dtScan();
            } else if (!dtPending) {
                dtPending = true;
                new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                    public void run() {
                        dtScan();
                    }
                }, 120);
            }
        } catch (Throwable ex) {
        }
        return false;
    }

    private boolean isSys(String p) {
        return p.contains("settings") || p.contains("permissioncontroller")
                || p.contains("securitycenter") || p.contains("lbe.security") || p.contains("deviceadmin");
    }

    private void guard(AccessibilityEvent e) {
        CharSequence cn = e.getClassName();
        if (cn != null) {
            String c = cn.toString().toLowerCase(Locale.ROOT);
            if (c.contains("deviceadmin") || c.contains("uninstall")) {
                if (hasLabel(root(e))) {
                    performGlobalAction(GLOBAL_ACTION_HOME);
                    return;
                }
            }
        }
        if (hasLabel(root(e))) performGlobalAction(GLOBAL_ACTION_HOME);
    }

    private AccessibilityNodeInfo root(AccessibilityEvent e) {
        AccessibilityNodeInfo r = getRootInActiveWindow();
        if (r == null) r = e.getSource();
        return r;
    }

    private boolean hasLabel(AccessibilityNodeInfo n) {
        int[] cnt = {0};
        return scan(n, 0, cnt);
    }

    private boolean scan(AccessibilityNodeInfo n, int d, int[] cnt) {
        if (n == null || d > 40 || cnt[0] > 600) return false;
        cnt[0]++;
        CharSequence a = n.getText(), b = n.getContentDescription();
        if (a != null && a.toString().toLowerCase(Locale.ROOT).contains(label)) return true;
        if (b != null && b.toString().toLowerCase(Locale.ROOT).contains(label)) return true;
        for (int i = 0; i < n.getChildCount(); i++) {
            AccessibilityNodeInfo c = n.getChild(i);
            if (c != null && scan(c, d + 1, cnt)) return true;
        }
        return false;
    }

    /* ====================== So'z filtri ====================== */
    private String homeP = "";
    private long homeAt = 0;

    /** Klaviaturada sezuvchi so'z yozilsa, o'sha zahoti uni matndan o'chiradi (ilovadan chiqarmaydi). */
    private void alErase(AccessibilityEvent e) {
        try {
            eraseNode(e.getSource());
        } catch (Throwable ex) {
        }
    }

    /** Yozish maydonidagi matndan FAQAT ro'yxatdagi so'zlarni o'chiradi, qolgan matn o'z holicha qoladi
     *  (masalan "sexuality videos" -> "videos"). Nusxa olib qo'yilgan (paste) matnga ham ishlaydi. */
    private void eraseNode(AccessibilityNodeInfo n) {
        try {
            if (n == null || !n.isEditable() || n.isPassword()) return;
            if (Build.VERSION.SDK_INT >= 26 && n.isShowingHintText()) return;
            CharSequence tx = n.getText();
            if (tx == null || tx.length() == 0 || tx.length() > 5000) return;
            Filtr.Res r = Filtr.erase(this, tx.toString());
            if (r == null) return;
            Bundle b = new Bundle();
            b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, r.text);
            n.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b);
            Bundle s = new Bundle();
            s.putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_START_INT, r.pos);
            s.putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_END_INT, r.pos);
            n.performAction(AccessibilityNodeInfo.ACTION_SET_SELECTION, s);
            Filtr.hit(this);
        } catch (Throwable ex) {
        }
    }

    private boolean homeApp(String p) {
        long now = System.currentTimeMillis();
        if (now - homeAt > 30000) {
            homeAt = now;
            try {
                ResolveInfo r = getPackageManager().resolveActivity(new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME), 0);
                homeP = r != null && r.activityInfo != null ? r.activityInfo.packageName : "";
            } catch (Exception e) {
                homeP = "";
            }
        }
        return p.equals(homeP) || p.contains("launcher");
    }

    private boolean nsIgnore(String p) {
        return p.equals("android") || p.startsWith("com.android.systemui") || p.contains("inputmethod") || p.contains("keyboard")
                || p.contains("latin") || p.contains("settings") || p.contains("packageinstaller") || p.contains("permissioncontroller")
                || p.contains("incallui") || p.contains("dialer") || p.contains("telecom") || p.contains("emergency") || homeApp(p);
    }

    /* ---- ekrandagi har qanday matnni sezuvchi so'zlarga tekshirish (brauzer, maqola, sayt, qidiruv natijasi...) ---- */
    private volatile boolean scanPending = false;
    private long lastWordHit = 0, lastScanAt = 0;
    private android.os.HandlerThread wth;
    private Handler wh;

    private synchronized Handler wHandler() {
        if (wh == null) {
            wth = new android.os.HandlerThread("al-words", android.os.Process.THREAD_PRIORITY_URGENT_DISPLAY);
            wth.start();
            wh = new Handler(wth.getLooper());
        }
        return wh;
    }

    /** Sezuvchi so'z topilganda: darhol orqaga qaytaradi va to'sish oynasini ochadi. */
    /** Hozir Madeena o'zi oldinda turibdimi (yozish maydoni Madeena ichida)? Bunda klaviaturaning tavsiya qatoridagi
     *  so'z (masalan \"xxx\") ilovadan chiqarmaydi: aks holda ro'yxatga so'z/sayt qo'shib bo'lmaydi. */
    private boolean ownFront() {
        try {
            AccessibilityNodeInfo r = getRootInActiveWindow();
            if (r == null) return false;
            CharSequence c = r.getPackageName();
            return c != null && c.toString().equals(getPackageName());
        } catch (Throwable t) {
            return false;
        }
    }

    private void wordHit(String pkg) {
        if (ownFront()) return;
        long now = System.currentTimeMillis();
        if (now - lastWordHit < 2000) return;
        lastWordHit = now;
        Filtr.hit(BlkService.this);
        performGlobalAction(GLOBAL_ACTION_HOME);
        startActivity(new Intent(BlkService.this, BlockActivity.class).putExtra("nsfw", true).putExtra("why", "word")
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NO_ANIMATION));
        exitApp(pkg);
    }

    /* ---- nomaqbul kontent topilgan ilova: "Oxirgi ilovalar"dan yo'q qilinadi.
       Sozlamalarga KIRMAYDI va "Majburan to'xtatish" BOSILMAYDI: oxirgi ilovalar oynasi ochilib, ilova kartochkasi tepaga suriladi. ---- */
    private String rcPkg = null;
    private String rcLabel = "";
    private long rcAt = 0;
    private boolean rcBusy = false;

    private void exitApp(final String pkg) {
        try {
            if (pkg == null || pkg.length() == 0 || pkg.equals(getPackageName()) || nsIgnore(pkg)) return;
            if (getPackageManager().getLaunchIntentForPackage(pkg) == null) return;
            String lb = "";
            try {
                lb = getPackageManager().getApplicationLabel(getPackageManager().getApplicationInfo(pkg, 0)).toString();
            } catch (Throwable t) {
            }
            if (lb.trim().length() == 0) return;
            try {
                android.app.ActivityManager am = (android.app.ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
                if (am != null) am.killBackgroundProcesses(pkg);
            } catch (Throwable t) {
            }
            rcPkg = pkg;
            rcLabel = lb.trim().toLowerCase(Locale.ROOT);
            rcBusy = false;
            rcLastRect = null;
            rcWait = 0;
            rcTry = 0;
            rcScr = 0;
            rcUnl = 0;
            rcCount0 = 0;
            rcAt = System.currentTimeMillis();
            final long mark = rcAt;
            Handler h = new Handler(Looper.getMainLooper());
            // zaxira: 12 s ichida kartochka topilmasa bosh ekranga qaytadi
            h.postDelayed(new Runnable() {
                public void run() {
                    if (rcPkg != null && rcAt == mark) {
                        rcPkg = null;
                        rcBusy = false;
                        performGlobalAction(GLOBAL_ACTION_HOME);
                    }
                }
            }, 12000);
            h.postDelayed(new Runnable() {
                public void run() {
                    try {
                        if (rcPkg != null && rcAt == mark) performGlobalAction(GLOBAL_ACTION_RECENTS);
                    } catch (Throwable t) {
                        rcPkg = null;
                    }
                }
            }, 250);
        } catch (Throwable t) {
        }
    }

    private boolean isRecentsPkg(String p) {
        return p != null && (homeApp(p) || p.startsWith("com.android.systemui") || p.contains("launcher") || p.contains("quickstep"));
    }

    /* ---- "Oxirgi ilovalar" oynasida AYNAN kerakli ilova kartochkasini topish va olib tashlash ---- */
    private android.graphics.Rect rcLastRect = null;
    private int rcWait = 0, rcTry = 0, rcCount0 = 0, rcScr = 0, rcUnl = 0;

    private static final class RcPick {
        AccessibilityNodeInfo node, card;
        android.graphics.Rect rect = new android.graphics.Rect();
        int count;
        float vis;
    }

    private static final String[] RC_LOCKED = {"lock", "locked", "qulf", "qulflangan", "mahkam", "mahkamlangan", "pin", "pinned", "заблок", "закреп", "锁", "鎖"};
    private static final String[] RC_UNLOCK = {"unlock", "unpin", "qulfdan", "qulfni ochish", "qulfni olib", "mahkamlashni", "разблок", "снять", "откреп", "解锁", "取消锁定"};

    private boolean rcMatch(CharSequence s) {
        if (s == null || rcLabel.length() == 0) return false;
        String x = s.toString().trim().toLowerCase(Locale.ROOT);
        return x.equals(rcLabel) || x.startsWith(rcLabel + ",") || x.startsWith(rcLabel + "\n");
    }

    /** Ilova nomiga aynan mos kelgan barcha tugunlar. */
    private void rcCollect(AccessibilityNodeInfo n, int d, int[] cnt, java.util.ArrayList<AccessibilityNodeInfo> out) {
        if (n == null || d > 40 || cnt[0] > 1200) return;
        cnt[0]++;
        if (rcMatch(n.getText()) || rcMatch(n.getContentDescription())) out.add(n);
        for (int i = 0; i < n.getChildCount(); i++) rcCollect(n.getChild(i), d + 1, cnt, out);
    }

    /** Kartochka konteyneri: nomdan yuqoriga qarab birinchi "kartochka o'lchamli" tugun (butun ro'yxat emas, faqat shu kartochka). */
    private AccessibilityNodeInfo rcCardOf(AccessibilityNodeInfo n, int W, int H) {
        AccessibilityNodeInfo p = n;
        for (int g = 0; p != null && g < 8; g++, p = p.getParent()) {
            android.graphics.Rect b = new android.graphics.Rect();
            p.getBoundsInScreen(b);
            if (b.height() >= H / 4 && b.width() >= W / 4 && b.width() < W * 0.95) return p;
        }
        return null;
    }

    /** Kerakli ilova kartochkasi. Bir nechta mos kelsa, ekran markaziga eng yaqin va ko'rinib turgani tanlanadi
     *  (ilova hozirgina yopilgani uchun u eng oxirgi, ya'ni markazdagi kartochka bo'ladi). */
    private RcPick rcPick(AccessibilityNodeInfo root) {
        android.util.DisplayMetrics dm = getResources().getDisplayMetrics();
        int W = dm.widthPixels, H = dm.heightPixels;
        java.util.ArrayList<AccessibilityNodeInfo> hits = new java.util.ArrayList<AccessibilityNodeInfo>();
        rcCollect(root, 0, new int[]{0}, hits);
        java.util.ArrayList<android.graphics.Rect> seen = new java.util.ArrayList<android.graphics.Rect>();
        RcPick best = null;
        double bestScore = Double.MAX_VALUE;
        for (AccessibilityNodeInfo n : hits) {
            AccessibilityNodeInfo card = rcCardOf(n, W, H);
            android.graphics.Rect rc = new android.graphics.Rect();
            (card != null ? card : n).getBoundsInScreen(rc);
            boolean dup = false;
            for (android.graphics.Rect s : seen) if (s.equals(rc)) {
                dup = true;
                break;
            }
            if (dup) continue;
            seen.add(rc);
            long area = (long) Math.max(1, rc.width()) * Math.max(1, rc.height());
            android.graphics.Rect vr = new android.graphics.Rect(rc);
            float v = vr.intersect(0, 0, W, H) ? (float) ((double) ((long) vr.width() * vr.height()) / area) : 0f;
            double score = Math.abs(rc.centerX() - W / 2.0) + (v < 0.3f ? 2.0 * W : 0);
            if (score < bestScore) {
                bestScore = score;
                best = new RcPick();
                best.node = n;
                best.card = card;
                best.rect = rc;
                best.vis = v;
            }
        }
        if (best != null) best.count = seen.size();
        return best;
    }

    /** Oxirgi ilovalar oynasi ochilganda chaqiriladi. true - hodisa shu uchun ishlatildi. */
    private boolean rcEvent() {
        try {
            if (rcPkg == null) return false;
            if (System.currentTimeMillis() - rcAt > 12000) {
                rcPkg = null;
                rcBusy = false;
                performGlobalAction(GLOBAL_ACTION_HOME);
                return false;
            }
            if (rcBusy) return true;
            AccessibilityNodeInfo r = getRootInActiveWindow();
            if (r == null) return false;
            CharSequence rp = r.getPackageName();
            if (!isRecentsPkg(rp == null ? "" : rp.toString())) return false;
            if (rcPick(r) == null) return true;
            rcBusy = true;
            rcLastRect = null;
            rcWait = 0;
            rcTry = 0;
            rcScr = 0;
            rcUnl = 0;
            rcCount0 = 0;
            // oyna animatsiyasi tugashini kutamiz, so'ng kartochkani yopamiz
            new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                public void run() {
                    rcAct();
                }
            }, 300);
            return true;
        } catch (Throwable t) {
        }
        return false;
    }

    private void rcLater(long ms) {
        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
            public void run() {
                rcAct();
            }
        }, ms);
    }

    private void rcGesture(int x1, int y1, int x2, int y2, long dur, final Runnable after) {
        try {
            if (Build.VERSION.SDK_INT < 24) {
                after.run();
                return;
            }
            android.graphics.Path path = new android.graphics.Path();
            path.moveTo(x1, y1);
            path.lineTo(x2, y2);
            android.accessibilityservice.GestureDescription.Builder gb = new android.accessibilityservice.GestureDescription.Builder();
            gb.addStroke(new android.accessibilityservice.GestureDescription.StrokeDescription(path, 0, dur));
            boolean ok = dispatchGesture(gb.build(), new GestureResultCallback() {
                @Override
                public void onCompleted(android.accessibilityservice.GestureDescription g) {
                    after.run();
                }

                @Override
                public void onCancelled(android.accessibilityservice.GestureDescription g) {
                    after.run();
                }
            }, null);
            if (!ok) after.run();
        } catch (Throwable t) {
            after.run();
        }
    }

    /** w so'zi x ichida alohida so'z sifatida bormi (xitoy yozuvi uchun oddiy qidiruv). */
    private static boolean rcHasWord(String x, String w) {
        if (w.length() > 0 && w.charAt(0) > 0x2E80) return x.contains(w);
        int from = 0;
        while (true) {
            int i = x.indexOf(w, from);
            if (i < 0) return false;
            boolean l = i == 0 || !Character.isLetterOrDigit(x.charAt(i - 1));
            int e = i + w.length();
            boolean r = e >= x.length() || !Character.isLetterOrDigit(x.charAt(e));
            if (l && r) return true;
            from = i + 1;
        }
    }

    private AccessibilityNodeInfo rcFindWords(AccessibilityNodeInfo n, String[] ws, int d, int[] cnt) {
        if (n == null || d > 40 || cnt[0] > 1200) return null;
        cnt[0]++;
        CharSequence a = n.getText(), b = n.getContentDescription();
        for (int k = 0; k < 2; k++) {
            CharSequence s = k == 0 ? a : b;
            if (s == null) continue;
            String x = s.toString().toLowerCase(Locale.ROOT);
            if (x.length() > 60) continue;
            if (rcLabel.length() > 0 && x.contains(rcLabel)) continue; // ilovaning o'z nomi (masalan "Clock") qulf deb o'ylanmasin
            for (String w : ws) if (rcHasWord(x, w)) return n;
        }
        for (int i = 0; i < n.getChildCount(); i++) {
            AccessibilityNodeInfo f = rcFindWords(n.getChild(i), ws, d + 1, cnt);
            if (f != null) return f;
        }
        return null;
    }

    /** Faqat kichik tugmani bosadi (kartochkaning o'zini bosib, ilovani ochib yubormaslik uchun). */
    private boolean rcClickSmall(AccessibilityNodeInfo n) {
        try {
            android.util.DisplayMetrics dm = getResources().getDisplayMetrics();
            android.graphics.Rect b = new android.graphics.Rect();
            n.getBoundsInScreen(b);
            if (b.isEmpty() || b.width() > dm.widthPixels / 3 || b.height() > dm.heightPixels / 6) return false;
            if (n.isClickable() && n.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true;
            AccessibilityNodeInfo p = n.getParent();
            if (p != null && p.isClickable()) {
                android.graphics.Rect pb = new android.graphics.Rect();
                p.getBoundsInScreen(pb);
                if (pb.width() <= dm.widthPixels / 3 && pb.height() <= dm.heightPixels / 6 && p.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true;
            }
            if (Build.VERSION.SDK_INT < 24) return false;
            rcGesture(b.centerX(), b.centerY(), b.centerX(), b.centerY(), 60, new Runnable() {
                public void run() {
                }
            });
            return true;
        } catch (Throwable t) {
            return false;
        }
    }

    /** Mahkamlangan (qulflangan) kartochka: avval "qulfdan chiqarish" bandini, bo'lmasa qulf belgisini bosadi.
     *  true - biror narsa bosildi (natijani kutish kerak). */
    private boolean rcUnlock(AccessibilityNodeInfo root, RcPick pk) {
        try {
            AccessibilityNodeInfo it = rcFindWords(root, RC_UNLOCK, 0, new int[]{0});
            if (it != null && rcClickSmall(it)) return true;
            AccessibilityNodeInfo lk = rcFindWords(pk.card != null ? pk.card : pk.node, RC_LOCKED, 0, new int[]{0});
            if (lk != null && rcClickSmall(lk)) return true;
        } catch (Throwable t) {
        }
        return false;
    }

    private void rcAct() {
        try {
            if (rcPkg == null) return;
            AccessibilityNodeInfo r = getRootInActiveWindow();
            CharSequence rp = r == null ? null : r.getPackageName();
            if (r == null || !isRecentsPkg(rp == null ? "" : rp.toString())) {
                rcBusy = false; // keyingi hodisada qayta uriniladi
                return;
            }
            RcPick pk = rcPick(r);
            if (pk == null) {
                // kartochka yo'q: urinib ko'rgan bo'lsak - olib tashlandi
                if (rcTry > 0) rcDone();
                else rcBusy = false;
                return;
            }
            if (rcTry == 0 && rcCount0 == 0) rcCount0 = pk.count;
            if (rcTry > 0 && pk.count < rcCount0) {
                rcDone(); // bir xil nomli kartochkalardan biri ketdi: kerakligi olib tashlandi
                return;
            }
            // 1) kartochka animatsiyasi to'xtashini kutamiz (suzib yurgan kartochkani surib bo'lmaydi)
            if (rcLastRect == null || !rcLastRect.equals(pk.rect)) {
                rcLastRect = new android.graphics.Rect(pk.rect);
                if (++rcWait <= 10) {
                    rcLater(150);
                    return;
                }
            }
            android.util.DisplayMetrics dm = getResources().getDisplayMetrics();
            final int W = dm.widthPixels, H = dm.heightPixels;
            // 2) kartochka ko'rinmayotgan bo'lsa (chetda) - avval o'ngga/chapga surib markazga keltiramiz
            if (pk.vis < 0.5f && rcScr < 2) {
                rcScr++;
                int dir = pk.rect.centerX() < W / 2 ? 1 : -1;
                rcGesture((int) (W * (dir > 0 ? 0.25 : 0.75)), H / 2, (int) (W * (dir > 0 ? 0.75 : 0.25)), H / 2, 250, new Runnable() {
                    public void run() {
                        rcLastRect = null;
                        rcWait = 0;
                        rcLater(450);
                    }
                });
                return;
            }
            // 3) bir marta urinib kartochka qolgan bo'lsa - u mahkamlangan: qulfdan chiqarishga urinamiz
            if (rcTry >= 1 && rcUnl < 2) {
                if (rcUnlock(r, pk)) {
                    rcUnl++;
                    rcLastRect = null;
                    rcWait = 0;
                    rcLater(650);
                    return;
                }
                rcUnl = 2;
            }
            if (rcTry >= 4) {
                rcDone();
                return;
            }
            rcTry++;
            // 4) kartochkaning O'ZIDA "dismiss" amali bo'lsa - shuni bajaramiz (uzoq ota-ona tugunlarga tegmaymiz)
            AccessibilityNodeInfo t = pk.card != null ? pk.card : pk.node;
            if (Build.VERSION.SDK_INT >= 21 && t.getActionList().contains(AccessibilityNodeInfo.AccessibilityAction.ACTION_DISMISS)
                    && t.performAction(AccessibilityNodeInfo.ACTION_DISMISS)) {
                rcLater(550);
                return;
            }
            // 5) aks holda aynan shu kartochkaning ekranda ko'rinib turgan qismining o'rtasidan tepaga suramiz
            android.graphics.Rect vr = new android.graphics.Rect(pk.rect);
            if (!vr.intersect(0, 0, W, H)) {
                rcLater(300);
                return;
            }
            final int x = vr.centerX(), y = vr.centerY();
            rcGesture(x, y, x, Math.max(10, y - (int) (H * 0.55)), 180, new Runnable() {
                public void run() {
                    rcLater(550);
                }
            });
        } catch (Throwable t) {
            rcDone();
        }
    }

    private void rcDone() {
        rcPkg = null;
        rcBusy = false;
        rcLastRect = null;
        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
            public void run() {
                performGlobalAction(GLOBAL_ACTION_HOME);
            }
        }, 400);
    }

    /** Hodisaning o'z matni (bitta tugun, IPC yo'q) - daraxtni aylanishdan oldin eng tez tekshiruv. */
    private boolean quickWords(AccessibilityEvent e, String pkg) {
        try {
            if (e.isPassword() || nsIgnore(pkg)) return false;
            // yozish maydonidagi matn ilovani bloklamaydi: u maydondan so'z o'chiriladi (eraseNode)
            AccessibilityNodeInfo src = e.getSource();
            if (src != null && src.isEditable()) {
                eraseNode(src);
                return false;
            }
            List<CharSequence> tx = e.getText();
            if (tx != null) {
                for (int i = 0; i < tx.size(); i++) {
                    CharSequence a = tx.get(i);
                    if (a != null && a.length() > 1 && a.length() <= 20000 && Filtr.find(this, a.toString()) != null) {
                        wordHit(pkg);
                        return true;
                    }
                }
            }
            CharSequence b = e.getContentDescription();
            if (b != null && b.length() > 1 && b.length() <= 20000 && Filtr.find(this, b.toString()) != null) {
                wordHit(pkg);
                return true;
            }
        } catch (Throwable ex) {
        }
        return false;
    }
    private final Runnable scanRun = new Runnable() {
        @Override
        public void run() {
            scanPending = false;
            lastScanAt = System.currentTimeMillis();
            try {
                if (!Filtr.on(BlkService.this)) return;
                PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
                if (pm != null && !pm.isInteractive()) return;
                AccessibilityNodeInfo r = getRootInActiveWindow();
                if (r == null) return;
                CharSequence pc = r.getPackageName();
                if (pc == null) return;
                String p = pc.toString();
                if (p.equals(getPackageName()) || nsIgnore(p)) return;
                int[] cnt = {0};
                String w = scanWords(r, 0, cnt);
                if (w == null) return;
                wordHit(p);
            } catch (Throwable ex) {
            }
        }
    };

    /** Ekran o'zgarishi bilan darhol (har 60 ms dan tez emas) butun ekranni fon oqimida tekshiradi. */
    private void alScreenSoon() {
        if (scanPending) return;
        scanPending = true;
        long d = 60 - (System.currentTimeMillis() - lastScanAt);
        wHandler().postDelayed(scanRun, d > 0 ? d : 0);
    }

    private String scanWords(AccessibilityNodeInfo n, int d, int[] cnt) {
        if (n == null || d > 60 || cnt[0] > 2500) return null;
        cnt[0]++;
        try {
            if (n.isEditable()) {
                // yozish maydoni (qidiruv satri va h.k.): ilova yopilmaydi, faqat ro'yxatdagi so'z matndan o'chadi
                eraseNode(n);
            } else if (!n.isPassword()) {
                boolean hint = Build.VERSION.SDK_INT >= 26 && n.isShowingHintText();
                CharSequence a = hint ? null : n.getText(), b = n.getContentDescription();
                if (a != null && a.length() > 1 && a.length() <= 20000) {
                    String w = Filtr.find(this, a.toString());
                    if (w != null) return w;
                }
                if (b != null && b.length() > 1 && b.length() <= 20000) {
                    String w = Filtr.find(this, b.toString());
                    if (w != null) return w;
                }
            }
        } catch (Throwable e) {
        }
        for (int i = 0; i < n.getChildCount(); i++) {
            AccessibilityNodeInfo c = n.getChild(i);
            if (c == null) continue;
            // ekranda ko'rinmayotgan tugun (va uning bolalari) tekshirilmaydi: IPC va vaqt tejaladi
            if (!c.isVisibleToUser()) continue;
            String w = scanWords(c, d + 1, cnt);
            if (w != null) return w;
        }
        return null;
    }

    /* ====================== minimalist rejim ====================== */
    private final Handler hd = new Handler(Looper.getMainLooper());
    private String curPkg = null;
    private long lastAsk = 0, lastShort = 0, lastSite = 0, remindedFor = 0;
    private boolean ticking = false;
    private Set<String> launch = new HashSet<String>();
    private long launchAt = 0;
    private WindowManager wm;
    private Bar bar;

    private static final String[][] SHORTS = {
            {"com.google.android.youtube", "reel_player_page_container", "reel_recycler", "shorts_player_container"},
            {"com.instagram.android", "clips_viewer", "reel_viewer"},
            {"com.facebook.katana", "reel_viewer", "reels_viewer"},
            {"com.facebook.lite", "reel_viewer", "reels_viewer"},
            {"com.snapchat.android", "spotlight_feed", "spotlight_page"}};
    private static final String[][] SITES = {
            {"com.google.android.youtube", "youtube.com", "youtu.be"},
            {"com.instagram.android", "instagram.com"},
            {"com.facebook.katana", "facebook.com", "fb.com", "fb.watch"},
            {"com.facebook.lite", "facebook.com", "fb.com", "fb.watch"},
            {"com.zhiliaoapp.musically", "tiktok.com"},
            {"com.ss.android.ugc.trill", "tiktok.com"},
            {"com.twitter.android", "x.com", "twitter.com"},
            {"com.snapchat.android", "snapchat.com"},
            {"com.reddit.frontpage", "reddit.com"},
            {"com.netflix.mediaclient", "netflix.com"},
            {"tv.twitch.android.app", "twitch.tv"},
            {"org.telegram.messenger", "web.telegram.org"}};
    private static final String[] BROWSERS = {"com.chrome.dev", "com.chrome.canary", "com.sec.android.app.sbrowser.beta",
            "org.mozilla.firefox_beta", "org.mozilla.focus", "org.mozilla.klar", "com.brave.browser_beta", "com.brave.browser_nightly",
            "com.microsoft.emmx.beta", "com.yandex.browser", "com.UCMobile.intl", "com.uc.browser.en", "mark.via.gp", "mark.via",
            "com.mi.globalbrowser", "com.android.browser", "com.huawei.browser", "com.ecosia.android", "com.opera.gx", "com.opera.touch",
            "org.torproject.torbrowser", "org.bromite.bromite", "acr.browser.lightning", "com.cloudmosa.puffinFree", "org.chromium.chrome",
            "com.google.android.apps.chrome", "com.stoutner.privacybrowser.standard", "com.android.chrome", "com.chrome.beta", "com.sec.android.app.sbrowser",
            "org.mozilla.firefox", "org.mozilla.fenix", "com.microsoft.emmx", "com.brave.browser", "com.opera.browser",
            "com.opera.mini.native", "com.vivaldi.browser", "com.duckduckgo.mobile.android", "com.kiwibrowser.browser"};

    private boolean launchable(String pkg) {
        long now = System.currentTimeMillis();
        if (now - launchAt > 60000 || launch.isEmpty()) {
            try {
                Set<String> n = new HashSet<String>();
                List<ResolveInfo> l = getPackageManager().queryIntentActivities(
                        new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0);
                for (ResolveInfo r : l) n.add(r.activityInfo.packageName);
                launch = n;
                launchAt = now;
            } catch (Exception e) {
            }
        }
        if (!launch.contains(pkg)) return false;
        String lp = pkg.toLowerCase(Locale.ROOT);
        return !(lp.contains("settings") || lp.contains("packageinstaller") || lp.contains("permissioncontroller")
                || lp.contains("dialer") || lp.contains("incallui") || lp.contains("telecom") || lp.contains("emergency")
                || lp.contains("inputmethod") || lp.contains("keyboard"));
    }

    private boolean owned(String pkg) {
        if (Blk.on(this) && Blk.pkgs(this).contains(pkg)) return true;
        return Focus.active(this) && Focus.mode(this, "apps") && Focus.pkgs(this).contains(pkg);
    }

    /** true - hodisa shu yerda qayta ishlandi (blok yoki so'rov oynasi ochildi) */
    private boolean sessGuard(String pkg, int t, AccessibilityEvent e, long now) {
        boolean state = t == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED;
        if (isHome(pkg)) {
            if (state) sxLeave();
            return false;
        }
        if (!launchable(pkg)) return false;
        if (state && !pkg.equals(curPkg)) {
            if (curPkg != null) sxLeave();
            curPkg = pkg;
            return enter(pkg, now);
        }
        if (!pkg.equals(curPkg)) return false;
        detect(pkg, e, now);
        return false;
    }

    private boolean enter(String pkg, long now) {
        hideBar();
        if (owned(pkg)) return false;
        long bu = Sess.blockedUntil(this, pkg, now);
        if (bu > now) return showBlocked(pkg, bu, now);
        Sess.gray(this, Sess.flag(this, "mono", false) && Sess.set(this, "monoPk").contains(pkg));
        if (!Sess.askOn(this) || !Sess.set(this, "askPk").contains(pkg)) {
            startTicker();
            return false;
        }
        if (Sess.valid(this, pkg, now)) {
            Sess.clearLeft(this);
            startTicker();
            return false;
        }
        startTicker();
        return ask(pkg, "ask", now);
    }

    private boolean ask(String pkg, String mode, long now) {
        if (now - lastAsk < 1500) return true;
        lastAsk = now;
        startActivity(new Intent(this, AskActivity.class).putExtra("pkg", pkg).putExtra("mode", mode)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NO_ANIMATION));
        return true;
    }

    private boolean showBlocked(String pkg, long until, long now) {
        if (now - lastBlock < 900) return true;
        lastBlock = now;
        startActivity(new Intent(this, BlockActivity.class).putExtra("pkg", pkg).putExtra("until", until)
                .putExtra("lim", Lim.until(this, pkg, now) >= until)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NO_ANIMATION));
        return true;
    }

    private void sxLeave() {
        lastTickEl = 0;
        Lim.flush(this);
        if (curPkg != null && curPkg.equals(Sess.sPkg(this))) Sess.markLeft(this);
        curPkg = null;
        hideBar();
        Sess.gray(this, false);
    }

    /* ---- sekundlik tekshiruv: progress chizig'i, eslatma, vaqt tugashi, jadval boshlanishi ---- */
    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            ticking = false;
            try {
                if (curPkg == null) {
                    lastTickEl = 0;
                    return;
                }
                startTicker();
                PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
                if (pm != null && !pm.isInteractive()) {
                    lastTickEl = 0;
                    Lim.flush(BlkService.this);
                    return;
                }
                long now = System.currentTimeMillis();
                limCount(curPkg);
                autoTime(now);
                if (owned(curPkg)) {
                    hideBar();
                    return;
                }
                long bu = Sess.blockedUntil(BlkService.this, curPkg, now);
                if (bu > now) {
                    hideBar();
                    if (!Sess.askUp && !BlockActivity.UP) showBlocked(curPkg, bu, now);
                    return;
                }
                if (!Sess.askOn(BlkService.this) || !Sess.set(BlkService.this, "askPk").contains(curPkg)) {
                    hideBar();
                    return;
                }
                if (Sess.askUp) {
                    hideBar();
                    return;
                }
                String sp = Sess.sPkg(BlkService.this);
                long until = Sess.sUntil(BlkService.this), total = Sess.sTotal(BlkService.this);
                if (sp.equals(curPkg) && until > now) {
                    long rem = until - now;
                    showBar(rem, total);
                    if (Sess.flag(BlkService.this, "remind", true) && rem <= 60000 && total >= 180000 && remindedFor != until) {
                        remindedFor = until;
                        Toast.makeText(BlkService.this, "1 daqiqa qoldi", Toast.LENGTH_LONG).show();
                    }
                } else {
                    hideBar();
                    ask(curPkg, sp.equals(curPkg) && until > 0 ? "expired" : "ask", now);
                }
            } catch (Throwable ex) {
            }
        }
    };

    /** Kunlik limit: ilova ochiq turgan vaqtni sanaydi; limit tugasa blok yozuvini yaratadi. */
    private void limCount(String pkg) {
        try {
            long el = android.os.SystemClock.elapsedRealtime();
            if (!Lim.on(this) || !Lim.has(this, pkg) || owned(pkg) || Sess.askUp) {
                lastTickEl = 0;
                return;
            }
            if (Lim.until(this, pkg, System.currentTimeMillis()) > System.currentTimeMillis()) {
                lastTickEl = 0;
                return;
            }
            if (lastTickEl > 0) Lim.add(this, pkg, Math.min(el - lastTickEl, 3000L));
            lastTickEl = el;
            Lim.check(this, pkg);
            long left = Lim.limitMs(this, pkg) - Lim.used(this, pkg);
            String wk = pkg + "|" + Lim.nextMidnight(System.currentTimeMillis());
            if (left > 0 && left <= 60000 && Sess.flag(this, "remind", true) && !wk.equals(limWarn)) {
                limWarn = wk;
                Toast.makeText(this, "Kunlik limitga 1 daqiqa qoldi", Toast.LENGTH_LONG).show();
            }
        } catch (Throwable e) {
        }
    }

    /* ---------- soatni o'zgartirib aldashdan himoya ---------- */
    private static final String[] DT = {"date & time", "date and time", "date&time", "sana va vaqt", "sana & vaqt", "sana, vaqt",
            "дата и время", "tarih ve saat", "tarih & saat"};
    private long lastAuto = 0;

    /** Limit rejimida Sana va vaqt sozlamalari ochilsa, darhol bosh ekranga qaytaradi. */
    private boolean dateGuard(AccessibilityEvent e) {
        if (!Lim.on(this)) return false;
        CharSequence cn = e.getClassName();
        if ((cn != null && cn.toString().toLowerCase(Locale.ROOT).contains("datetime")) || scanTitle(root(e), 0, new int[]{0})) {
            performGlobalAction(GLOBAL_ACTION_HOME);
            return true;
        }
        return false;
    }

    private boolean scanTitle(AccessibilityNodeInfo n, int d, int[] cnt) {
        if (n == null || d > 40 || cnt[0] > 600) return false;
        cnt[0]++;
        String id = n.getViewIdResourceName();
        CharSequence tx = n.getText();
        if (id != null && tx != null) {
            String i = id.toLowerCase(Locale.ROOT);
            if (i.contains("toolbar") || i.contains("action_bar") || i.contains("app_bar")) {
                String x = tx.toString().toLowerCase(Locale.ROOT);
                for (String k : DT) if (x.contains(k)) return true;
                for (String k : NB) if (x.contains(k)) return true;
            }
        }
        for (int i = 0; i < n.getChildCount(); i++) {
            AccessibilityNodeInfo c = n.getChild(i);
            if (c != null && scanTitle(c, d + 1, cnt)) return true;
        }
        return false;
    }

    /** Ruxsat berilgan bo'lsa (WRITE_SECURE_SETTINGS), avtomatik vaqt va vaqt zonasini doim yoqiq tutadi. */
    private void autoTime(long now) {
        if (now - lastAuto < 5000) return;
        lastAuto = now;
        try {
            if (!Lim.on(this) || !Sess.monoOk(this)) return;
            android.content.ContentResolver cr = getContentResolver();
            if (Settings.Global.getInt(cr, Settings.Global.AUTO_TIME, 1) == 0) Settings.Global.putInt(cr, Settings.Global.AUTO_TIME, 1);
            if (Settings.Global.getInt(cr, Settings.Global.AUTO_TIME_ZONE, 1) == 0) Settings.Global.putInt(cr, Settings.Global.AUTO_TIME_ZONE, 1);
        } catch (Throwable ex) {
        }
    }

    /* ---------- ilova ichidagi brauzerlar (WebView) ---------- */
    private Set<String> limDomains(long now) {
        Set<String> out = new HashSet<String>(Lim.hitDomains(this, now));
        for (String[] r : SITES) {
            if (Lim.until(this, r[0], now) > now) for (int i = 1; i < r.length; i++) out.add(r[i]);
        }
        return out;
    }

    private void checkWebView(String pkg, AccessibilityNodeInfo root, long now) {
        if (root == null) return;
        if (pkg != null && pkg.equals(getPackageName())) return; // Madeenaning o'z ekrani (ro'yxat matnlari) bloklanmasin
        Set<String> dom = new HashSet<String>(limDomains(now));
        dom.addAll(SiteBlk.active(this));
        if (dom.isEmpty()) return;
        boolean[] web = {false};
        String[] hit = {null};
        scanWeb(root, 0, new int[]{0}, dom, web, hit);
        if (web[0] && hit[0] != null) {
            performGlobalAction(GLOBAL_ACTION_HOME);
            startActivity(new Intent(this, BlockActivity.class).putExtra("site", hit[0])
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NO_ANIMATION));
        }
    }

    private void scanWeb(AccessibilityNodeInfo n, int d, int[] cnt, Set<String> dom, boolean[] web, String[] hit) {
        if (n == null || d > 40 || cnt[0] > 700) return;
        cnt[0]++;
        CharSequence cn = n.getClassName();
        if (cn != null && cn.toString().contains("WebView")) web[0] = true;
        CharSequence tx = n.getText();
        if (hit[0] == null && tx != null && tx.length() > 3 && tx.length() <= 90) {
            String s = tx.toString().toLowerCase(Locale.ROOT).trim();
            if (s.indexOf(' ') < 0) {
                s = s.replaceFirst("^[a-z]+://", "");
                int e = s.length();
                for (int k = 0; k < s.length(); k++) {
                    char ch = s.charAt(k);
                    if (ch == '/' || ch == '?' || ch == '#' || ch == ':' || ch == '\u2026') {
                        e = k;
                        break;
                    }
                }
                String host = s.substring(0, e);
                for (String dm : dom) {
                    if (dm.length() > 2 && (host.equals(dm) || host.endsWith("." + dm))) {
                        hit[0] = dm;
                        break;
                    }
                }
            }
        }
        for (int i = 0; i < n.getChildCount(); i++) {
            AccessibilityNodeInfo c = n.getChild(i);
            if (c != null) scanWeb(c, d + 1, cnt, dom, web, hit);
        }
    }

    private void startTicker() {
        if (ticking) return;
        ticking = true;
        hd.postDelayed(tick, 1000);
    }

    /* ---- suzuvchi progress chizig'i (maxsus imkoniyatlar qatlami, qo'shimcha ruxsat shart emas) ---- */
    private static class Bar extends View {
        private final Paint pt = new Paint();
        private float frac = 1f;

        Bar(Context c) {
            super(c);
        }

        void set(float f) {
            frac = Math.max(0f, Math.min(1f, f));
            invalidate();
        }

        @Override
        protected void onDraw(Canvas c) {
            pt.setColor(frac > 0.3f ? 0xFF2FBF7A : frac > 0.1f ? 0xFFF2A93B : 0xFFE5484D);
            c.drawRect(0, 0, getWidth() * frac, getHeight(), pt);
        }
    }

    private void showBar(long rem, long total) {
        if (!Sess.flag(this, "bar", true) || total <= 0) {
            hideBar();
            return;
        }
        try {
            if (wm == null) wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
            if (bar == null) {
                bar = new Bar(this);
                WindowManager.LayoutParams lp = new WindowManager.LayoutParams(WindowManager.LayoutParams.MATCH_PARENT,
                        (int) (3 * getResources().getDisplayMetrics().density) + 1,
                        WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                                | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                        PixelFormat.TRANSLUCENT);
                lp.gravity = Gravity.TOP;
                wm.addView(bar, lp);
            }
            bar.set((float) rem / (float) total);
        } catch (Throwable e) {
            bar = null;
        }
    }

    private void hideBar() {
        try {
            if (bar != null && wm != null) wm.removeView(bar);
        } catch (Throwable e) {
        }
        bar = null;
    }

    /* ---- qisqa videolar va saytlar ---- */
    private void detect(String pkg, AccessibilityEvent e, long now) {
        if (Sess.flag(this, "shorts", false) && now - lastShort > 700) {
            /* TikTok butunlay qisqa videodan iborat: ilovaning o'zi yopiladi */
            if ("com.zhiliaoapp.musically".equals(pkg) || "com.ss.android.ugc.trill".equals(pkg)) {
                lastShort = now;
                performGlobalAction(GLOBAL_ACTION_HOME);
                Toast.makeText(this, "Qisqa videolar bloklangan", Toast.LENGTH_SHORT).show();
                return;
            }
            for (String[] r : SHORTS) {
                if (!r[0].equals(pkg)) continue;
                lastShort = now;
                if (hasId(root(e), r)) {
                    performGlobalAction(GLOBAL_ACTION_BACK);
                    Toast.makeText(this, "Qisqa videolar bloklangan", Toast.LENGTH_SHORT).show();
                    return;
                }
            }
        }
        if ((Sess.flag(this, "sites", false) || Lim.anyHit(this) || SiteBlk.on(this)) && now - lastSite > 900) {
            boolean br = false;
            for (String b : BROWSERS) if (b.equals(pkg)) br = true;
            if (br) {
                lastSite = now;
                checkSite(pkg, root(e), now);
            } else if (Lim.anyHit(this) || SiteBlk.on(this)) {
                lastSite = now;
                checkWebView(pkg, root(e), now);
            }
        }
    }

    private boolean hasId(AccessibilityNodeInfo n, String[] tokens) {
        return scanId(n, 0, new int[]{0}, tokens);
    }

    private boolean scanId(AccessibilityNodeInfo n, int d, int[] cnt, String[] tokens) {
        if (n == null || d > 40 || cnt[0] > 900) return false;
        cnt[0]++;
        String id = n.getViewIdResourceName();
        if (id != null) {
            String x = id.toLowerCase(Locale.ROOT);
            for (int i = 1; i < tokens.length; i++) if (x.contains(tokens[i])) return true;
        }
        for (int i = 0; i < n.getChildCount(); i++) {
            AccessibilityNodeInfo c = n.getChild(i);
            if (c != null && scanId(c, d + 1, cnt, tokens)) return true;
        }
        return false;
    }

    private Set<String> blockedDomains(long now) {
        boolean sites = Sess.flag(this, "sites", false);
        Set<String> out = new HashSet<String>();
        if (sites) out.addAll(Sess.set(this, "domains"));
        boolean blk = Blk.on(this);
        Set<String> bp = blk ? Blk.pkgs(this) : new HashSet<String>();
        for (String[] r : SITES) {
            boolean lim = Lim.until(this, r[0], now) > now;
            if (lim || (sites && (bp.contains(r[0]) || Sess.blockedUntil(this, r[0], now) > now))) {
                for (int i = 1; i < r.length; i++) out.add(r[i]);
            }
        }
        out.addAll(Lim.hitDomains(this, now));
        return out;
    }

    /* ---------- boshqa VPN ilovalarni bloklash ---------- */
    private long lastVpn = 0;
    private final java.util.HashMap<String, Boolean> vpnCache = new java.util.HashMap<String, Boolean>();
    private static final String[] VPN_PKGS = {"com.wireguard.android", "org.outline.android.client", "com.psiphon3", "com.psiphon3.subscription",
            "net.openvpn.openvpn", "de.blinkt.openvpn", "com.v2ray.ang", "app.hiddify.com", "com.github.shadowsocks", "com.protonvpn.android",
            "ch.protonvpn.android", "com.nordvpn.android", "com.expressvpn.vpn", "com.cloudflare.onedotonedotonedotone", "com.surfshark.vpnclient.android",
            "org.torproject.android", "com.windscribe.vpn", "com.tunnelbear.android", "com.privateinternetaccess.android", "io.nekohasekai.sagernet",
            "moe.nb4a", "com.v2raytun.android", "com.happproxy", "free.vpn.unblock.proxy.turbovpn", "com.ipvanish", "com.cyberghostvpn.android"};

    private boolean isVpnApp(String pkg) {
        Boolean c = vpnCache.get(pkg);
        if (c != null) return c;
        boolean r = false;
        try {
            for (String x : VPN_PKGS) if (x.equals(pkg)) r = true;
            android.content.pm.ApplicationInfo ai = getPackageManager().getApplicationInfo(pkg, 0);
            boolean sys = (ai.flags & android.content.pm.ApplicationInfo.FLAG_SYSTEM) != 0;
            if (!r && !sys) {
                String lb = "";
                try {
                    lb = getPackageManager().getApplicationLabel(ai).toString().toLowerCase(Locale.ROOT);
                } catch (Throwable t) {
                }
                r = pkg.toLowerCase(Locale.ROOT).contains("vpn") || lb.contains("vpn");
            }
        } catch (Throwable t) {
        }
        vpnCache.put(pkg, r);
        return r;
    }

    private boolean dlgOurs(AccessibilityNodeInfo n, int d, int[] cnt) {
        if (n == null || d > 25 || cnt[0] > 200) return false;
        cnt[0]++;
        CharSequence tx = n.getText();
        if (tx != null) {
            String x = tx.toString().toLowerCase(Locale.ROOT);
            if (x.contains("madeena") || (label != null && label.length() > 2 && x.contains(label))) return true;
        }
        for (int i = 0; i < n.getChildCount(); i++) {
            AccessibilityNodeInfo c = n.getChild(i);
            if (c != null && dlgOurs(c, d + 1, cnt)) return true;
        }
        return false;
    }

    /** Boshqa VPN ilova ochilsa yopadi; tizimning "VPN ulanish so'rovi" Madeenaniki bo'lmasa bekor qiladi. */
    private android.view.View shield = null;

    private void shieldOn() {
        if (shield != null) return;
        try {
            android.view.WindowManager wm = (android.view.WindowManager) getSystemService(WINDOW_SERVICE);
            android.view.View v = new android.view.View(this);
            v.setOnTouchListener(new android.view.View.OnTouchListener() {
                @Override
                public boolean onTouch(android.view.View x, android.view.MotionEvent ev) {
                    return true;
                }
            });
            android.view.WindowManager.LayoutParams lp = new android.view.WindowManager.LayoutParams(
                    android.view.WindowManager.LayoutParams.MATCH_PARENT, android.view.WindowManager.LayoutParams.MATCH_PARENT,
                    android.view.WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                    android.view.WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | android.view.WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                            | android.view.WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                    android.graphics.PixelFormat.TRANSPARENT);
            lp.gravity = android.view.Gravity.TOP | android.view.Gravity.START;
            wm.addView(v, lp);
            shield = v;
        } catch (Throwable t) {
            shield = null;
        }
    }

    private void shieldOff() {
        if (shield == null) return;
        try {
            ((android.view.WindowManager) getSystemService(WINDOW_SERVICE)).removeView(shield);
        } catch (Throwable t) {
        }
        shield = null;
    }

    private long lastHeal = 0;

    /** Madeena VPN i uzilgan bo'lsa (tizimdan o'chirilgan, jarayon to'xtagan) 5 soniyada bir tekshirib qayta ulaydi. */
    private void vpnHeal() {
        try {
            long n = System.currentTimeMillis();
            if (n - lastHeal < 5000) return;
            lastHeal = n;
            if (SiteBlk.on(this) && SiteBlk.vpn(this) && !SiteVpn.running && android.net.VpnService.prepare(this) == null) SiteVpn.start(this);
        } catch (Throwable x) {
        }
    }

    private boolean dlgDisc(AccessibilityNodeInfo n, int d, int[] cnt) {
        if (n == null || d > 25 || cnt[0] > 200) return false;
        cnt[0]++;
        CharSequence tx = n.getText();
        if (tx != null) {
            String x = tx.toString().toLowerCase(Locale.ROOT);
            if (x.contains("disconnect") || x.contains("uzish") || x.contains("ajrat") || x.contains("\u043e\u0442\u043a\u043b\u044e\u0447") || x.contains("\u0440\u0430\u0437\u044a\u0435\u0434\u0438\u043d")) return true;
        }
        for (int i = 0; i < n.getChildCount(); i++) {
            AccessibilityNodeInfo c = n.getChild(i);
            if (c != null && dlgDisc(c, d + 1, cnt)) return true;
        }
        return false;
    }

    /** Sozlamalardagi VPN sahifasi: ekranda "VPN" va Madeena (ulangan VPN) matnlari birga bo'lsa. */
    private boolean vpnPage(AccessibilityNodeInfo root) {
        boolean[] f = new boolean[5];
        vpnScan(root, 0, new int[]{0}, f);
        return f[0] && f[1];
    }

    private void vpnScan(AccessibilityNodeInfo n, int d, int[] cnt, boolean[] f) {
        if (n == null || d > 25 || cnt[0] > 300) return;
        cnt[0]++;
        CharSequence tx = n.getText();
        if (tx != null) {
            String x = tx.toString().toLowerCase(Locale.ROOT);
            if (x.contains("vpn")) f[0] = true;
            if (x.contains("madeena")) f[1] = true;
            if (x.contains("dns")) f[2] = true;
            if (x.contains("hostname") || x.contains("host name") || x.contains("xost") || x.contains("\u0438\u043c\u044f \u0445\u043e\u0441\u0442\u0430")) f[3] = true;
            if (x.contains("dns 1") || x.contains("dns1")) f[4] = true;
        }
        for (int i = 0; i < n.getChildCount(); i++) {
            AccessibilityNodeInfo c = n.getChild(i);
            if (c != null) vpnScan(c, d + 1, cnt, f);
        }
    }

    private boolean vpnGuard(AccessibilityEvent e, String pkg, int t) {
        if (!SiteBlk.on(this)) {
            shieldOff();
            return false;
        }
        boolean nv = SiteBlk.noVpn(this);
        if (t != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED && t != AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED) return false;
        long now = System.currentTimeMillis();
        if (now - lastVpn < 700) return false;
        boolean dlg = pkg.equals("com.android.vpndialogs");
        if (!pkg.contains("settings")) shieldOff();
        if (!dlg && pkg.contains("settings")) {
            AccessibilityNodeInfo sr = root(e);
            if (sr != null) {
                boolean[] f = new boolean[5];
                vpnScan(sr, 0, new int[]{0}, f);
                boolean vp = SiteBlk.vpn(this) && now > SiteBlk.grace(this) && f[0] && f[1];
                boolean dp = (f[2] && f[3]) || f[4]; // "Shaxsiy DNS" sahifasi yoki Wi-Fi "DNS 1" maydoni
                if (vp || dp) {
                    shieldOn(); // sahifa ustiga ko'rinmas qatlam: tegilganda hech narsa bo'lmaydi, xabar ham chiqmaydi
                    return true;
                }
                shieldOff();
            }
        }
        if (dlg) {
            AccessibilityNodeInfo r = root(e);
            if (r == null) return false;
            if (dlgOurs(r, 0, new int[]{0})) {
                // Madeenaning o'z oynasi: faqat "Uzish" (Disconnect) oynasi bekor qilinadi
                if (!(SiteBlk.vpn(this) && dlgDisc(r, 0, new int[]{0}))) return false;
            } else if (!nv) {
                return false;
            }
        } else if (!nv || !isVpnApp(pkg)) {
            return false;
        }
        lastVpn = now;
        performGlobalAction(dlg ? GLOBAL_ACTION_BACK : GLOBAL_ACTION_HOME);
        return true;
    }

    private void urlCollect(AccessibilityNodeInfo n, int d, int[] cnt, List<AccessibilityNodeInfo> out) {
        if (n == null || d > 30 || cnt[0] > 500 || out.size() > 6) return;
        cnt[0]++;
        String id = n.getViewIdResourceName();
        if (id != null && n.getText() != null) {
            String x = id.toLowerCase(Locale.ROOT);
            if (x.contains("url") || x.contains("address") || x.contains("omnibox") || x.contains("location_bar")) out.add(n);
        }
        for (int i = 0; i < n.getChildCount(); i++) {
            AccessibilityNodeInfo c = n.getChild(i);
            if (c != null) urlCollect(c, d + 1, cnt, out);
        }
    }

    private void checkSite(String pkg, AccessibilityNodeInfo root, long now) {
        if (root == null) return;
        Set<String> dom = blockedDomains(now);
        Set<String> sb = SiteBlk.active(this);
        if (dom.isEmpty() && sb.isEmpty()) return;
        List<AccessibilityNodeInfo> l = root.findAccessibilityNodeInfosByViewId(pkg + ":id/url_bar");
        if ((l == null || l.isEmpty()) && pkg.equals("com.sec.android.app.sbrowser"))
            l = root.findAccessibilityNodeInfosByViewId(pkg + ":id/location_bar_edit_text");
        if ((l == null || l.isEmpty()) && pkg.startsWith("org.mozilla"))
            l = root.findAccessibilityNodeInfosByViewId(pkg + ":id/mozac_browser_toolbar_url_view");
        if ((l == null || l.isEmpty()) && pkg.equals("com.opera.browser"))
            l = root.findAccessibilityNodeInfosByViewId(pkg + ":id/url_field");
        if (l == null || l.isEmpty()) {
            // noma'lum brauzer: id'sida url/address/omnibox bo'lgan maydonlardan qidiradi
            l = new java.util.ArrayList<AccessibilityNodeInfo>();
            urlCollect(root, 0, new int[]{0}, l);
        }
        if (l == null) return;
        for (AccessibilityNodeInfo n : l) {
            CharSequence tx = n.getText();
            if (tx == null) continue;
            String u = tx.toString().toLowerCase(Locale.ROOT);
            String sh = SiteBlk.urlHit(u, sb);
            if (sh != null) {
                performGlobalAction(GLOBAL_ACTION_HOME);
                startActivity(new Intent(this, BlockActivity.class).putExtra("site", sh)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NO_ANIMATION));
                return;
            }
            for (String dm : dom) {
                if (dm.length() > 2 && u.contains(dm)) {
                    performGlobalAction(GLOBAL_ACTION_HOME);
                    startActivity(new Intent(this, BlockActivity.class).putExtra("site", dm)
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NO_ANIMATION));
                    return;
                }
            }
        }
    }

    @Override
    public void onInterrupt() {
    }
}
