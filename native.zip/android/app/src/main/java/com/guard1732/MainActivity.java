package com.guard1732;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Build;
import android.content.Intent;
import android.os.Bundle;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    /** Telefon qayta yoqilgandan keyin ochilgan: himoyani avtomatik tiklash kerak */
    public static volatile boolean autostart = false;

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        if (intent != null && intent.getBooleanExtra("autostart", false)) autostart = true;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        Dbg.installCrashHandler(getApplicationContext());
        registerPlugin(GuardPlugin.class);
        super.onCreate(savedInstanceState);
        if (getIntent() != null && getIntent().getBooleanExtra("autostart", false)) autostart = true;
        Dbg.step(this, "ilova ochildi");
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1002);
        }
    }
}
