package com.guard1732;

import android.accessibilityservice.AccessibilityService;
import android.content.Context;
import android.os.SystemClock;
import android.view.accessibility.AccessibilityNodeInfo;

import java.security.MessageDigest;
import java.util.ArrayDeque;

/** Himoyani o'chirib qo'yishga qarshi: parol va xavfli sozlama sahifalarini yopish. */
public class Tamper {
    private static final String PASS_SHA256 = "23141f7b4fb94678035e687019e6b85c7273a89b5d709e4d45209be1e4318fea";
    private static int fails = 0;
    private static long lockUntil = 0;

    public static synchronized boolean check(String pw) {
        long now = SystemClock.elapsedRealtime();
        if (now < lockUntil) return false;            // ko'p xato: 1 daqiqa kutish
        boolean ok = false;
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] d = md.digest(("g1732|" + (pw == null ? "" : pw)).getBytes("UTF-8"));
            StringBuilder b = new StringBuilder();
            for (byte x : d) b.append(String.format("%02x", x));
            ok = MessageDigest.isEqual(b.toString().getBytes("UTF-8"), PASS_SHA256.getBytes("UTF-8"));
        } catch (Throwable ignored) { }
        if (ok) { fails = 0; return true; }
        if (++fails >= 5) { fails = 0; lockUntil = now + 60000; }
        return false;
    }

    public static boolean isLocked() { return SystemClock.elapsedRealtime() < lockUntil; }

    /** Himoya yoqiq bo'lsa true */
    public static boolean active(Context c) {
        return Restore.armed(c) || ScreenCaptureService.running || GuardAccessibilityService.shotsActive;
    }

    /** Sozlamalar, o'rnatuvchi va ruxsat oynalari */
    public static boolean isSystemUi(String p) {
        if (p == null) return false;
        return p.equals("com.android.settings") || p.startsWith("com.android.settings.")
                || p.contains(".settings") || p.contains("packageinstaller")
                || p.contains("permissioncontroller") || p.contains("securitycenter")
                || p.contains("safecenter") || p.contains("vpndialogs");
    }

    private static final String[] DATETIME = {
            "date & time", "date and time", "sana va vaqt", "sana & vaqt", "sana, vaqt", "vaqt va sana",
            "set time", "set date", "vaqtni o'rnatish", "sanani o'rnatish", "time zone", "vaqt mintaqasi",
            "automatic date", "avtomatik sana", "avtomatik vaqt", "network-provided time",
            "дата и время", "часовой пояс", "автоматическая дата"
    };
    private static final String[] RESET = {
            "factory data reset", "factory reset", "erase all data", "reset options", "reset phone",
            "zavod sozlamalari", "zavod holatiga", "barcha ma'lumotlarni o'chirish", "telefonni tiklash",
            "сброс до заводских", "сброс настроек", "стереть все данные"
    };
    private static final String[] NETWORK = {
            "always-on vpn", "doim yoqiq vpn", "block connections without vpn", "vpnsiz ulanishlarni bloklash",
            "add vpn", "vpn qo'shish", "vpn profil", "private dns", "shaxsiy dns", "приватный dns",
            "постоянная vpn", "блокировать подключения без vpn"
    };
    /** "17-32" bilan birga uchrasa xavfli: to'xtatish, o'chirish, ruxsatlarni olish */
    private static final String[] DANGER = {
            "force stop", "majburan to'xtatish", "majburan to'xtat", "uninstall", "o'chirish", "o'chirib tashlash",
            "clear data", "clear storage", "clear cache", "ma'lumotlarni tozalash", "xotirani tozalash",
            "disable", "o'chirib qo'yish", "permissions", "ruxsatlar", "display over other apps",
            "boshqa ilovalar ustida", "usage access", "foydalanish statistikasi", "battery", "batareya",
            "use service", "xizmatdan foydalanish", "foydalanish", "stop 17-32", "to'xtatish", "to'xtatilsinmi",
            "administrator", "administrat", "deactivate", "faolsizlantir", "forget", "unutish", "disconnect",
            "принудительно", "остановить", "администратор", "деактив", "удалить", "стереть", "отключить", "разрешения", "использовать службу"
    };

    /** Bloklash sababi yoki null */
    public static String reason(String pkg, String raw) {
        String t = BlockList.norm(raw);
        if (t.isEmpty()) return null;
        if (pkg != null && pkg.contains("vpndialogs")) {
            // VPN ruxsat oynasi: faqat 17-32 ning o'ziga ruxsat, boshqa VPN ilovalari bloklanadi
            return t.contains("17-32") ? null : "boshqa VPN";
        }
        for (String w : NETWORK) if (t.contains(w)) return "VPN/DNS sozlamasi";
        for (String w : DATETIME) if (t.contains(w)) return "sana/vaqt sozlamasi";
        for (String w : RESET) if (t.contains(w)) return "zavod sozlamalari";
        if (t.contains("17-32")) {
            for (String w : DANGER) if (t.contains(w)) return "ilova sozlamasi (" + w + ")";
        }
        return null;
    }

    public static String collect(AccessibilityNodeInfo root) {
        StringBuilder b = new StringBuilder();
        ArrayDeque<AccessibilityNodeInfo> q = new ArrayDeque<AccessibilityNodeInfo>();
        q.add(root);
        int seen = 0;
        while (!q.isEmpty() && seen < 600) {
            AccessibilityNodeInfo n = q.poll();
            seen++;
            try {
                CharSequence a = n.getText();
                CharSequence d = n.getContentDescription();
                if (a != null && a.length() > 0) b.append(a).append('\n');
                else if (d != null && d.length() > 0) b.append(d).append('\n');
                for (int i = 0; i < n.getChildCount(); i++) {
                    AccessibilityNodeInfo c = n.getChild(i);
                    if (c != null) q.add(c);
                }
            } catch (Throwable ignored) { }
        }
        return b.toString();
    }
}
