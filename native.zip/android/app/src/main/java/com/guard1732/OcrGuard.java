package com.guard1732;

import android.graphics.Bitmap;
import android.graphics.Rect;

import com.google.android.gms.tasks.Tasks;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;

import java.util.List;
import java.util.concurrent.TimeUnit;

/** Rasmdagi yozuvni o'qiydi (ML Kit, qurilmada, internetsiz; lotin yozuvi). Accessibility matni bor joylar o'tkazib yuboriladi. */
public class OcrGuard {
    private final TextRecognizer rec = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);

    /** Orqa oqimda chaqiriladi (bloklaydi) */
    public String read(Bitmap frame) {
        try {
            Text t = Tasks.await(rec.process(InputImage.fromBitmap(frame, 0)), 4, TimeUnit.SECONDS);
            List<Rect> masks = TextGuard.textRects();
            StringBuilder b = new StringBuilder();
            for (Text.TextBlock blk : t.getTextBlocks()) {
                for (Text.Line ln : blk.getLines()) {
                    Rect r = ln.getBoundingBox();
                    if (r == null) continue;
                    int cx = r.centerX(), cy = r.centerY();
                    boolean covered = false;
                    for (Rect m : masks) {
                        if (m.contains(cx, cy)) { covered = true; break; }
                    }
                    if (!covered) b.append(ln.getText()).append('\n');
                }
            }
            return b.toString();
        } catch (Throwable e) {
            return "";
        }
    }

    public void close() {
        try { rec.close(); } catch (Throwable ignored) { }
    }
}
