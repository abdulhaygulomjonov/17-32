package com.guard1732;

import android.app.AppOpsManager;
import android.app.usage.UsageEvents;
import android.app.usage.UsageStatsManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Process;

import org.json.JSONObject;

import java.util.Calendar;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

/** Ilovalar uchun kunlik vaqt limitlari (soniyada): saqlash va bugungi foydalanishni hisoblash. */
public final class AppLimits {
    private AppLimits() { }

    private static SharedPreferences sp(Context c) {
        return c.getSharedPreferences("guard", Context.MODE_PRIVATE);
    }

    /** Eski saqlangan limitlar daqiqada edi: bir marta soniyaga o'tkazadi */
    private static void migrate(Context c) {
        SharedPreferences p = sp(c);
        if (p.contains("limitsS") || !p.contains("limits")) return;
        try {
            JSONObject old = new JSONObject(p.getString("limits", "{}"));
            JSONObject nw = new JSONObject();
            Iterator<String> it = old.keys();
            while (it.hasNext()) {
                String k = it.next();
                int v = old.optInt(k, 0);
                if (v > 0) nw.put(k, v * 60);
            }
            p.edit().putString("limitsS", nw.toString()).apply();
        } catch (Exception ignored) { }
    }

    /** paket -> kunlik limit (soniya) */
    public static Map<String, Integer> getAll(Context c) {
        migrate(c);
        Map<String, Integer> m = new HashMap<String, Integer>();
        try {
            JSONObject o = new JSONObject(sp(c).getString("limitsS", "{}"));
            Iterator<String> it = o.keys();
            while (it.hasNext()) {
                String k = it.next();
                int v = o.optInt(k, 0);
                if (v > 0) m.put(k, v);
            }
        } catch (Exception ignored) { }
        return m;
    }

    public static int getLimit(Context c, String pkg) {
        Integer v = getAll(c).get(pkg);
        return v == null ? 0 : v.intValue();
    }

    /** seconds: kunlik limit soniyada (0 = olib tashlash) */
    public static void setLimit(Context c, String pkg, int seconds) {
        migrate(c);
        try {
            JSONObject o = new JSONObject(sp(c).getString("limitsS", "{}"));
            if (seconds > 0) o.put(pkg, seconds); else o.remove(pkg);
            sp(c).edit().putString("limitsS", o.toString()).apply();
        } catch (Exception ignored) { }
    }

    /** Limit qulfi tugaydigan vaqt (ms). Qulf yo'q yoki tugagan bo'lsa 0 */
    public static long lockUntil(Context c, String pkg) {
        try {
            JSONObject o = new JSONObject(sp(c).getString("locks", "{}"));
            long u = o.optLong(pkg, 0L);
            return u > System.currentTimeMillis() ? u : 0L;
        } catch (Exception e) {
            return 0L;
        }
    }

    /** Limitni qo'yadi va uni `days` kunga qulflaydi (shu muddatda o'zgartirib bo'lmaydi) */
    public static void setLimitLocked(Context c, String pkg, int seconds, int days) {
        try {
            setLimit(c, pkg, seconds);
            JSONObject o = new JSONObject(sp(c).getString("locks", "{}"));
            if (seconds > 0) o.put(pkg, System.currentTimeMillis() + days * 86400000L);
            else o.remove(pkg);
            sp(c).edit().putString("locks", o.toString()).apply();
        } catch (Exception ignored) { }
    }

    @SuppressWarnings("deprecation")
    public static boolean hasUsageAccess(Context c) {
        AppOpsManager a = (AppOpsManager) c.getSystemService(Context.APP_OPS_SERVICE);
        if (a == null) return false;
        int mode;
        if (Build.VERSION.SDK_INT >= 29) {
            mode = a.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS,
                    Process.myUid(), c.getPackageName());
        } else {
            mode = a.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS,
                    Process.myUid(), c.getPackageName());
        }
        return mode == AppOpsManager.MODE_ALLOWED;
    }

    private static void add(Map<String, Long> m, String p, long ms) {
        Long cur = m.get(p);
        long base = cur == null ? 0L : cur.longValue();
        m.put(p, base + Math.max(0L, ms));
    }

    /** paket -> bugun (00:00 dan hozirgacha) ekranda bo'lgan vaqti, millisekund */
    public static Map<String, Long> todayUsageMs(Context c) {
        Map<String, Long> total = new HashMap<String, Long>();
        if (!hasUsageAccess(c)) return total;
        try {
            UsageStatsManager u = (UsageStatsManager) c.getSystemService(Context.USAGE_STATS_SERVICE);
            if (u == null) return total;
            Calendar cal = Calendar.getInstance();
            cal.set(Calendar.HOUR_OF_DAY, 0);
            cal.set(Calendar.MINUTE, 0);
            cal.set(Calendar.SECOND, 0);
            cal.set(Calendar.MILLISECOND, 0);
            long now = System.currentTimeMillis();
            UsageEvents ev = u.queryEvents(cal.getTimeInMillis(), now);
            Map<String, Set<String>> active = new HashMap<String, Set<String>>();
            Map<String, Long> start = new HashMap<String, Long>();
            UsageEvents.Event e = new UsageEvents.Event();
            while (ev.hasNextEvent()) {
                ev.getNextEvent(e);
                String p = e.getPackageName();
                if (p == null) continue;
                int t = e.getEventType();
                String cls = String.valueOf(e.getClassName());
                if (t == 1) {                       // ACTIVITY_RESUMED
                    Set<String> s = active.get(p);
                    if (s == null) { s = new HashSet<String>(); active.put(p, s); }
                    if (s.isEmpty()) start.put(p, Long.valueOf(e.getTimeStamp()));
                    s.add(cls);
                } else if (t == 2 || t == 23) {     // ACTIVITY_PAUSED / ACTIVITY_STOPPED
                    Set<String> s = active.get(p);
                    if (s != null && s.remove(cls) && s.isEmpty()) {
                        Long st = start.remove(p);
                        if (st != null) add(total, p, e.getTimeStamp() - st.longValue());
                    }
                }
            }
            for (Map.Entry<String, Set<String>> en : active.entrySet()) {
                if (!en.getValue().isEmpty()) {
                    Long st = start.get(en.getKey());
                    if (st != null) add(total, en.getKey(), now - st.longValue());
                }
            }
        } catch (Exception ignored) { }
        return total;
    }

    /** Limit qo'yilgan va bugungi vaqt limitga yetgan bo'lsa true */
    public static boolean isOver(Context c, String pkg) {
        int lim = getLimit(c, pkg);
        if (lim <= 0) return false;
        Long ms = todayUsageMs(c).get(pkg);
        return ms != null && ms.longValue() >= lim * 1000L;
    }
}
