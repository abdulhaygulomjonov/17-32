package com.guard1732;

import android.content.Context;
import android.content.SharedPreferences;

/** Diagnostika: har qadam xotiraga darrov yoziladi, ilova yiqilsa ham qoladi. */
public class Dbg {
    private static SharedPreferences sp(Context c) {
        return c.getApplicationContext().getSharedPreferences("guard_dbg", Context.MODE_PRIVATE);
    }

    public static synchronized void step(Context c, String s) {
        try {
            SharedPreferences p = sp(c);
            String old = p.getString("log", "");
            String[] lines = old.isEmpty() ? new String[0] : old.split("\n");
            StringBuilder b = new StringBuilder();
            int from = Math.max(0, lines.length - 11);
            for (int i = from; i < lines.length; i++) b.append(lines[i]).append('\n');
            b.append(android.text.format.DateFormat.format("HH:mm:ss", System.currentTimeMillis())).append(' ').append(s);
            p.edit().putString("log", b.toString()).commit();
        } catch (Throwable ignored) { }
    }

    public static String log(Context c) {
        try { return sp(c).getString("log", ""); } catch (Throwable t) { return ""; }
    }

    public static void clear(Context c) {
        try { sp(c).edit().remove("log").commit(); } catch (Throwable ignored) { }
    }

    public static void installCrashHandler(final Context c) {
        final Thread.UncaughtExceptionHandler prev = Thread.getDefaultUncaughtExceptionHandler();
        Thread.setDefaultUncaughtExceptionHandler(new Thread.UncaughtExceptionHandler() {
            @Override public void uncaughtException(Thread t, Throwable e) {
                StringBuilder b = new StringBuilder("CRASH[" + t.getName() + "] " + e);
                StackTraceElement[] st = e.getStackTrace();
                for (int i = 0; i < Math.min(4, st.length); i++) b.append(" @").append(st[i]);
                if (e.getCause() != null) b.append(" cause=").append(e.getCause());
                step(c, b.toString());
                if (prev != null) prev.uncaughtException(t, e);
            }
        });
    }
}
