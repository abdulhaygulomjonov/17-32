package com.guard1732;

import android.content.Context;
import android.graphics.Bitmap;

import org.tensorflow.lite.Interpreter;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/**
 * assets/nsfw.tflite:
 *  kirish [1,H,W,3] float32 (0..1, RGB)
 *  chiqish 5 sinf: drawings, hentai, neutral, porn, sexy  (yoki 2 sinf: safe, nsfw)
 */
public class NsfwClassifier {
    public static final String MODEL_FILE = "nsfw.tflite";

    private final Interpreter interpreter;
    private final int size;
    private final int outN;

    public NsfwClassifier(Context ctx) throws IOException {
        InputStream is = ctx.getAssets().open(MODEL_FILE);
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        byte[] buf = new byte[65536];
        int n;
        while ((n = is.read(buf)) > 0) bo.write(buf, 0, n);
        is.close();
        byte[] bytes = bo.toByteArray();
        ByteBuffer bb = ByteBuffer.allocateDirect(bytes.length).order(ByteOrder.nativeOrder());
        bb.put(bytes);
        bb.rewind();
        Interpreter.Options o = new Interpreter.Options();
        o.setNumThreads(4);
        interpreter = new Interpreter(bb, o);
        size = interpreter.getInputTensor(0).shape()[1];
        outN = interpreter.getOutputTensor(0).shape()[1];
    }

    /** 0..1: rasm ochiq pornografik bo'lish ehtimoli */
    public float explicitScore(Bitmap bmp) {
        Bitmap scaled = Bitmap.createScaledBitmap(bmp, size, size, true);
        ByteBuffer in = ByteBuffer.allocateDirect(size * size * 3 * 4).order(ByteOrder.nativeOrder());
        int[] px = new int[size * size];
        scaled.getPixels(px, 0, size, 0, 0, size, size);
        for (int p : px) {
            in.putFloat(((p >> 16) & 0xFF) / 255f);
            in.putFloat(((p >> 8) & 0xFF) / 255f);
            in.putFloat((p & 0xFF) / 255f);
        }
        in.rewind();
        if (scaled != bmp) scaled.recycle();
        float[][] out = new float[1][outN];
        interpreter.run(in, out);
        float[] o = out[0];
        // faqat porn + hentai. "sexy" qo'shilmaydi: yuz/teri/iliq ranglarda soxta ball beradi
        if (outN >= 5) return Math.min(1f, o[3] + o[1]);
        return o[outN - 1];
    }

    /** Deyarli bir xil rangli (bo'sh fon, matn, tugma) bo'lakmi: bunday bo'lakni modelga bermaymiz */
    public static boolean isFlat(Bitmap bmp) {
        Bitmap t = Bitmap.createScaledBitmap(bmp, 24, 24, true);
        int[] px = new int[24 * 24];
        t.getPixels(px, 0, 24, 0, 0, 24, 24);
        if (t != bmp) t.recycle();
        double sum = 0, sq = 0;
        for (int p : px) {
            double l = 0.299 * ((p >> 16) & 0xFF) + 0.587 * ((p >> 8) & 0xFF) + 0.114 * (p & 0xFF);
            sum += l;
            sq += l * l;
        }
        double n = px.length, mean = sum / n;
        double std = Math.sqrt(Math.max(0, sq / n - mean * mean));
        return std < 14.0;
    }

    public void close() { interpreter.close(); }

    public static boolean modelExists(Context ctx) {
        if (NudeDetector.modelExists(ctx)) return true;
        try {
            String[] l = ctx.getAssets().list("");
            if (l != null) for (String s : l) if (MODEL_FILE.equals(s)) return true;
        } catch (IOException ignored) { }
        return false;
    }
}
