package com.guard1732;

import android.content.Intent;
import android.net.VpnService;
import android.os.ParcelFileDescriptor;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Faqat DNS uchun mahalliy VPN: ilovalarning DNS so'rovlari shu yerdan o'tadi.
 * Nomaqbul domen bo'lsa "yo'q" javobi qaytadi, qolganlari oilaviy DNS (1.1.1.3) orqali o'tadi.
 * Boshqa trafik (video, sahifalar) VPN'ga kirmaydi, tezlikka ta'sir qilmaydi.
 */
public class GuardVpnService extends VpnService {
    public static volatile boolean running = false;
    public static volatile String lastError = "";
    private static volatile GuardVpnService inst;

    private static final String ADDR = "10.77.0.1";
    private static final String FAKE_DNS = "10.77.0.2";
    private static final String[] UPSTREAM = { "1.1.1.3", "1.0.0.3", "8.8.8.8" };   // oxirgisi zaxira (filtrsiz)

    private ParcelFileDescriptor tun;
    private FileOutputStream out;
    private ExecutorService pool;
    private Thread reader;
    private volatile boolean stop = false;
    private long lastBlockLog = 0;
    private long lastSafeLog = 0;

    public static void stopNow() {
        GuardVpnService s = inst;
        if (s != null) s.shutdown();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (!running) startVpn();
        return START_STICKY;
    }

    private void startVpn() {
        try {
            Builder b = new Builder()
                    .setSession("17-32 DNS")
                    .addAddress(ADDR, 32)
                    .addDnsServer(FAKE_DNS)
                    .addRoute(FAKE_DNS, 32);
            b.setBlocking(true);
            tun = b.establish();
            if (tun == null) {
                lastError = "VPN ruxsati yo'q";
                Dbg.step(this, "VPN: ruxsat yo'q");
                stopSelf();
                return;
            }
            inst = this;
            stop = false;
            running = true;
            lastError = "";
            pool = Executors.newFixedThreadPool(4);
            out = new FileOutputStream(tun.getFileDescriptor());
            final FileInputStream in = new FileInputStream(tun.getFileDescriptor());
            reader = new Thread(new Runnable() {
                @Override public void run() {
                    byte[] buf = new byte[32767];
                    try {
                        while (!stop) {
                            int n = in.read(buf);
                            if (n < 0) break;
                            if (n == 0) { Thread.sleep(20); continue; }
                            handle(buf, n);
                        }
                    } catch (Throwable t) {
                        if (!stop) Dbg.step(GuardVpnService.this, "VPN sikl xato: " + t);
                    }
                    if (!stop) shutdown();
                }
            }, "guard-dns");
            reader.start();
            Dbg.step(this, "VPN/DNS yoqildi");
        } catch (Throwable t) {
            lastError = "VPN: " + t.getClass().getSimpleName() + " " + t.getMessage();
            Dbg.step(this, "VPN xato: " + t);
            shutdown();
        }
    }

    private void handle(byte[] p, int n) {
        if (n < 28 || (p[0] >> 4) != 4) return;
        int ihl = (p[0] & 0x0F) * 4;
        if (p[9] != 17 || n < ihl + 8) return;                       // faqat UDP
        int dport = ((p[ihl + 2] & 0xFF) << 8) | (p[ihl + 3] & 0xFF);
        if (dport != 53) return;
        final byte[] client = { p[12], p[13], p[14], p[15] };
        final byte[] server = { p[16], p[17], p[18], p[19] };
        final int sport = ((p[ihl] & 0xFF) << 8) | (p[ihl + 1] & 0xFF);
        final byte[] q = Arrays.copyOfRange(p, ihl + 8, n);
        String name = DnsFilter.qname(q);
        if (name != null && DnsFilter.blocked(name)) {
            byte[] nx = DnsFilter.nxdomain(q);
            if (nx != null) {
                write(buildReply(client, server, sport, nx));
                long now = System.currentTimeMillis();
                if (now - lastBlockLog > 3000) {
                    lastBlockLog = now;
                    Dbg.step(this, "DNS bloklandi: " + name);
                }
                return;
            }
        }
        ExecutorService ex = pool;
        if (ex == null) return;
        // SafeSearch: Google/Bing/DuckDuckGo xavfsiz qidiruv serveriga yo'naltiriladi
        final String target = name == null ? null : DnsFilter.safeTarget(name);
        if (target != null) {
            int qend = DnsFilter.questionEnd(q);
            int qtype = qend >= 4 ? (((q[qend - 4] & 0xFF) << 8) | (q[qend - 3] & 0xFF)) : 0;
            if (qtype != 1) {   // AAAA, HTTPS va boshqalar: yozuv yo'q, mijoz IPv4 dan foydalanadi
                byte[] nd = DnsFilter.nodata(q);
                if (nd != null) write(buildReply(client, server, sport, nd));
                return;
            }
            long now = System.currentTimeMillis();
            if (now - lastSafeLog > 5000) {
                lastSafeLog = now;
                Dbg.step(this, "SafeSearch: " + name + " -> " + target);
            }
            ex.execute(new Runnable() {
                @Override public void run() {
                    List<byte[]> ips = DnsFilter.aRecords(forward(DnsFilter.buildQuery(target)));
                    if (ips.isEmpty()) {
                        byte[] st = DnsFilter.staticIp(target);
                        if (st != null) ips.add(st);
                    }
                    byte[] ans = DnsFilter.answerA(q, ips);
                    if (ans != null) write(buildReply(client, server, sport, ans));
                }
            });
            return;
        }
        ex.execute(new Runnable() {
            @Override public void run() {
                byte[] ans = forward(q);
                if (ans != null) write(buildReply(client, server, sport, ans));
            }
        });
    }

    private byte[] forward(byte[] q) {
        for (String up : UPSTREAM) {
            DatagramSocket s = null;
            try {
                s = new DatagramSocket();
                protect(s);   // bu so'rov VPN'ga qaytib kirmasligi uchun
                s.setSoTimeout(2000);
                s.send(new DatagramPacket(q, q.length, InetAddress.getByName(up), 53));
                byte[] r = new byte[4096];
                DatagramPacket dp = new DatagramPacket(r, r.length);
                s.receive(dp);
                return Arrays.copyOf(r, dp.getLength());
            } catch (Throwable ignored) {
            } finally {
                if (s != null) s.close();
            }
        }
        return null;
    }

    private void write(byte[] pkt) {
        FileOutputStream o = out;
        if (o == null) return;
        try {
            synchronized (this) { o.write(pkt); }
        } catch (Throwable ignored) { }
    }

    private static byte[] buildReply(byte[] client, byte[] server, int clientPort, byte[] dns) {
        int len = 20 + 8 + dns.length;
        byte[] r = new byte[len];
        r[0] = 0x45;
        r[2] = (byte) (len >> 8); r[3] = (byte) len;
        r[6] = 0x40;            // DF
        r[8] = 64;              // TTL
        r[9] = 17;              // UDP
        System.arraycopy(server, 0, r, 12, 4);   // kimdan: so'rov yuborilgan DNS manzil
        System.arraycopy(client, 0, r, 16, 4);   // kimga: so'rovchi
        int ck = checksum(r, 0, 20);
        r[10] = (byte) (ck >> 8); r[11] = (byte) ck;
        r[20] = 0; r[21] = 53;
        r[22] = (byte) (clientPort >> 8); r[23] = (byte) clientPort;
        int ul = 8 + dns.length;
        r[24] = (byte) (ul >> 8); r[25] = (byte) ul;   // UDP nazorat yig'indisi 0 (IPv4 da ruxsat etilgan)
        System.arraycopy(dns, 0, r, 28, dns.length);
        return r;
    }

    private static int checksum(byte[] b, int off, int len) {
        long sum = 0;
        for (int i = off; i < off + len; i += 2) sum += ((b[i] & 0xFF) << 8) | (b[i + 1] & 0xFF);
        while ((sum >> 16) != 0) sum = (sum & 0xFFFF) + (sum >> 16);
        return (int) (~sum & 0xFFFF);
    }

    private void shutdown() {
        stop = true;
        running = false;
        inst = null;
        try { if (pool != null) pool.shutdownNow(); } catch (Throwable ignored) { }
        pool = null;
        try { if (tun != null) tun.close(); } catch (Throwable ignored) { }
        tun = null;
        out = null;
        stopSelf();
    }

    @Override
    public void onRevoke() {
        Dbg.step(this, "VPN bekor qilindi (boshqa VPN yoqilgan bo'lishi mumkin)");
        shutdown();
        super.onRevoke();
    }

    @Override
    public void onDestroy() {
        stop = true;
        running = false;
        super.onDestroy();
    }
}
