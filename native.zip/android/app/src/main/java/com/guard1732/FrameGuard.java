package com.guard1732;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;

/** Kadr tahlili (ScreenCaptureService bilan bir xil mantiq): screenshot rejimida Accessibility xizmati ishlatadi. */
public class FrameGuard {
    private final Context ctx;
    private NsfwClassifier classifier;
    private NudeDetector detector;
    private int hits = 0;
    private int deepHits = 0;
    private int firedSystem = 0;
    private long lastDeep = 0;
    private long lastHitAt = 0;
    private int blackRun = 0;
    private long lastProtCheck = 0;
    private OcrGuard ocr;
    private long lastOcr = 0;

    public int firedSystem() { return firedSystem; }

    public FrameGuard(Context c) throws Throwable {
        ctx = c.getApplicationContext();
        Dbg.step(ctx, "model yuklanmoqda (screenshot)");
        try {
            if (NudeDetector.modelExists(ctx)) {
                try {
                    detector = new NudeDetector(ctx);
                } catch (Throwable t) {
                    Dbg.step(ctx, "NudeNet yuklanmadi: " + t.getMessage());
                    if (!hasAsset("nsfw.tflite")) throw t;
                    classifier = new NsfwClassifier(ctx);
                }
            } else {
                classifier = new NsfwClassifier(ctx);
            }
        } catch (Throwable t) {
            throw t;
        }
        try { ocr = new OcrGuard(); } catch (Throwable t) { Dbg.step(ctx, "OCR yuklanmadi: " + t.getMessage()); }
        Dbg.step(ctx, "model OK (screenshot)");
    }

    public void close() {
        try { if (classifier != null) classifier.close(); } catch (Throwable ignored) { }
        try { if (detector != null) detector.close(); } catch (Throwable ignored) { }
        try { if (ocr != null) ocr.close(); } catch (Throwable ignored) { }
    }

    /** true = nomaqbul kontent. Kadr shu yerda recycle qilinadi. */
    public boolean process(Bitmap frame, long now) {
        try {
            if (isBlack(frame)) {
                blackRun++;
                if (blackRun >= 3 && now - lastProtCheck > 1000) {
                    lastProtCheck = now;
                    GuardAccessibilityService sv = GuardAccessibilityService.instance;
                    if (sv != null) sv.protectedBlack(blackRun >= 8);
                }
                return false;
            }
            blackRun = 0;

            NsfwClassifier c = classifier;
            NudeDetector d = detector;
            if (c == null && d == null) return false;
            SharedPreferences sp = ctx.getSharedPreferences("guard", Context.MODE_PRIVATE);
            final float thr = 0.60f;

            boolean fire;
            if (d != null) {
                fire = decideDetector(d, frame, sp, thr, now);
            } else {
                firedSystem = 0;
                float best = scan(c, frame, thr);
                fire = false;
                if (best >= thr) {
                    if (now - lastHitAt > 2500) hits = 0;
                    hits++;
                    lastHitAt = now;
                    if (best >= Math.min(0.97f, thr + 0.25f) || hits >= 2) fire = true;
                } else {
                    hits = 0;
                }
            }
            // 5-tizim: rasmdagi yozuv (OCR), har 1,5 soniyada
            if (!fire && ocr != null && now - lastOcr > 1500) {
                lastOcr = now;
                String txt = ocr.read(frame);
                if (TextGuard.badImageText(txt)) {
                    fire = true;
                    firedSystem = 5;
                    Dbg.step(ctx, "tizim 5: rasmdagi yozuv");
                }
            }
            if (fire) { hits = 0; deepHits = 0; }
            return fire;
        } finally {
            try { frame.recycle(); } catch (Throwable ignored) { }
        }
    }

    /** Kadrning o'rta qismida (tepa/past tizim panellaridan tashqari) hech qanday yorug' piksel yo'qmi */
    private static boolean isBlack(Bitmap b) {
        int W = b.getWidth(), H = b.getHeight();
        if (W < 24 || H < 48) return false;
        int y0 = (int) (H * 0.10f), y1 = (int) (H * 0.90f);
        int sx = Math.max(1, W / 24), sy = Math.max(1, (y1 - y0) / 40);
        for (int y = y0; y < y1; y += sy) {
            for (int x = 0; x < W; x += sx) {
                int p = b.getPixel(x, y);
                int m = Math.max((p >> 16) & 0xFF, Math.max((p >> 8) & 0xFF, p & 0xFF));
                if (m > 12) return false;
            }
        }
        return true;
    }

    private boolean hasAsset(String name) {
        try {
            String[] l = ctx.getAssets().list("");
            if (l != null) for (String x : l) if (name.equals(x)) return true;
        } catch (Throwable ignored) { }
        return false;
    }

    /**
     * 3 tizim:
     *  m1 (standart yoqiq): ochiq jinsiy a'zolar, 2 kadrda tasdiqlanadi (juda aniq bo'lsa darrov)
     *  m2: yopiq, lekin uyatsiz kiyim (lifchik, sochiq...): chegara 15% qattiqroq, doim 2 kadr kerak
     *  m3: mayda rasmlar: ekranni 4x6 bo'lakka bo'lib, har 2 soniyada, 2 skanerda tasdiqlanadi
     */
    private boolean decideDetector(NudeDetector d, Bitmap f, SharedPreferences sp, float thr, long now) {
        // uchala tizim doim yoqiq, o'chirib bo'lmaydi
        final boolean m1 = true, m2 = true, m3 = true;

        int W = f.getWidth(), H = f.getHeight(), half = H / 2;
        float[] cm = d.classMax(f);
        Bitmap top = Bitmap.createBitmap(f, 0, 0, W, half);
        NudeDetector.merge(cm, d.classMax(top));
        top.recycle();
        Bitmap bot = Bitmap.createBitmap(f, 0, half, W, H - half);
        NudeDetector.merge(cm, d.classMax(bot));
        bot.recycle();

        // Kiyimli erkak (selfi, portret): yuz ERKAK deb topilgan va ayol yuzi yo'q bo'lsa,
        // "yopiq kiyim" sinflari (kofta, to'qima mato, ko'krak/dumba "covered") ishonchsiz bo'ladi:
        // 2-tizim butunlay o'chadi, ochiq a'zolar uchun esa juda yuqori ishonch talab qilinadi.
        boolean maleOnly = cm[NudeDetector.FACE_MALE] >= 0.45f && cm[NudeDetector.FACE_FEMALE] < 0.35f;
        float ex = m1 ? NudeDetector.explicitOf(cm) : 0f;
        float im = (m2 && !maleOnly) ? NudeDetector.immodestOf(cm) - 0.15f : 0f;
        if (maleOnly && ex < 0.85f) ex = 0f;

        boolean fire = false;
        float cur = Math.max(ex, im);
        if (cur >= thr) {
            if (now - lastHitAt > 2500) hits = 0;
            hits++;
            lastHitAt = now;
            if (ex >= Math.min(0.97f, thr + 0.25f) || hits >= 2) {
                fire = true;
                firedSystem = ex >= im ? 1 : 2;   // 1: ochiq a'zolar, 2: uyatsiz kiyim
                Dbg.step(ctx, "tizim " + firedSystem + ": ex=" + ex + " im=" + im
                        + " yuzE=" + cm[NudeDetector.FACE_MALE] + " yuzA=" + cm[NudeDetector.FACE_FEMALE]);
            }
        } else {
            hits = 0;
        }

        // 3-tizim: mayda rasmlar (yumaloq avatar, kichik surat) uchun chuqur skaner.
        // Ekran ustma-ust tushuvchi kvadrat oynalarga bo'linadi (tomoni = eni 40%, qadam = yarmi),
        // shuning uchun kichik rasm hech qachon chegarada ikkiga bo'linib qolmaydi va model
        // kirishiga (320 px) kattalashib tushadi. Shubha bo'lsa keyingi skaner tezroq (0.8 s).
        long gap = deepHits > 0 ? 800 : 2000;
        if (!fire && m3 && now - lastDeep > gap) {
            lastDeep = now;
            float[] dm = new float[18];
            int side = Math.max(64, Math.min(Math.round(W * 0.40f), Math.min(W, H)));
            int step = Math.max(1, side / 2);
            outer:
            for (int y = 0; ; y += step) {
                int yy = Math.min(y, H - side);
                for (int x = 0; ; x += step) {
                    int xx = Math.min(x, W - side);
                    Bitmap t = Bitmap.createBitmap(f, xx, yy, side, side);
                    if (!NsfwClassifier.isFlat(t)) NudeDetector.merge(dm, d.classMax(t));
                    t.recycle();
                    if (NudeDetector.explicitOf(dm) - 0.10f >= Math.min(0.97f, thr + 0.25f)) break outer;
                    if (xx >= W - side) break;
                }
                if (yy >= H - side) break;
            }
            float dex = m1 || m3 ? NudeDetector.explicitOf(dm) : 0f;
            // erkak kadri: "yopiq kiyim" sinflari o'chadi, ochiq a'zo uchun juda yuqori ishonch kerak
            float dim = (m2 && !maleOnly) ? NudeDetector.immodestOf(dm) - 0.15f : 0f;
            if (maleOnly && dex < 0.90f) dex = 0f;
            float best = Math.max(dex, dim) - 0.10f;   // oyna kontekstsiz, shuning uchun 10% qattiqroq
            if (best >= thr) {
                deepHits++;
                if (deepHits >= 2 || best >= Math.min(0.97f, thr + 0.25f)) {
                    fire = true; firedSystem = 3;
                    Dbg.step(ctx, "tizim 3: dex=" + dex + " dim=" + dim);
                }
            } else {
                deepHits = 0;
            }
        }
        return fire;
    }

    /**
     * Butun ekran, so'ng 2x3 bo'laklar. Bir xil rangli bo'laklar o'tkazib yuboriladi,
     * kichik bo'laklar uchun chegara 10% qattiqroq (kontekstsiz bo'lak ishonchsiz).
     */
    private float scan(NsfwClassifier c, Bitmap f, float thr) {
        float best = 0f;
        if (!NsfwClassifier.isFlat(f)) {
            best = c.explicitScore(f);
            if (best >= thr) return best;
        }
        float tileThr = Math.min(0.99f, thr + 0.10f);
        int W = f.getWidth(), H = f.getHeight();
        int cols = 2, rows = 3;
        int tw = W / cols, th = H / rows;
        for (int r = 0; r < rows; r++) {
            for (int q = 0; q < cols; q++) {
                Bitmap t = Bitmap.createBitmap(f, q * tw, r * th, tw, th);
                float s = NsfwClassifier.isFlat(t) ? 0f : c.explicitScore(t);
                t.recycle();
                if (s >= tileThr) return s;
            }
        }
        return Math.min(best, thr - 0.001f);
    }

}
