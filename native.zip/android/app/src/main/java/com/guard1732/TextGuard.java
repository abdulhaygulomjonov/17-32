package com.guard1732;

import android.graphics.Rect;
import android.os.Build;
import android.view.accessibility.AccessibilityNodeInfo;

import java.util.ArrayDeque;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 4-tizim: brauzer va ilovalar ichidagi veb-oynalar (Telegram, Instagram va boshqalar) uchun
 * "SafeSearch" o'rnini bosuvchi matn tekshiruvi. DNS yoki VPN ishlatilmaydi: ekrandagi
 * manzil, qidiruv so'rovi, sarlavha va sahifa matni Accessibility orqali o'qiladi.
 *
 * Oddiy ilova chatlari (veb-oyna bo'lmagan joylar) tekshirilmaydi, shuning uchun
 * suhbatdagi so'zlar bloklanmaydi.
 */
public final class TextGuard {
    private TextGuard() { }

    /** Brauzer ilovalari: butun oyna tekshiriladi */
    private static final Set<String> BROWSERS = new HashSet<String>(Arrays.asList(
            "com.android.chrome", "com.chrome.beta", "com.chrome.dev", "com.chrome.canary",
            "org.mozilla.firefox", "org.mozilla.firefox_beta", "org.mozilla.fenix",
            "com.opera.browser", "com.opera.mini.native", "com.opera.gx",
            "com.sec.android.app.sbrowser", "com.microsoft.emmx", "com.brave.browser",
            "com.UCMobile.intl", "com.uc.browser.en", "com.mi.globalbrowser",
            "com.android.browser", "com.duckduckgo.mobile.android", "com.vivaldi.browser",
            "com.yandex.browser", "com.google.android.googlequicksearchbox",
            "com.huawei.browser", "mark.via.gp", "org.chromium.webview_shell"));

    /** Manzilda uchrasa darrov bloklanadigan qismlar */
    private static final String[] HOST_STEMS = {
            "pornhub", "xvideos", "xnxx", "xhamster", "redtube", "youporn", "tube8", "spankbang",
            "eporner", "brazzers", "chaturbate", "stripchat", "bongacams", "livejasmin", "cam4",
            "motherless", "nhentai", "hentai", "rule34", "porn", "xxx", "onlyfans", "fapello",
            "thothub", "erome", "hqporner", "beeg", "txxx", "porntrex", "sexvid", "camsoda"
    };
    private static final String[] BAD_TLDS = { ".xxx", ".porn", ".sex", ".adult" };

    /** Kuchli so'zlar: sarlavha, qidiruv va manzil joyida bittasi yetadi */
    private static final Pattern STRONG = Pattern.compile(
            "(?<![\\p{L}\\p{N}])(porn|porno|pornos|pornography|xxx|hentai|nudes?|"
            + "sex videos?|sex video|sex tape|porn videos?|"
            + "порно|порн|хентай|голые девки|секс видео|"
            + "seks video|jinsiy video|yalang'och|yalangoch)(?![\\p{L}\\p{N}])",
            Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);

    /** Kuchsiz so'zlar: bir nechtasi birga kelsagina hisobga olinadi */
    private static final Pattern WEAK = Pattern.compile(
            "(?<![\\p{L}\\p{N}])(sex|seks|секс|erotic|erotica|эротика|naked|nsfw|escort|"
            + "milf|boobs|pussy|dick|cock|blowjob|fetish|stripper|18\\+)(?![\\p{L}\\p{N}])",
            Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);

    private static final Pattern HOST = Pattern.compile(
            "(?<![a-z0-9.-])((?:[a-z0-9-]+\\.)+[a-z]{2,})(?![a-z0-9-])",
            Pattern.CASE_INSENSITIVE);

    private static final int MAX_NODES = 700;
    private static final int MAX_TEXT = 400;

    /** Tekshirilishi kerak bo'lgan oynami (brauzer yoki ichida veb-oynasi bor ilova) */
    public static boolean isBrowser(String pkg) {
        return pkg != null && BROWSERS.contains(pkg);
    }

    /**
     * Oynani tekshiradi. Nomaqbul narsa topilsa true.
     * @param screenH ekran balandligi (tepadagi 20% manzil/sarlavha qismi hisoblanadi)
     */
    public static boolean check(AccessibilityNodeInfo root, String pkg, int screenH) {
        if (root == null) return false;
        boolean browser = isBrowser(pkg);

        StringBuilder head = new StringBuilder();
        StringBuilder body = new StringBuilder();
        boolean hasWeb = browser;

        ArrayDeque<AccessibilityNodeInfo> q = new ArrayDeque<AccessibilityNodeInfo>();
        q.add(root);
        int seen = 0;
        Rect r = new Rect();
        while (!q.isEmpty() && seen < MAX_NODES) {
            AccessibilityNodeInfo n = q.poll();
            seen++;
            try {
                CharSequence cls = n.getClassName();
                if (cls != null && cls.toString().contains("WebView")) hasWeb = true;

                String t = textOf(n);
                if (t != null) {
                    n.getBoundsInScreen(r);
                    String id = n.getViewIdResourceName();
                    boolean top = screenH > 0 && r.top < screenH * 0.20f;
                    boolean field = cls != null && cls.toString().contains("EditText");
                    boolean urlish = id != null && (id.contains("url") || id.contains("search")
                            || id.contains("omnibox") || id.contains("title"));
                    if (top || field || urlish) head.append(t).append('\n');
                    else body.append(t).append('\n');
                }
                int c = n.getChildCount();
                for (int i = 0; i < c; i++) {
                    AccessibilityNodeInfo ch = n.getChild(i);
                    if (ch != null) q.add(ch);
                }
            } catch (Exception ignored) {
            } finally {
                if (n != root && Build.VERSION.SDK_INT < 33) {
                    try { n.recycle(); } catch (Exception ignored) { }
                }
            }
        }
        if (!hasWeb) return false;   // oddiy ilova (chat va hokazo): tekshirilmaydi

        String h = head.toString();
        String b = body.toString();

        // 1) manzil: ro'yxatdagi sayt yoki taqiqlangan domen zonasi
        if (badHost(h) || badHost(b)) return true;
        // 2) tepa qism (manzil, qidiruv, sarlavha): bitta kuchli so'z yetadi, kuchsizdan 2 ta kerak
        if (STRONG.matcher(h).find()) return true;
        if (distinct(WEAK, h) >= 2) return true;
        // 3) sahifa matni: kamida 3 ta kuchli so'z yoki 2 ta kuchli va 3 ta kuchsiz
        int s = count(STRONG, b);
        if (s >= 3) return true;
        if (s >= 1 && distinct(WEAK, b) >= 3) return true;
        return false;
    }

    private static String textOf(AccessibilityNodeInfo n) {
        CharSequence a = n.getText();
        CharSequence d = n.getContentDescription();
        String s = null;
        if (a != null && a.length() > 0) s = a.toString();
        else if (d != null && d.length() > 0) s = d.toString();
        if (s == null) return null;
        if (s.length() > MAX_TEXT) s = s.substring(0, MAX_TEXT);
        return s;
    }

    private static boolean badHost(String text) {
        if (text.isEmpty()) return false;
        Matcher m = HOST.matcher(text.toLowerCase(Locale.ROOT));
        while (m.find()) {
            String host = m.group(1);
            for (String t : BAD_TLDS) if (host.endsWith(t)) return true;
            for (String s : HOST_STEMS) if (host.contains(s)) return true;
        }
        return false;
    }

    private static int count(Pattern p, String text) {
        Matcher m = p.matcher(text);
        int c = 0;
        while (m.find()) c++;
        return c;
    }

    private static int distinct(Pattern p, String text) {
        Matcher m = p.matcher(text);
        Set<String> seen = new HashSet<String>();
        while (m.find()) seen.add(m.group(1).toLowerCase(Locale.ROOT));
        return seen.size();
    }
}
