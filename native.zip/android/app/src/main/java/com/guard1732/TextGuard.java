package com.guard1732;

import android.graphics.Rect;
import android.os.Build;
import android.view.accessibility.AccessibilityNodeInfo;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 4-tizim: brauzer va ilovalar ichidagi veb-oynalar (Telegram, Instagram va boshqalar) uchun
 * "SafeSearch" o'rnini bosuvchi matn tekshiruvi. DNS yoki VPN ishlatilmaydi: ekrandagi
 * manzil, qidiruv so'rovi, sarlavha va sahifa matni Accessibility orqali o'qiladi.
 *
 * Oddiy ilova chatlari (veb-oyna bo'lmagan joylar) tekshirilmaydi, shuning uchun
 * suhbatdagi so'zlar bloklanmaydi.
 */
public final class TextGuard {
    private TextGuard() { }

    /** Brauzer ilovalari: butun oyna tekshiriladi */
    private static final Set<String> BROWSERS = new HashSet<String>(Arrays.asList(
            "com.android.chrome", "com.chrome.beta", "com.chrome.dev", "com.chrome.canary",
            "org.mozilla.firefox", "org.mozilla.firefox_beta", "org.mozilla.fenix",
            "com.opera.browser", "com.opera.mini.native", "com.opera.gx",
            "com.sec.android.app.sbrowser", "com.microsoft.emmx", "com.brave.browser",
            "com.UCMobile.intl", "com.uc.browser.en", "com.mi.globalbrowser",
            "com.android.browser", "com.duckduckgo.mobile.android", "com.vivaldi.browser",
            "com.yandex.browser", "com.google.android.googlequicksearchbox",
            "com.huawei.browser", "mark.via.gp", "org.chromium.webview_shell"));

    /** Manzilda uchrasa darrov bloklanadigan qismlar */
    private static final String[] HOST_STEMS = {
            "pornhub", "xvideos", "xnxx", "xhamster", "redtube", "youporn", "tube8", "spankbang",
            "eporner", "brazzers", "chaturbate", "stripchat", "bongacams", "livejasmin", "cam4",
            "motherless", "nhentai", "hentai", "rule34", "porn", "xxx", "onlyfans", "fapello",
            "thothub", "erome", "hqporner", "beeg", "txxx", "porntrex", "sexvid", "camsoda"
    };
    private static final String[] BAD_TLDS = { ".xxx", ".porn", ".sex", ".adult" };

    /** Kuchli so'zlar: sarlavha, qidiruv va manzil joyida bittasi yetadi */
    private static final Pattern STRONG = Pattern.compile(
            "(?<![\\p{L}\\p{N}])(porn|porno|pornos|pornography|xxx|hentai|nudes?|"
            + "sex videos?|sex video|sex tape|porn videos?|"
            + "порно|порн|хентай|голые девки|секс видео|"
            + "seks video|jinsiy video|yalang'och|yalangoch)(?![\\p{L}\\p{N}])",
            Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);

    /** Kuchsiz so'zlar: bir nechtasi birga kelsagina hisobga olinadi */
    private static final Pattern WEAK = Pattern.compile(
            "(?<![\\p{L}\\p{N}])(sex|seks|секс|erotic|erotica|эротика|naked|nsfw|escort|"
            + "milf|boobs|pussy|dick|cock|blowjob|fetish|stripper|18\\+)(?![\\p{L}\\p{N}])",
            Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);

    /** Qidiruv maydoniga yozilganda har qanday ilovada (Telegram, YouTube...) bloklanadigan so'zlar */
    private static final Pattern FIELD_BAD = Pattern.compile(
            "(?<![\\p{L}\\p{N}])(amlar|amcha|amchalar|sikish|sikishish|uyatsiz|"
            + "yalang[\u2019'\u02bb`]?och|real\\s+amlar|intim\\s+video|"
            + "sex|seks|секс|nsfw|"
            + "голые|голая|голый|обнаженк\\p{L}*|шлюхи|проститутки)(?![\\p{L}])",
            Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);

    private static final Pattern HOST = Pattern.compile(
            "(?<![a-z0-9.-])((?:[a-z0-9-]+\\.)+[a-z]{2,})(?![a-z0-9-])",
            Pattern.CASE_INSENSITIVE);

    /** Telegram va uning klientlari: qidiruv natijalaridagi kanal/guruh nomlari tekshiriladi */
    private static final Set<String> TELEGRAMS = new HashSet<String>(Arrays.asList(
            "org.telegram.messenger", "org.telegram.messenger.web", "org.telegram.plus",
            "org.thunderdog.challegram", "nekox.messenger", "tw.nekomimi.nekogram",
            "org.telegram.messenger.beta", "com.exteragram.messenger",
            "org.telegram.mdgram", "com.radolyn.ayugram", "it.owlgram.android",
            "org.forkgram.messenger", "app.nicegram", "com.iMe.android", "ir.ilmili.telegraph",
            "org.telegram.group", "com.cool2645.nekolite", "org.nift4.catox", "uz.telegram.plus",
            "org.telegram.BifToGram", "com.lonelycatgames.telegram"));

    private static final int MAX_NODES = 1500;
    private static final int MAX_TEXT = 1000;

    /** Oxirgi tekshiruvda Accessibility matni bor joylar (OCR shu joylarni o'tkazib yuboradi: faqat rasmdagi yozuv o'qiladi) */
    private static volatile List<Rect> lastRects = Collections.emptyList();
    public static List<Rect> textRects() { return lastRects; }

    /** Rasmdan o'qilgan (OCR) matn nomaqbulmi */
    public static boolean badImageText(String text) {
        if (text == null || text.isEmpty()) return false;
        if (STRONG.matcher(text).find()) return true;
        if (BlockList.bad(text)) return true;
        if (badHost(text)) return true;
        return distinct(WEAK, text) >= 2;
    }

    /** Tekshirilishi kerak bo'lgan oynami (brauzer yoki ichida veb-oynasi bor ilova) */
    public static boolean isBrowser(String pkg) {
        return pkg != null && BROWSERS.contains(pkg);
    }

    /**
     * Oynani tekshiradi. Nomaqbul narsa topilsa true.
     * @param screenH ekran balandligi (tepadagi 20% manzil/sarlavha qismi hisoblanadi)
     */
    public static boolean check(AccessibilityNodeInfo root, String pkg, int screenH) {
        if (root == null) return false;
        boolean browser = isBrowser(pkg);

        StringBuilder head = new StringBuilder();
        StringBuilder body = new StringBuilder();
        StringBuilder fields = new StringBuilder();   // faqat yozish maydonlari (qidiruv so'rovi)
        boolean topEdit = false;                      // ekran tepasida yozish maydoni = qidiruv rejimi
        boolean hasWeb = browser;
        boolean tgUi = false;                         // Telegram interfeysi belgilari (fork/klonlar uchun)
        int recentMarks = 0;                          // "Recent" + "Clear" = qidiruvdagi "yaqinda qidirilganlar"

        ArrayDeque<AccessibilityNodeInfo> q = new ArrayDeque<AccessibilityNodeInfo>();
        q.add(root);
        int seen = 0;
        Rect r = new Rect();
        ArrayList<Rect> rects = new ArrayList<Rect>();
        while (!q.isEmpty() && seen < MAX_NODES) {
            AccessibilityNodeInfo n = q.poll();
            seen++;
            try {
                CharSequence cls = n.getClassName();
                if (cls != null && cls.toString().contains("WebView")) hasWeb = true;

                String t = textOf(n);
                String vid = n.getViewIdResourceName();
                if ((vid != null && vid.startsWith("org.telegram"))
                        || (cls != null && cls.toString().startsWith("org.telegram"))) tgUi = true;
                // MUHIM: bo'sh qidiruv maydonida matn yo'q (null) bo'ladi, shuning uchun
                // qidiruv rejimi matnga bog'liq bo'lmagan holda aniqlanadi
                if (cls != null && cls.toString().contains("EditText") && screenH > 0) {
                    n.getBoundsInScreen(r);
                    if (r.top < screenH * 0.25f) topEdit = true;
                }
                if (t != null) {
                    if (t.equalsIgnoreCase("Recent") || t.equalsIgnoreCase("Clear")
                            || t.equalsIgnoreCase("So'nggi") || t.equalsIgnoreCase("Yaqinda")
                            || t.equalsIgnoreCase("\u041d\u0435\u0434\u0430\u0432\u043d\u0438\u0435")
                            || t.equalsIgnoreCase("\u041e\u0447\u0438\u0441\u0442\u0438\u0442\u044c")) recentMarks++;
                    n.getBoundsInScreen(r);
                    if (screenH <= 0 || r.height() < screenH * 0.5f) rects.add(new Rect(r));
                    String id = n.getViewIdResourceName();
                    boolean top = screenH > 0 && r.top < screenH * 0.20f;
                    boolean field = cls != null && cls.toString().contains("EditText");
                    boolean urlish = id != null && (id.contains("url") || id.contains("search")
                            || id.contains("omnibox") || id.contains("title"));
                    if (field) fields.append(t).append('\n');
                    if (field && screenH > 0 && r.top < screenH * 0.20f) topEdit = true;
                    if (top || field || urlish) head.append(t).append('\n');
                    else body.append(t).append('\n');
                }
                int c = n.getChildCount();
                for (int i = 0; i < c; i++) {
                    AccessibilityNodeInfo ch = n.getChild(i);
                    if (ch != null) q.add(ch);
                }
            } catch (Exception ignored) {
            } finally {
                if (n != root && Build.VERSION.SDK_INT < 33) {
                    try { n.recycle(); } catch (Exception ignored) { }
                }
            }
        }
        lastRects = rects;
        // Oddiy ilova (Telegram, YouTube...): chat matni tekshirilmaydi, lekin qidiruv/yozish maydoniga
        // nomaqbul so'z yozilsa bloklanadi (qidiruv natijalarini ochmasdan oldin)
        if (!hasWeb) {
            String f = fields.toString();
            if (!f.isEmpty() && (FIELD_BAD.matcher(f).find() || STRONG.matcher(f).find() || BlockList.bad(f))) return true;
            // Oddiy ilovalar (chat, Telegram, Instagram...): ekrandagi butun matn tekshiriladi.
            // Brauzerdan farqi: tasodifiy ("18+", "sex" kabi) bitta kuchsiz so'z yetmaydi, kamida 2 ta kerak.
            String all = head.toString() + "\n" + body.toString();
            if (badHost(all)) return true;
            if (STRONG.matcher(all).find() || FIELD_BAD.matcher(f).find()) return true;
            if (BlockList.bad(head.toString()) || BlockList.badBody(body.toString())) return true;
            if (distinct(WEAK, all) >= 2) return true;
            return false;
        }

        String h = head.toString();
        String b = body.toString();

        // 1) manzil: ro'yxatdagi sayt yoki taqiqlangan domen zonasi
        if (badHost(h) || badHost(b)) return true;
        // 2) tepa qism (manzil, qidiruv, sarlavha): bitta kuchli so'z yetadi, kuchsizdan 2 ta kerak
        if (STRONG.matcher(h).find() || FIELD_BAD.matcher(fields.toString()).find()) return true;
        if (BlockList.bad(h) || BlockList.badBody(b)) return true;
        if (distinct(WEAK, h) >= 1) return true;
        // 3) sahifa matni: kamida 3 ta kuchli so'z yoki 2 ta kuchli va 3 ta kuchsiz
        int s = count(STRONG, b);
        if (s >= 1 || distinct(WEAK, b) >= 1) return true;
        return false;
    }

    public static boolean isTelegramPkg(String pkg) {
        return pkg != null && (TELEGRAMS.contains(pkg) || pkg.contains("telegram"));
    }

    /**
     * Skrinshot olish taqiqlangan oyna (FLAG_SECURE: maxfiy chat, "saqlashni cheklash" kanallari)
     * ekran yozuvida butunlay qora chiqadi, ichidagi rasmni tahlil qilib bo'lmaydi.
     * Faqat Telegram ekranida: chat/kanal sarlavhasi (ekran tepasi) bloklash ro'yxatida
     * (BlockList va qidiruv so'zlari) bo'lsa true qaytaradi. Ro'yxatda bo'lmagan nom yopilmaydi.
     */
    public static boolean protectedMedia(AccessibilityNodeInfo root, String pkg, int screenH) {
        if (root == null || !isTelegramPkg(pkg)) return false;
        ArrayDeque<AccessibilityNodeInfo> q = new ArrayDeque<AccessibilityNodeInfo>();
        q.add(root);
        int seen = 0;
        StringBuilder title = new StringBuilder();
        Rect r = new Rect();
        while (!q.isEmpty() && seen < MAX_NODES) {
            AccessibilityNodeInfo n = q.poll();
            seen++;
            try {
                String t = textOf(n);
                if (t != null) {
                    n.getBoundsInScreen(r);
                    if (screenH > 0 && r.top < screenH * 0.15f) title.append(t).append('\n');
                }
                int c = n.getChildCount();
                for (int i = 0; i < c; i++) {
                    AccessibilityNodeInfo ch = n.getChild(i);
                    if (ch != null) q.add(ch);
                }
            } catch (Exception ignored) {
            }
        }
        String ti = title.toString();
        if (ti.isEmpty()) return false;
        return BlockList.bad(ti) || FIELD_BAD.matcher(ti).find() || STRONG.matcher(ti).find();
    }

    private static String textOf(AccessibilityNodeInfo n) {
        CharSequence a = n.getText();
        CharSequence d = n.getContentDescription();
        String s = null;
        if (a != null && a.length() > 0) s = a.toString();
        else if (d != null && d.length() > 0) s = d.toString();
        if (s == null) return null;
        if (s.length() > MAX_TEXT) s = s.substring(0, MAX_TEXT);
        return s;
    }

    private static boolean badHost(String text) {
        if (text.isEmpty()) return false;
        Matcher m = HOST.matcher(text.toLowerCase(Locale.ROOT));
        while (m.find()) {
            String host = m.group(1);
            for (String t : BAD_TLDS) if (host.endsWith(t)) return true;
            for (String s : HOST_STEMS) if (host.contains(s)) return true;
        }
        return false;
    }

    private static int count(Pattern p, String text) {
        Matcher m = p.matcher(text);
        int c = 0;
        while (m.find()) c++;
        return c;
    }

    private static int distinct(Pattern p, String text) {
        Matcher m = p.matcher(text);
        Set<String> seen = new HashSet<String>();
        while (m.find()) seen.add(m.group(1).toLowerCase(Locale.ROOT));
        return seen.size();
    }
}
