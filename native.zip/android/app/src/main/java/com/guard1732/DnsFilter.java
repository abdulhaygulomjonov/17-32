package com.guard1732;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.regex.Pattern;

/** DNS so'rovlari uchun nomaqbul domen ro'yxati va DNS paketini o'qish yordamchilari. */
final class DnsFilter {
    private DnsFilter() { }

    /** Domenning istalgan joyida uchrasa bloklanadi (uzun, noyob qismlar) */
    private static final String[] STEMS = {
            "pornhub", "xvideos", "xnxx", "xhamster", "redtube", "youporn", "spankbang", "eporner",
            "brazzers", "chaturbate", "stripchat", "bongacams", "livejasmin", "motherless", "nhentai",
            "hentai", "rule34", "porn", "xxx", "onlyfans", "fapello", "thothub", "hqporner", "porntrex",
            "sexvid", "camsoda", "hanime", "tnaflix", "pornpics", "xtube", "jerkmate", "sunporno",
            "daftsex", "hclips", "upornia", "vporn", "camwhores", "fansly", "myfreecams", "cumlouder"
    };
    /** Qisqa nomlar: faqat butun bo'lak ("." yoki "-" orasida) bo'lsa bloklanadi, aks holda "jerome" kabilar buzilardi */
    private static final String[] TOKENS = {
            "sex", "seks", "sexy", "porno", "nude", "nudes", "nsfw", "erotica", "erotika", "milf", "fetish",
            "erome", "beeg", "cam4", "txxx", "fuq", "tube8", "4tube", "xtube", "tubegalore", "javhd", "jav"
    };
    private static final String[] TLDS = { ".xxx", ".porn", ".sex", ".adult" };

    // ---------- SafeSearch ----------
    private static final Pattern GOOGLE = Pattern.compile("(www\\.)?google\\.(com|[a-z]{2}|(co|com)\\.[a-z]{2})");

    /** Qidiruv tizimi bo'lsa, xavfsiz qidiruv serveri nomi (aks holda null) */
    static String safeTarget(String domain) {
        if (domain == null) return null;
        String d = domain.toLowerCase(Locale.ROOT);
        if (d.endsWith(".")) d = d.substring(0, d.length() - 1);
        if (GOOGLE.matcher(d).matches()) return "forcesafesearch.google.com";
        if (d.equals("bing.com") || d.equals("www.bing.com")) return "strict.bing.com";
        if (d.equals("duckduckgo.com") || d.equals("www.duckduckgo.com")) return "safe.duckduckgo.com";
        return null;
    }

    /** Server nomini topib bo'lmasa ishlatiladigan zaxira manzil (yoki null) */
    static byte[] staticIp(String target) {
        if ("forcesafesearch.google.com".equals(target)) return new byte[] { (byte) 216, (byte) 239, 38, 120 };
        if ("strict.bing.com".equals(target)) return new byte[] { (byte) 204, 79, (byte) 197, (byte) 220 };
        return null;
    }

    /** A turidagi DNS so'rovi paketi */
    static byte[] buildQuery(String name) {
        java.io.ByteArrayOutputStream b = new java.io.ByteArrayOutputStream();
        int id = (int) (System.nanoTime() & 0xFFFF);
        b.write(id >> 8); b.write(id & 0xFF);
        b.write(0x01); b.write(0x00);       // RD
        b.write(0); b.write(1);             // QDCOUNT=1
        b.write(0); b.write(0); b.write(0); b.write(0); b.write(0); b.write(0);
        for (String label : name.split("\\.")) {
            b.write(label.length());
            for (int i = 0; i < label.length(); i++) b.write(label.charAt(i));
        }
        b.write(0);
        b.write(0); b.write(1);             // TYPE A
        b.write(0); b.write(1);             // CLASS IN
        return b.toByteArray();
    }

    private static int skipName(byte[] b, int pos) {
        while (pos < b.length) {
            int l = b[pos] & 0xFF;
            if (l == 0) return pos + 1;
            if ((l & 0xC0) == 0xC0) return pos + 2;
            pos += l + 1;
        }
        return -1;
    }

    /** Javobdagi A yozuvlari (IPv4 manzillar) */
    static List<byte[]> aRecords(byte[] r) {
        List<byte[]> out = new ArrayList<byte[]>();
        try {
            if (r == null || r.length < 12) return out;
            int qd = ((r[4] & 0xFF) << 8) | (r[5] & 0xFF);
            int an = ((r[6] & 0xFF) << 8) | (r[7] & 0xFF);
            int pos = 12;
            for (int i = 0; i < qd; i++) { pos = skipName(r, pos); if (pos < 0) return out; pos += 4; }
            for (int i = 0; i < an; i++) {
                pos = skipName(r, pos);
                if (pos < 0 || pos + 10 > r.length) return out;
                int type = ((r[pos] & 0xFF) << 8) | (r[pos + 1] & 0xFF);
                int rdlen = ((r[pos + 8] & 0xFF) << 8) | (r[pos + 9] & 0xFF);
                pos += 10;
                if (pos + rdlen > r.length) return out;
                if (type == 1 && rdlen == 4) out.add(new byte[] { r[pos], r[pos + 1], r[pos + 2], r[pos + 3] });
                pos += rdlen;
            }
        } catch (Throwable ignored) { }
        return out;
    }

    /** Asl savolga A javobi (berilgan manzillar bilan) */
    static byte[] answerA(byte[] q, List<byte[]> ips) {
        int end = questionEnd(q);
        if (end < 0 || ips.isEmpty()) return null;
        int n = Math.min(ips.size(), 8);
        byte[] r = new byte[end + n * 16];
        System.arraycopy(q, 0, r, 0, end);
        r[2] = (byte) (0x80 | (q[2] & 0x01));
        r[3] = (byte) 0x80;                 // RA=1, RCODE=0
        r[6] = 0; r[7] = (byte) n;          // ANCOUNT
        r[8] = 0; r[9] = 0; r[10] = 0; r[11] = 0;
        int p = end;
        for (int i = 0; i < n; i++) {
            r[p++] = (byte) 0xC0; r[p++] = 0x0C;     // nom: savoldan nusxa
            r[p++] = 0; r[p++] = 1;                   // TYPE A
            r[p++] = 0; r[p++] = 1;                   // CLASS IN
            r[p++] = 0; r[p++] = 0; r[p++] = 0; r[p++] = 60;   // TTL 60 s
            r[p++] = 0; r[p++] = 4;
            System.arraycopy(ips.get(i), 0, r, p, 4);
            p += 4;
        }
        return r;
    }

    /** "Yozuv yo'q" (xato emas): AAAA, HTTPS kabi turlar uchun, shunda mijoz IPv4 ga o'tadi */
    static byte[] nodata(byte[] q) {
        int end = questionEnd(q);
        if (end < 0) return null;
        byte[] r = new byte[end];
        System.arraycopy(q, 0, r, 0, end);
        r[2] = (byte) (0x80 | (q[2] & 0x01));
        r[3] = (byte) 0x80;
        r[6] = 0; r[7] = 0; r[8] = 0; r[9] = 0; r[10] = 0; r[11] = 0;
        return r;
    }

    static boolean blocked(String domain) {
        if (domain == null || domain.isEmpty()) return false;
        String d = domain.toLowerCase(Locale.ROOT);
        if (d.endsWith(".")) d = d.substring(0, d.length() - 1);
        for (String t : TLDS) if (d.endsWith(t)) return true;
        for (String s : STEMS) if (d.contains(s)) return true;
        for (String part : d.split("[.\\-_]")) {
            for (String t : TOKENS) if (part.equals(t)) return true;
        }
        return false;
    }

    /** DNS so'rovidagi domen nomi (yoki null) */
    static String qname(byte[] q) {
        if (q == null || q.length < 13) return null;
        StringBuilder b = new StringBuilder();
        int pos = 12;
        while (pos < q.length) {
            int l = q[pos] & 0xFF;
            if (l == 0) return b.toString();
            if ((l & 0xC0) != 0 || pos + 1 + l > q.length) return null;
            if (b.length() > 0) b.append('.');
            for (int i = 0; i < l; i++) b.append((char) (q[pos + 1 + i] & 0xFF));
            pos += l + 1;
        }
        return null;
    }

    /** Savol qismi tugaydigan joy (QNAME + QTYPE + QCLASS), yoki -1 */
    static int questionEnd(byte[] q) {
        int pos = 12;
        while (pos < q.length) {
            int l = q[pos] & 0xFF;
            if (l == 0) return (pos + 1 + 4 <= q.length) ? pos + 1 + 4 : -1;
            if ((l & 0xC0) != 0) return -1;
            pos += l + 1;
        }
        return -1;
    }

    /** "Bunday domen yo'q" (NXDOMAIN) javobi */
    static byte[] nxdomain(byte[] q) {
        int end = questionEnd(q);
        if (end < 0) return null;
        byte[] r = new byte[end];
        System.arraycopy(q, 0, r, 0, end);
        r[2] = (byte) (0x80 | (q[2] & 0x01));   // QR=1, RD saqlanadi
        r[3] = (byte) 0x83;                      // RA=1, RCODE=3
        r[6] = 0; r[7] = 0; r[8] = 0; r[9] = 0; r[10] = 0; r[11] = 0;   // javob/qo'shimcha yozuvlar yo'q
        return r;
    }
}
