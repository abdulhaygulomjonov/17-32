package com.guard1732;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.app.ActivityManager;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Color;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.os.Build;
import android.graphics.Bitmap;
import android.hardware.HardwareBuffer;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.SystemClock;
import android.view.Display;
import java.util.concurrent.Executor;
import android.os.Looper;
import android.os.PowerManager;
import android.provider.Settings;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.FrameLayout;
import android.widget.TextView;

public class GuardAccessibilityService extends AccessibilityService {

    public static volatile GuardAccessibilityService instance;

    private final Handler main = new Handler(Looper.getMainLooper());
    private String lastApp;
    private volatile boolean busy = false;
    private boolean scanScheduled = false;
    private long lastTextScan = 0;
    private View overlay;

    private final Runnable limitLoop = new Runnable() {
        @Override public void run() {
            try { checkLimits(); } catch (Exception ignored) { }
            // matn tekshiruvi hodisasiz ham: ekranda turgan so'z ham topiladi
            try { tamperCheck(); } catch (Exception ignored) { }
            try { vpnWatch(); } catch (Exception ignored) { }
            if (System.currentTimeMillis() - lastTextScan >= 400) {
                lastTextScan = System.currentTimeMillis();
                try { textScan(); } catch (Exception ignored) { }
            }
            main.postDelayed(this, 500);
        }
    };

    @Override
    protected void onServiceConnected() {
        instance = this;
        main.removeCallbacks(limitLoop);
        main.postDelayed(limitLoop, 500);
        // Android 11+: ekran tekshiruvi Accessibility orqali, ruxsat so'ramasdan, qayta yoqilganda o'zi ishga tushadi
        if (Build.VERSION.SDK_INT >= 30 && Restore.armed(this)) startShots();
        // qayta yoqilgandan keyin tizim xizmatni o'zi ulaydi, lekin ekran yozuvi o'chiq qoladi
        main.postDelayed(new Runnable() {
            @Override public void run() { Restore.remind(GuardAccessibilityService.this, "accessibility ulandi"); }
        }, 4000);
    }

    @Override
    public boolean onUnbind(Intent intent) {
        stopShots();
        instance = null;
        main.removeCallbacks(limitLoop);
        return super.onUnbind(intent);
    }


    // ---- Screenshot rejimi (Android 11+): MediaProjection ham, ruxsat oynasi ham kerak emas ----
    public static volatile boolean shotsActive = false;
    private HandlerThread shotThread;
    private Handler shotH;
    private FrameGuard guard;
    private long pausedUntil = 0;
    private int shotFails = 0;

    public void startShots() {
        if (Build.VERSION.SDK_INT < 30 || shotsActive) return;
        shotsActive = true;
        shotFails = 0;
        ScreenCaptureService.lastError = "";
        shotThread = new HandlerThread("guard-shot");
        shotThread.start();
        shotH = new Handler(shotThread.getLooper());
        shotH.post(new Runnable() {
            @Override public void run() {
                try {
                    guard = new FrameGuard(GuardAccessibilityService.this);
                } catch (Throwable t) {
                    ScreenCaptureService.lastError = "model: " + t.getClass().getSimpleName() + " " + t.getMessage();
                    Dbg.step(GuardAccessibilityService.this, "XATO " + ScreenCaptureService.lastError);
                    main.post(new Runnable() { @Override public void run() { stopShots(); } });
                    return;
                }
                Dbg.step(GuardAccessibilityService.this, "screenshot rejimi ishlayapti");
                shotH.post(shotTick);
            }
        });
    }

    public void stopShots() {
        shotsActive = false;
        try { if (shotH != null) shotH.removeCallbacksAndMessages(null); } catch (Throwable ignored) { }
        try { if (shotThread != null) shotThread.quitSafely(); } catch (Throwable ignored) { }
        shotThread = null;
        shotH = null;
        FrameGuard g = guard;
        guard = null;
        if (g != null) g.close();
    }

    private long lastTamper = 0;
    private long lastVpnTry = 0;

    /** DNS filtr (VPN) o'chib qolsa, qayta yoqadi; ruxsat yo'qolgan bo'lsa (boshqa VPN yoqilgan) eslatma chiqaradi */
    private void vpnWatch() {
        if (!Tamper.active(this) || GuardVpnService.running) return;
        long now = SystemClock.elapsedRealtime();
        if (now - lastVpnTry < 10000) return;
        lastVpnTry = now;
        try {
            if (android.net.VpnService.prepare(this) == null) {
                startService(new Intent(this, GuardVpnService.class));
            } else {
                Restore.vpnRemind(this);
            }
        } catch (Throwable t) {
            Dbg.step(this, "VPN tiklash xato: " + t);
        }
    }

    /** Sozlamalarda sana/vaqt, zavod tiklash va ilovani to'xtatish/o'chirish sahifalarini yopadi */
    private void tamperCheck() {
        if (!Tamper.active(this)) return;
        long now = SystemClock.elapsedRealtime();
        if (now - lastTamper < 150) return;
        lastTamper = now;
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null || root.getPackageName() == null) return;
        String pk = root.getPackageName().toString();
        if (!Tamper.isSystemUi(pk)) return;
        String why = Tamper.reason(pk, Tamper.collect(root));
        if (why != null) {
            Dbg.step(this, "himoya: " + why + " yopildi");
            performGlobalAction(GLOBAL_ACTION_HOME);
            android.widget.Toast.makeText(this, "Bu sahifa parol bilan himoyalangan", android.widget.Toast.LENGTH_SHORT).show();
        }
    }

    private void nextShot(long delay) {
        Handler h = shotH;
        if (shotsActive && h != null) h.postDelayed(shotTick, delay);
    }

    private final Runnable shotTick = new Runnable() {
        @Override public void run() {
            if (!shotsActive || Build.VERSION.SDK_INT < 30) return;
            long now = SystemClock.elapsedRealtime();
            PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
            if ((pm != null && !pm.isInteractive()) || busy || now < pausedUntil) { nextShot(500); return; }
            try {
                takeScreenshot(Display.DEFAULT_DISPLAY, new Executor() {
                    @Override public void execute(Runnable r) {
                        Handler h = shotH;
                        if (h != null) h.post(r);
                    }
                }, new TakeScreenshotCallback() {
                    @Override public void onSuccess(ScreenshotResult r) {
                        shotFails = 0;
                        try { handleShot(r); } catch (Throwable t) { Dbg.step(GuardAccessibilityService.this, "kadr xato: " + t); }
                        nextShot(350);
                    }
                    @Override public void onFailure(int code) {
                        if (code == 3) { nextShot(450); return; }   // so'rovlar orasi qisqa
                        shotFails++;
                        // himoyalangan oyna (FLAG_SECURE) ba'zi versiyalarda xato qaytaradi
                        if (shotFails >= 3) protectedBlack(shotFails >= 8);
                        nextShot(1000);
                    }
                });
            } catch (Throwable t) {
                nextShot(1500);
            }
        }
    };

    private void handleShot(ScreenshotResult r) {
        HardwareBuffer hb = r.getHardwareBuffer();
        Bitmap soft = null;
        try {
            Bitmap hw = Bitmap.wrapHardwareBuffer(hb, r.getColorSpace());
            if (hw != null) { soft = hw.copy(Bitmap.Config.ARGB_8888, false); hw.recycle(); }
        } finally {
            try { hb.close(); } catch (Throwable ignored) { }
        }
        FrameGuard g = guard;
        if (soft == null || g == null) return;
        long now = SystemClock.elapsedRealtime();
        if (g.process(soft, now)) {
            pausedUntil = now + 5000;
            trigger(g.firedSystem());
        }
    }

    @Override
    public void onInterrupt() { }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent e) {
        if (e == null) return;
        int type = e.getEventType();
        CharSequence cs = e.getPackageName();
        if (cs == null) return;
        String p = cs.toString();
        if (Tamper.isSystemUi(p)) tamperCheck();
        if (isIgnored(p)) return;

        if (type == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            lastApp = p;
            if (AppLimits.isOver(this, p)) { blockLimit(p); return; }
        }
        // 4-tizim: sahifa o'zgarsa yoki qidiruvga yozilsa tekshiramiz (zich chaqirilmasligi uchun kechiktiriladi)
        if (type == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED
                || type == AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED
                || type == AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED) {
            scheduleTextScan();
        }
    }


    private void scheduleTextScan() {
        if (scanScheduled || busy) return;
        scanScheduled = true;
        long wait = Math.max(250L, 500L - (System.currentTimeMillis() - lastTextScan));
        main.postDelayed(new Runnable() {
            @Override public void run() {
                scanScheduled = false;
                lastTextScan = System.currentTimeMillis();
                try { textScan(); } catch (Exception ignored) { }
            }
        }, wait);
    }

    /** 4-tizim: brauzer va veb-oynalardagi manzil, qidiruv va sahifa matni */
    private void textScan() {
        if (busy) return;
        PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
        if (pm != null && !pm.isInteractive()) return;
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null || root.getPackageName() == null) return;
        String p = root.getPackageName().toString();
        if (isIgnored(p)) return;
        DisplayMetrics dm = getResources().getDisplayMetrics();
        if (TextGuard.check(root, p, dm.heightPixels)) {
            busy = true;
            closeAndRemoveFromRecents(p, "4-tizim orqali nomaqbul kontent aniqlandi");
        }
    }

    /** Har 5 soniyada: ekrandagi ilova kunlik limitga yetganmi */
    private void checkLimits() {
        if (busy) return;
        PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
        if (pm != null && !pm.isInteractive()) return;
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null || root.getPackageName() == null) return;
        String p = root.getPackageName().toString();
        if (isIgnored(p)) return;
        if (AppLimits.isOver(this, p)) blockLimit(p);
    }

    /** Limit tugagan ilovani yopadi va "yaqinda kirilganlar"dan ham olib tashlaydi */
    private void blockLimit(final String pkg) {
        if (busy) return;
        busy = true;
        closeAndRemoveFromRecents(pkg, "Kunlik limit tugadi");
    }

    /**
     * Ilovani yopadi, processini o'ldiradi va recents (yaqinda kirilganlar)
     * ekranidan swipe bilan olib tashlaydi. busy=true holatda chaqiriladi.
     */
    private void closeAndRemoveFromRecents(final String target, String text) {
        showOverlay(text);
        performGlobalAction(GLOBAL_ACTION_HOME);

        main.postDelayed(new Runnable() {
            @Override public void run() {
                if (target != null) {
                    ((ActivityManager) getSystemService(ACTIVITY_SERVICE))
                            .killBackgroundProcesses(target);
                }
            }
        }, 150);
        main.postDelayed(new Runnable() {
            @Override public void run() {
                if (target != null) performGlobalAction(GLOBAL_ACTION_RECENTS);
            }
        }, 350);
        main.postDelayed(new Runnable() {
            @Override public void run() {
                if (target != null) swipeUp();
            }
        }, 1100);
        main.postDelayed(new Runnable() {
            @Override public void run() { performGlobalAction(GLOBAL_ACTION_HOME); }
        }, 1600);
        main.postDelayed(new Runnable() {
            @Override public void run() { hideOverlay(); busy = false; }
        }, 1900);
    }

    private String launcherPkg() {
        Intent i = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME);
        ResolveInfo ri = getPackageManager().resolveActivity(i, PackageManager.MATCH_DEFAULT_ONLY);
        return (ri != null && ri.activityInfo != null) ? ri.activityInfo.packageName : null;
    }

    private String imePkg() {
        String s = Settings.Secure.getString(getContentResolver(), Settings.Secure.DEFAULT_INPUT_METHOD);
        if (s == null) return null;
        int k = s.indexOf('/');
        return k > 0 ? s.substring(0, k) : s;
    }

    private boolean isIgnored(String p) {
        return p.equals(getPackageName()) || p.equals("com.android.systemui")
                || p.equals(launcherPkg()) || p.equals(imePkg());
    }

    /** Hozir ekranda turgan (buzuvchi) ilova paketi, yoki null */
    private String currentTarget() {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        String cur = (root != null && root.getPackageName() != null)
                ? root.getPackageName().toString() : null;
        if (cur == null) return lastApp;
        if (isIgnored(cur)) return null;
        return cur;
    }

    /** ScreenCaptureService chaqiradi. system: 1, 2 yoki 3 (0 = eski model) */
    public void trigger(final int system) {
        main.post(new Runnable() {
            @Override public void run() {
                if (busy) return;
                busy = true;
                String text = system > 0
                        ? system + "-tizim orqali nomaqbul kontent aniqlandi"
                        : "Zaxira model (nsfw) orqali nomaqbul kontent aniqlandi";
                closeAndRemoveFromRecents(currentTarget(), text);
            }
        });
    }

    /** ScreenCaptureService chaqiradi: ekran yozuvi qora (himoyalangan oyna). longRun = uzoq davom etdi */
    public void protectedBlack(final boolean longRun) {
        main.post(new Runnable() {
            @Override public void run() {
                if (busy) return;
                AccessibilityNodeInfo root = getRootInActiveWindow();
                if (root == null || root.getPackageName() == null) return;
                String p = root.getPackageName().toString();
                if (isIgnored(p)) return;
                if (TextGuard.protectedMedia(root, p, getResources().getDisplayMetrics().heightPixels)) {
                    busy = true;
                    closeAndRemoveFromRecents(p, "Himoyalangan oyna: rasm tekshirib bo'lmaydi");
                }
            }
        });
    }

    private void swipeUp() {
        DisplayMetrics dm = getResources().getDisplayMetrics();
        Path path = new Path();
        path.moveTo(dm.widthPixels / 2f, dm.heightPixels * 0.55f);
        path.lineTo(dm.widthPixels / 2f, dm.heightPixels * 0.08f);
        GestureDescription g = new GestureDescription.Builder()
                .addStroke(new GestureDescription.StrokeDescription(path, 0, 180))
                .build();
        dispatchGesture(g, null, null);
    }

    private void showOverlay(String text) {
        if (overlay != null) return;
        WindowManager wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextColor(Color.WHITE);
        tv.setTextSize(18f);
        tv.setGravity(Gravity.CENTER);
        FrameLayout frame = new FrameLayout(this);
        frame.setBackgroundColor(Color.BLACK);
        frame.addView(tv, new FrameLayout.LayoutParams(-1, -1));
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.OPAQUE);
        if (Build.VERSION.SDK_INT >= 28) {
            lp.layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        }
        try { wm.addView(frame, lp); overlay = frame; } catch (Exception ignored) { }
    }

    private void hideOverlay() {
        if (overlay == null) return;
        try { ((WindowManager) getSystemService(WINDOW_SERVICE)).removeView(overlay); }
        catch (Exception ignored) { }
        overlay = null;
    }
}
