package com.guard1732;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.app.ActivityManager;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Color;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.provider.Settings;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.FrameLayout;
import android.widget.TextView;

public class GuardAccessibilityService extends AccessibilityService {

    public static volatile GuardAccessibilityService instance;

    private final Handler main = new Handler(Looper.getMainLooper());
    private String lastApp;
    private boolean busy = false;
    private View overlay;

    private final Runnable limitLoop = new Runnable() {
        @Override public void run() {
            try { checkLimits(); } catch (Exception ignored) { }
            main.postDelayed(this, 5000);
        }
    };

    @Override
    protected void onServiceConnected() {
        instance = this;
        main.removeCallbacks(limitLoop);
        main.postDelayed(limitLoop, 5000);
    }

    @Override
    public boolean onUnbind(Intent intent) {
        instance = null;
        main.removeCallbacks(limitLoop);
        return super.onUnbind(intent);
    }

    @Override
    public void onInterrupt() { }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent e) {
        if (e == null || e.getEventType() != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return;
        CharSequence cs = e.getPackageName();
        if (cs == null) return;
        String p = cs.toString();
        if (!isIgnored(p)) {
            lastApp = p;
            if (AppLimits.isOver(this, p)) blockLimit(p);
        }
    }

    /** Har 5 soniyada: ekrandagi ilova kunlik limitga yetganmi */
    private void checkLimits() {
        if (busy) return;
        PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
        if (pm != null && !pm.isInteractive()) return;
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null || root.getPackageName() == null) return;
        String p = root.getPackageName().toString();
        if (isIgnored(p)) return;
        if (AppLimits.isOver(this, p)) blockLimit(p);
    }

    /** Limit tugagan ilovani yopadi */
    private void blockLimit(final String pkg) {
        if (busy) return;
        busy = true;
        showOverlay("Kunlik limit tugadi");
        performGlobalAction(GLOBAL_ACTION_HOME);
        main.postDelayed(new Runnable() {
            @Override public void run() {
                ((ActivityManager) getSystemService(ACTIVITY_SERVICE)).killBackgroundProcesses(pkg);
            }
        }, 150);
        main.postDelayed(new Runnable() {
            @Override public void run() { hideOverlay(); busy = false; }
        }, 1200);
    }

    private String launcherPkg() {
        Intent i = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME);
        ResolveInfo ri = getPackageManager().resolveActivity(i, PackageManager.MATCH_DEFAULT_ONLY);
        return (ri != null && ri.activityInfo != null) ? ri.activityInfo.packageName : null;
    }

    private String imePkg() {
        String s = Settings.Secure.getString(getContentResolver(), Settings.Secure.DEFAULT_INPUT_METHOD);
        if (s == null) return null;
        int k = s.indexOf('/');
        return k > 0 ? s.substring(0, k) : s;
    }

    private boolean isIgnored(String p) {
        return p.equals(getPackageName()) || p.equals("com.android.systemui")
                || p.equals(launcherPkg()) || p.equals(imePkg());
    }

    /** Hozir ekranda turgan (buzuvchi) ilova paketi, yoki null */
    private String currentTarget() {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        String cur = (root != null && root.getPackageName() != null)
                ? root.getPackageName().toString() : null;
        if (cur == null) return lastApp;
        if (isIgnored(cur)) return null;
        return cur;
    }

    /** ScreenCaptureService chaqiradi */
    public void trigger() {
        main.post(new Runnable() {
            @Override public void run() {
                if (busy) return;
                busy = true;
                final String target = currentTarget();
                showOverlay("Nomaqbul kontent aniqlandi");
                performGlobalAction(GLOBAL_ACTION_HOME);

                main.postDelayed(new Runnable() {
                    @Override public void run() {
                        if (target != null) {
                            ((ActivityManager) getSystemService(ACTIVITY_SERVICE))
                                    .killBackgroundProcesses(target);
                        }
                    }
                }, 150);
                main.postDelayed(new Runnable() {
                    @Override public void run() {
                        if (target != null) performGlobalAction(GLOBAL_ACTION_RECENTS);
                    }
                }, 350);
                main.postDelayed(new Runnable() {
                    @Override public void run() {
                        if (target != null) swipeUp();
                    }
                }, 1100);
                main.postDelayed(new Runnable() {
                    @Override public void run() { performGlobalAction(GLOBAL_ACTION_HOME); }
                }, 1600);
                main.postDelayed(new Runnable() {
                    @Override public void run() { hideOverlay(); busy = false; }
                }, 1900);
            }
        });
    }

    private void swipeUp() {
        DisplayMetrics dm = getResources().getDisplayMetrics();
        Path path = new Path();
        path.moveTo(dm.widthPixels / 2f, dm.heightPixels * 0.55f);
        path.lineTo(dm.widthPixels / 2f, dm.heightPixels * 0.08f);
        GestureDescription g = new GestureDescription.Builder()
                .addStroke(new GestureDescription.StrokeDescription(path, 0, 180))
                .build();
        dispatchGesture(g, null, null);
    }

    private void showOverlay(String text) {
        if (overlay != null) return;
        WindowManager wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextColor(Color.WHITE);
        tv.setTextSize(18f);
        tv.setGravity(Gravity.CENTER);
        FrameLayout frame = new FrameLayout(this);
        frame.setBackgroundColor(Color.BLACK);
        frame.addView(tv, new FrameLayout.LayoutParams(-1, -1));
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.OPAQUE);
        if (Build.VERSION.SDK_INT >= 28) {
            lp.layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        }
        try { wm.addView(frame, lp); overlay = frame; } catch (Exception ignored) { }
    }

    private void hideOverlay() {
        if (overlay == null) return;
        try { ((WindowManager) getSystemService(WINDOW_SERVICE)).removeView(overlay); }
        catch (Exception ignored) { }
        overlay = null;
    }
}
