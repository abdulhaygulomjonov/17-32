package com.guard1732;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent i) {
        String a = i == null ? null : i.getAction();
        Dbg.step(c, "qabul: " + a);
        Restore.remind(c, "telefon qayta yoqildi");
    }
}
