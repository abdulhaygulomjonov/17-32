package com.guard1732;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent i) {
        String a = i == null ? null : i.getAction();
        Dbg.step(c, "qabul: " + a);
        if (Restore.armed(c)) {
            try {   // DNS filtr: ruxsat saqlangan bo'lsa o'zi yonadi
                if (android.net.VpnService.prepare(c) == null) c.startService(new Intent(c, GuardVpnService.class));
            } catch (Throwable t) {
                Dbg.step(c, "VPN boot xato: " + t);
            }
        }
        Restore.remind(c, "telefon qayta yoqildi");
    }
}
