package com.guard1732;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.provider.Settings;

/** Telefon qayta yoqilgandan keyin himoyani tiklash: ekran yozish ruxsati har safar qayta so'raladi. */
public class Restore {
    static final int NOTIF_ID = 2;
    private static volatile long lastRoot = -100000;

    private static SharedPreferences sp(Context c) {
        return c.getSharedPreferences("guard", Context.MODE_PRIVATE);
    }

    /** Foydalanuvchi himoyani yoqqan (to'xtatmagan) bo'lsa true */
    public static boolean armed(Context c) { return sp(c).getBoolean("armed", false); }
    public static void setArmed(Context c, boolean v) { sp(c).edit().putBoolean("armed", v).commit(); }

    /** Himoya o'chiq, lekin yoqilgan bo'lishi kerak: ilovani ochadi va bildirishnoma chiqaradi */
    public static void remind(Context c, String why) {
        try {
            if (android.os.Build.VERSION.SDK_INT >= 30) return;   // 11+: Accessibility screenshot rejimi o'zi tiklanadi
            if (!armed(c) || ScreenCaptureService.running) return;
            Dbg.step(c, "tiklash: " + why);
            // 1) root bor bo'lsa: so'rovsiz, o'zi yoqadi
            final Context app = c.getApplicationContext();
            long now = android.os.SystemClock.elapsedRealtime();
            if (now - lastRoot > 20000) {
                lastRoot = now;
                new Thread(new Runnable() {
                    @Override public void run() {
                        boolean ok = Root.startCapture(app);
                        Dbg.step(app, "root orqali yoqish: " + ok);
                    }
                }, "guard-root").start();
            }
            // 2) zaxira: bildirishnoma (root bo'lmasa yoki ishlamasa)
            Intent open = new Intent(c, MainActivity.class)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP)
                    .putExtra("autostart", true);
            NotificationManager nm = c.getSystemService(NotificationManager.class);
            nm.createNotificationChannel(new NotificationChannel(
                    "guard_restore", "17-32 tiklash", NotificationManager.IMPORTANCE_HIGH));
            PendingIntent pi = PendingIntent.getActivity(c, 7, open,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            android.app.Notification n = new android.app.Notification.Builder(c, "guard_restore")
                    .setContentTitle("17-32 o'chiq")
                    .setContentText("Himoyani yoqish uchun bosing")
                    .setSmallIcon(android.R.drawable.ic_lock_idle_lock)
                    .setContentIntent(pi)
                    .setAutoCancel(true)
                    .setOngoing(true)
                    .build();
            nm.notify(NOTIF_ID, n);
            // "Boshqa ilovalar ustida" ruxsati bor bo'lsa, fondan ilovani to'g'ridan-to'g'ri ochish mumkin
            if (Settings.canDrawOverlays(c)) c.startActivity(open);
        } catch (Throwable t) {
            Dbg.step(c, "tiklash xato: " + t);
        }
    }

    private static long lastVpnNote = 0;

    /** DNS filtr o'chdi va ruxsat yo'qolgan: ilovani ochib qayta yoqish uchun bildirishnoma */
    public static void vpnRemind(Context c) {
        try {
            long now = android.os.SystemClock.elapsedRealtime();
            if (lastVpnNote != 0 && now - lastVpnNote < 60000) return;
            lastVpnNote = now;
            Intent open = new Intent(c, MainActivity.class)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            NotificationManager nm = c.getSystemService(NotificationManager.class);
            nm.createNotificationChannel(new NotificationChannel(
                    "guard_restore", "17-32 tiklash", NotificationManager.IMPORTANCE_HIGH));
            PendingIntent pi = PendingIntent.getActivity(c, 8, open,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            nm.notify(3, new android.app.Notification.Builder(c, "guard_restore")
                    .setContentTitle("17-32: DNS himoya o'chdi")
                    .setContentText("Qayta yoqish uchun bosing")
                    .setSmallIcon(android.R.drawable.ic_lock_idle_lock)
                    .setContentIntent(pi).setAutoCancel(true).build());
            Dbg.step(c, "VPN ruxsati yo'qolgan: eslatma");
        } catch (Throwable t) {
            Dbg.step(c, "vpnRemind xato: " + t);
        }
    }

    public static void clear(Context c) {
        try { c.getSystemService(NotificationManager.class).cancel(NOTIF_ID); } catch (Throwable ignored) { }
    }
}
