package com.guard1732;

import android.app.admin.DeviceAdminReceiver;
import android.content.Context;
import android.content.Intent;

/** Qurilma administratori: yoqiq bo'lsa ilovani odatiy usulda o'chirib bo'lmaydi. */
public class GuardAdminReceiver extends DeviceAdminReceiver {
    @Override
    public CharSequence onDisableRequested(Context c, Intent i) {
        return "17-32 himoyasi faqat parol bilan o'chiriladi.";
    }

    @Override
    public void onEnabled(Context c, Intent i) { Dbg.step(c, "qurilma administratori yoqildi"); }

    @Override
    public void onDisabled(Context c, Intent i) { Dbg.step(c, "qurilma administratori o'chirildi"); }
}
