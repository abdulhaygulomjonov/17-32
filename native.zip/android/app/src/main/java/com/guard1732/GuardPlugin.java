package com.guard1732;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.projection.MediaProjectionManager;
import android.provider.Settings;

import androidx.activity.result.ActivityResult;
import androidx.core.content.ContextCompat;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.ActivityCallback;
import com.getcapacitor.annotation.CapacitorPlugin;

@CapacitorPlugin(name = "Guard")
public class GuardPlugin extends Plugin {

    private SharedPreferences prefs() {
        return getContext().getSharedPreferences("guard", Context.MODE_PRIVATE);
    }

    @PluginMethod
    public void getStatus(PluginCall call) {
        JSObject r = new JSObject();
        r.put("accessibility", GuardAccessibilityService.instance != null);
        r.put("model", NsfwClassifier.modelExists(getContext()));
        r.put("running", ScreenCaptureService.running);
        r.put("threshold", prefs().getInt("thr", 70));
        call.resolve(r);
    }

    @PluginMethod
    public void openAccessibility(PluginCall call) {
        Intent i = new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        getContext().startActivity(i);
        call.resolve();
    }

    @PluginMethod
    public void startProtection(PluginCall call) {
        if (GuardAccessibilityService.instance == null) { call.reject("accessibility"); return; }
        if (!NsfwClassifier.modelExists(getContext())) { call.reject("model"); return; }
        MediaProjectionManager mpm = (MediaProjectionManager)
                getContext().getSystemService(Context.MEDIA_PROJECTION_SERVICE);
        startActivityForResult(call, mpm.createScreenCaptureIntent(), "captureResult");
    }

    @ActivityCallback
    private void captureResult(PluginCall call, ActivityResult result) {
        if (call == null) return;
        if (result.getResultCode() == Activity.RESULT_OK && result.getData() != null) {
            Intent i = new Intent(getContext(), ScreenCaptureService.class)
                    .putExtra("code", result.getResultCode())
                    .putExtra("data", result.getData());
            ContextCompat.startForegroundService(getContext(), i);
            call.resolve();
        } else {
            call.reject("denied");
        }
    }

    @PluginMethod
    public void stopProtection(PluginCall call) {
        getContext().stopService(new Intent(getContext(), ScreenCaptureService.class));
        call.resolve();
    }

    @PluginMethod
    public void setThreshold(PluginCall call) {
        Integer v = call.getInt("value");
        if (v == null) { call.reject("value"); return; }
        int t = Math.max(50, Math.min(95, v));
        prefs().edit().putInt("thr", t).apply();
        call.resolve();
    }
}
