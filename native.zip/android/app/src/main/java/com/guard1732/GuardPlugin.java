package com.guard1732;

import android.app.Activity;
import android.app.AppOpsManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.PowerManager;
import android.provider.Settings;

import androidx.activity.result.ActivityResult;
import androidx.core.app.NotificationManagerCompat;
import androidx.core.content.ContextCompat;

import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;

import org.json.JSONObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.ActivityCallback;
import com.getcapacitor.annotation.CapacitorPlugin;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

@CapacitorPlugin(name = "Guard")
public class GuardPlugin extends Plugin {

    private SharedPreferences prefs() {
        return getContext().getSharedPreferences("guard", Context.MODE_PRIVATE);
    }

    @PluginMethod
    public void getStatus(PluginCall call) {
        JSObject r = new JSObject();
        r.put("accessibility", GuardAccessibilityService.instance != null);
        r.put("model", NsfwClassifier.modelExists(getContext()));
        r.put("running", ScreenCaptureService.running);
        r.put("threshold", 60);
        r.put("usage", AppLimits.hasUsageAccess(getContext()));
        r.put("m1", true);
        r.put("m2", true);
        r.put("m3", true);
        r.put("detector", NudeDetector.modelExists(getContext()));
        r.put("error", ScreenCaptureService.lastError);
        call.resolve(r);
    }

    /** Xiaomi/HyperOS: "Fonda ochiladigan oynalar" (OP 10021). true/false, bilib bo'lmasa null */
    private Boolean bgPopupAllowed() {
        try {
            Context c = getContext();
            AppOpsManager ops = (AppOpsManager) c.getSystemService(Context.APP_OPS_SERVICE);
            java.lang.reflect.Method m = AppOpsManager.class.getMethod(
                    "checkOpNoThrow", int.class, int.class, String.class);
            int r = ((Integer) m.invoke(ops, 10021, android.os.Process.myUid(), c.getPackageName())).intValue();
            return Boolean.valueOf(r == AppOpsManager.MODE_ALLOWED);
        } catch (Throwable t) {
            return null;
        }
    }

    @PluginMethod
    public void getPermissions(PluginCall call) {
        Context c = getContext();
        JSObject r = new JSObject();
        r.put("accessibility", GuardAccessibilityService.instance != null);
        r.put("notifications", NotificationManagerCompat.from(c).areNotificationsEnabled());
        r.put("overlay", Settings.canDrawOverlays(c));
        PowerManager pm = (PowerManager) c.getSystemService(Context.POWER_SERVICE);
        r.put("battery", pm != null && pm.isIgnoringBatteryOptimizations(c.getPackageName()));
        r.put("usage", AppLimits.hasUsageAccess(c));
        Boolean bg = bgPopupAllowed();
        r.put("bgpopup", bg == null ? JSONObject.NULL : bg);
        String mf = String.valueOf(Build.MANUFACTURER).toLowerCase();
        r.put("xiaomi", mf.contains("xiaomi") || mf.contains("redmi") || mf.contains("poco"));
        call.resolve(r);
    }

    private void launch(Intent i) {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        getContext().startActivity(i);
    }

    private Intent appDetails() {
        return new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                Uri.parse("package:" + getContext().getPackageName()));
    }

    @PluginMethod
    public void openPermission(PluginCall call) {
        String n = call.getString("name");
        String pkg = getContext().getPackageName();
        try {
            if ("accessibility".equals(n)) {
                launch(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
            } else if ("notifications".equals(n)) {
                launch(new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                        .putExtra(Settings.EXTRA_APP_PACKAGE, pkg));
            } else if ("overlay".equals(n)) {
                launch(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + pkg)));
            } else if ("battery".equals(n)) {
                try {
                    launch(new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                            Uri.parse("package:" + pkg)));
                } catch (Exception e) {
                    launch(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS));
                }
            } else if ("usage".equals(n)) {
                launch(new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS));
            } else if ("bgpopup".equals(n)) {
                try {
                    Intent i = new Intent("miui.intent.action.APP_PERM_EDITOR");
                    i.setClassName("com.miui.securitycenter",
                            "com.miui.permcenter.permissions.PermissionsEditorActivity");
                    i.putExtra("extra_pkgname", pkg);
                    launch(i);
                } catch (Exception e) {
                    launch(appDetails());
                }
            } else if ("autostart".equals(n)) {
                try {
                    Intent i = new Intent();
                    i.setComponent(new ComponentName("com.miui.securitycenter",
                            "com.miui.permcenter.autostart.AutoStartManagementActivity"));
                    launch(i);
                } catch (Exception e) {
                    launch(appDetails());
                }
            } else {
                launch(appDetails());
            }
            call.resolve();
        } catch (Exception e) {
            try { launch(appDetails()); call.resolve(); }
            catch (Exception e2) { call.reject(String.valueOf(e2.getMessage())); }
        }
    }

    @PluginMethod
    public void openAccessibility(PluginCall call) {
        Intent i = new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        getContext().startActivity(i);
        call.resolve();
    }

    @PluginMethod
    public void startProtection(PluginCall call) {
        if (ScreenCaptureService.running) { call.resolve(); return; }   // allaqachon yoqiq: qayta so'ramaymiz
        if (GuardAccessibilityService.instance == null) { call.reject("accessibility"); return; }
        if (!NsfwClassifier.modelExists(getContext())) { call.reject("model"); return; }
        MediaProjectionManager mpm = (MediaProjectionManager)
                getContext().getSystemService(Context.MEDIA_PROJECTION_SERVICE);
        startActivityForResult(call, mpm.createScreenCaptureIntent(), "captureResult");
    }

    @ActivityCallback
    private void captureResult(PluginCall call, ActivityResult result) {
        if (call == null) return;
        int rc = result.getResultCode();
        Intent data = result.getData();
        if (rc == Activity.RESULT_OK && data != null) {
            try {
                Intent i = new Intent(getContext(), ScreenCaptureService.class)
                        .putExtra("code", rc)
                        .putExtra("data", data);
                ContextCompat.startForegroundService(getContext(), i);
                call.resolve();
            } catch (Exception e) {
                call.reject("service: " + e.getClass().getSimpleName() + " " + e.getMessage());
            }
        } else {
            // rc: -1 = OK, 0 = bekor qilingan; data bo'sh bo'lsa tizim ruxsatni qaytarmagan
            call.reject("denied rc=" + rc + " data=" + (data != null));
        }
    }

    @PluginMethod
    public void stopProtection(PluginCall call) {
        getContext().stopService(new Intent(getContext(), ScreenCaptureService.class));
        call.resolve();
    }

    @PluginMethod
    public void openUsageAccess(PluginCall call) {
        Intent i = new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        getContext().startActivity(i);
        call.resolve();
    }

    @PluginMethod
    public void getApps(PluginCall call) {
        Context c = getContext();
        PackageManager pm = c.getPackageManager();
        Intent launcher = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> list = pm.queryIntentActivities(launcher, 0);
        Map<String, Integer> limits = AppLimits.getAll(c);
        Map<String, Long> usage = AppLimits.todayUsageMs(c);
        List<JSObject> items = new ArrayList<JSObject>();
        Set<String> seen = new HashSet<String>();
        for (ResolveInfo ri : list) {
            String p = ri.activityInfo.packageName;
            if (p.equals(c.getPackageName()) || !seen.add(p)) continue;
            JSObject o = new JSObject();
            o.put("pkg", p);
            o.put("name", String.valueOf(ri.loadLabel(pm)));
            Long ms = usage.get(p);
            o.put("usedSec", ms == null ? 0 : (int) (ms.longValue() / 1000L));
            Integer lim = limits.get(p);
            o.put("limit", lim == null ? 0 : lim.intValue());
            long lu = AppLimits.lockUntil(c, p);
            long left = lu == 0L ? 0L : lu - System.currentTimeMillis();
            o.put("lockLeftMs", left);
            items.add(o);
        }
        Collections.sort(items, new Comparator<JSObject>() {
            @Override
            public int compare(JSObject a, JSObject b) {
                int la = a.optInt("limit", 0) > 0 ? 0 : 1;
                int lb = b.optInt("limit", 0) > 0 ? 0 : 1;
                if (la != lb) return la - lb;
                int ua = a.optInt("usedSec", 0), ub = b.optInt("usedSec", 0);
                if (ua != ub) return ub - ua;
                return a.optString("name", "").compareToIgnoreCase(b.optString("name", ""));
            }
        });
        JSArray arr = new JSArray();
        for (JSObject o : items) arr.put(o);
        JSObject r = new JSObject();
        r.put("apps", arr);
        r.put("usage", AppLimits.hasUsageAccess(c));
        call.resolve(r);
    }

    @PluginMethod
    public void setLimit(PluginCall call) {
        String p = call.getString("pkg");
        Integer m = call.getInt("seconds");
        Integer d = call.getInt("days");
        if (p == null || m == null) { call.reject("value"); return; }
        long lu = AppLimits.lockUntil(getContext(), p);
        if (lu > 0L) { call.reject("locked"); return; }   // qulf tugamaguncha o'zgartirib bo'lmaydi
        int mins = Math.max(0, Math.min(24 * 3600, m.intValue()));
        if (mins > 0) {
            int days = d == null ? 0 : d.intValue();
            if (days != 7 && days != 21 && days != 40) { call.reject("days"); return; }
            AppLimits.setLimitLocked(getContext(), p, mins, days);
        } else {
            AppLimits.setLimitLocked(getContext(), p, 0, 0);
        }
        call.resolve();
    }
}
