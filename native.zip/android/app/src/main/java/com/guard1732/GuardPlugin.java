package com.guard1732;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.media.projection.MediaProjectionManager;
import android.provider.Settings;

import androidx.activity.result.ActivityResult;
import androidx.core.content.ContextCompat;

import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.ActivityCallback;
import com.getcapacitor.annotation.CapacitorPlugin;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

@CapacitorPlugin(name = "Guard")
public class GuardPlugin extends Plugin {

    private SharedPreferences prefs() {
        return getContext().getSharedPreferences("guard", Context.MODE_PRIVATE);
    }

    @PluginMethod
    public void getStatus(PluginCall call) {
        JSObject r = new JSObject();
        r.put("accessibility", GuardAccessibilityService.instance != null);
        r.put("model", NsfwClassifier.modelExists(getContext()));
        r.put("running", ScreenCaptureService.running);
        r.put("threshold", prefs().getInt("thr", 50));
        r.put("usage", AppLimits.hasUsageAccess(getContext()));
        call.resolve(r);
    }

    @PluginMethod
    public void openAccessibility(PluginCall call) {
        Intent i = new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        getContext().startActivity(i);
        call.resolve();
    }

    @PluginMethod
    public void startProtection(PluginCall call) {
        if (GuardAccessibilityService.instance == null) { call.reject("accessibility"); return; }
        if (!NsfwClassifier.modelExists(getContext())) { call.reject("model"); return; }
        MediaProjectionManager mpm = (MediaProjectionManager)
                getContext().getSystemService(Context.MEDIA_PROJECTION_SERVICE);
        startActivityForResult(call, mpm.createScreenCaptureIntent(), "captureResult");
    }

    @ActivityCallback
    private void captureResult(PluginCall call, ActivityResult result) {
        if (call == null) return;
        if (result.getResultCode() == Activity.RESULT_OK && result.getData() != null) {
            Intent i = new Intent(getContext(), ScreenCaptureService.class)
                    .putExtra("code", result.getResultCode())
                    .putExtra("data", result.getData());
            ContextCompat.startForegroundService(getContext(), i);
            call.resolve();
        } else {
            call.reject("denied");
        }
    }

    @PluginMethod
    public void stopProtection(PluginCall call) {
        getContext().stopService(new Intent(getContext(), ScreenCaptureService.class));
        call.resolve();
    }

    @PluginMethod
    public void setThreshold(PluginCall call) {
        Integer v = call.getInt("value");
        if (v == null) { call.reject("value"); return; }
        int t = Math.max(20, Math.min(95, v));
        prefs().edit().putInt("thr", t).apply();
        call.resolve();
    }

    @PluginMethod
    public void openUsageAccess(PluginCall call) {
        Intent i = new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        getContext().startActivity(i);
        call.resolve();
    }

    @PluginMethod
    public void getApps(PluginCall call) {
        Context c = getContext();
        PackageManager pm = c.getPackageManager();
        Intent launcher = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> list = pm.queryIntentActivities(launcher, 0);
        Map<String, Integer> limits = AppLimits.getAll(c);
        Map<String, Long> usage = AppLimits.todayUsageMs(c);
        List<JSObject> items = new ArrayList<JSObject>();
        Set<String> seen = new HashSet<String>();
        for (ResolveInfo ri : list) {
            String p = ri.activityInfo.packageName;
            if (p.equals(c.getPackageName()) || !seen.add(p)) continue;
            JSObject o = new JSObject();
            o.put("pkg", p);
            o.put("name", String.valueOf(ri.loadLabel(pm)));
            Long ms = usage.get(p);
            o.put("usedMin", ms == null ? 0 : (int) (ms.longValue() / 60000L));
            Integer lim = limits.get(p);
            o.put("limit", lim == null ? 0 : lim.intValue());
            items.add(o);
        }
        Collections.sort(items, new Comparator<JSObject>() {
            @Override
            public int compare(JSObject a, JSObject b) {
                int la = a.optInt("limit", 0) > 0 ? 0 : 1;
                int lb = b.optInt("limit", 0) > 0 ? 0 : 1;
                if (la != lb) return la - lb;
                int ua = a.optInt("usedMin", 0), ub = b.optInt("usedMin", 0);
                if (ua != ub) return ub - ua;
                return a.optString("name", "").compareToIgnoreCase(b.optString("name", ""));
            }
        });
        JSArray arr = new JSArray();
        for (JSObject o : items) arr.put(o);
        JSObject r = new JSObject();
        r.put("apps", arr);
        r.put("usage", AppLimits.hasUsageAccess(c));
        call.resolve(r);
    }

    @PluginMethod
    public void setLimit(PluginCall call) {
        String p = call.getString("pkg");
        Integer m = call.getInt("minutes");
        if (p == null || m == null) { call.reject("value"); return; }
        AppLimits.setLimit(getContext(), p, Math.max(0, Math.min(24 * 60, m)));
        call.resolve();
    }
}
