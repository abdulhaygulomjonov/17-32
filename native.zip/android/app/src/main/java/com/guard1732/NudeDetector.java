package com.guard1732;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;

import ai.onnxruntime.OnnxTensor;
import ai.onnxruntime.OrtEnvironment;
import ai.onnxruntime.OrtSession;
import ai.onnxruntime.TensorInfo;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.FloatBuffer;
import java.util.Collections;

/**
 * NudeNet v3 (YOLOv8n, ONNX) detektori. Butun rasmga ball bermaydi, balki ochiq tana
 * a'zolarini topadi. Yuz, qo'l, kiyimli tana va hokazo sinflar hisobga olinmaydi.
 *
 * assets/nudenet.onnx: kirish [1,3,S,S] RGB 0..1, chiqish [1, 4+18, N].
 */
public class NudeDetector {
    public static final String MODEL_FILE = "nudenet.onnx";

    private static final int NUM_CLASSES = 18;
    /** NudeNet v3: 1 FACE_FEMALE, 12 FACE_MALE */
    public static final int FACE_FEMALE = 1;
    public static final int FACE_MALE = 12;
    /** NudeNet v3 sinflari: 2 BUTTOCKS_EXPOSED, 3 FEMALE_BREAST_EXPOSED, 4 FEMALE_GENITALIA_EXPOSED,
     *  6 ANUS_EXPOSED, 14 MALE_GENITALIA_EXPOSED */
    private static final int[] EXPLICIT = { 2, 3, 4, 6, 14 };
    /** 2-rejim (uyatsiz kiyim): 0 FEMALE_GENITALIA_COVERED, 15 ANUS_COVERED,
     *  16 FEMALE_BREAST_COVERED, 17 BUTTOCKS_COVERED */
    private static final int[] IMMODEST = { 0, 15, 16, 17 };

    private final OrtEnvironment env;
    private final OrtSession session;
    private final String inputName;
    private final int size;

    public NudeDetector(Context ctx) throws Exception {
        InputStream is = ctx.getAssets().open(MODEL_FILE);
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        byte[] buf = new byte[65536];
        int n;
        while ((n = is.read(buf)) > 0) bo.write(buf, 0, n);
        is.close();

        env = OrtEnvironment.getEnvironment();
        OrtSession.SessionOptions o = new OrtSession.SessionOptions();
        o.setIntraOpNumThreads(4);
        session = env.createSession(bo.toByteArray(), o);
        inputName = session.getInputNames().iterator().next();
        int s = 320;
        try {
            long[] shape = ((TensorInfo) session.getInputInfo().get(inputName).getInfo()).getShape();
            if (shape.length == 4 && shape[2] > 0) s = (int) shape[2];
        } catch (Exception ignored) { }
        size = s;
    }

    /** Rasmdagi har bir sinf uchun eng yuqori ishonch (uzunligi 18) */
    public float[] classMax(Bitmap bmp) {
        float[] m = new float[NUM_CLASSES];
        try {
            // kvadratga to'ldirish (pastga/o'ngga qora) va S x S ga kichraytirish
            int w = bmp.getWidth(), h = bmp.getHeight();
            float sc = size / (float) Math.max(w, h);
            int nw = Math.max(1, Math.round(w * sc)), nh = Math.max(1, Math.round(h * sc));
            Bitmap sq = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
            Canvas cv = new Canvas(sq);
            cv.drawColor(Color.BLACK);
            Paint pt = new Paint(Paint.FILTER_BITMAP_FLAG);
            cv.drawBitmap(bmp, new Rect(0, 0, w, h), new Rect(0, 0, nw, nh), pt);

            int[] px = new int[size * size];
            sq.getPixels(px, 0, size, 0, 0, size, size);
            sq.recycle();
            float[] data = new float[3 * size * size];
            int plane = size * size;
            for (int i = 0; i < plane; i++) {
                int p = px[i];
                data[i] = ((p >> 16) & 0xFF) / 255f;
                data[plane + i] = ((p >> 8) & 0xFF) / 255f;
                data[2 * plane + i] = (p & 0xFF) / 255f;
            }

            OnnxTensor t = OnnxTensor.createTensor(env, FloatBuffer.wrap(data),
                    new long[] { 1, 3, size, size });
            try {
                OrtSession.Result r = session.run(Collections.singletonMap(inputName, t));
                try {
                    float[][][] out = (float[][][]) r.get(0).getValue();
                    fill(out[0], m);
                } finally {
                    r.close();
                }
            } finally {
                t.close();
            }
        } catch (Exception e) {
            // xato bo'lsa nollar qaytadi: bloklanmaydi
        }
        return m;
    }

    /** o: [4+18][N] yoki [N][4+18]; m ga sinf maksimumlarini yozadi */
    private static void fill(float[][] o, float[] m) {
        boolean chFirst = o.length == 4 + NUM_CLASSES;
        boolean chLast = !chFirst && o.length > 0 && o[0].length == 4 + NUM_CLASSES;
        if (!chFirst && !chLast) return;   // kutilmagan model: bloklamaymiz
        int n = chFirst ? o[0].length : o.length;
        for (int k = 0; k < NUM_CLASSES; k++) {
            float best = 0f;
            for (int i = 0; i < n; i++) {
                float v = chFirst ? o[4 + k][i] : o[i][4 + k];
                if (v > best) best = v;
            }
            m[k] = Math.min(1f, best);
        }
    }

    public static void merge(float[] into, float[] other) {
        for (int k = 0; k < into.length; k++) if (other[k] > into[k]) into[k] = other[k];
    }

    /** 1-rejim: ochiq jinsiy a'zolar */
    public static float explicitOf(float[] m) {
        float b = 0f;
        for (int k : EXPLICIT) if (m[k] > b) b = m[k];
        return b;
    }

    /** 2-rejim: yopiq, lekin uyatsiz (lifchik, sochiq, ichki kiyim) */
    public static float immodestOf(float[] m) {
        float b = 0f;
        for (int k : IMMODEST) if (m[k] > b) b = m[k];
        return b;
    }

    public void close() {
        try { session.close(); } catch (Exception ignored) { }
    }

    public static boolean modelExists(Context ctx) {
        try {
            String[] l = ctx.getAssets().list("");
            if (l != null) for (String s : l) if (MODEL_FILE.equals(s)) return true;
        } catch (IOException ignored) { }
        return false;
    }
}
