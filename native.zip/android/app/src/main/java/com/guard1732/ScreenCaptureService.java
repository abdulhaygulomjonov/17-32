package com.guard1732;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.Bitmap;
import android.graphics.PixelFormat;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.SystemClock;
import android.util.DisplayMetrics;

public class ScreenCaptureService extends Service {

    public static volatile boolean running = false;

    private MediaProjection projection;
    private VirtualDisplay display;
    private ImageReader reader;
    private HandlerThread thread;
    private NsfwClassifier classifier;
    private long lastRun = 0;
    private long pausedUntil = 0;

    @Override
    public IBinder onBind(Intent i) { return null; }

    @SuppressWarnings("deprecation")
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null) { stopSelf(); return START_NOT_STICKY; }
        startAsForeground();

        int code = intent.getIntExtra("code", 0);
        Intent data = intent.getParcelableExtra("data");
        if (data == null) { stopSelf(); return START_NOT_STICKY; }

        try {
            classifier = new NsfwClassifier(this);
        } catch (Exception e) {
            stopSelf();
            return START_NOT_STICKY;
        }

        MediaProjectionManager mpm = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
        projection = mpm.getMediaProjection(code, data);

        thread = new HandlerThread("guard-capture");
        thread.start();
        Handler h = new Handler(thread.getLooper());

        projection.registerCallback(new MediaProjection.Callback() {
            @Override public void onStop() { stopSelf(); }
        }, h);

        DisplayMetrics dm = getResources().getDisplayMetrics();
        int w = dm.widthPixels;
        int hh = dm.heightPixels;
        reader = ImageReader.newInstance(w, hh, PixelFormat.RGBA_8888, 2);
        display = projection.createVirtualDisplay("guard", w, hh, dm.densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader.getSurface(), null, h);
        reader.setOnImageAvailableListener(new ImageReader.OnImageAvailableListener() {
            @Override public void onImageAvailable(ImageReader rd) { onFrame(rd); }
        }, h);
        running = true;
        return START_NOT_STICKY;
    }

    private void onFrame(ImageReader rd) {
        Image img;
        try { img = rd.acquireLatestImage(); } catch (Exception e) { return; }
        if (img == null) return;
        try {
            long now = SystemClock.elapsedRealtime();
            if (now - lastRun < 350 || now < pausedUntil) return;
            lastRun = now;

            Image.Plane plane = img.getPlanes()[0];
            int rowPadding = plane.getRowStride() - plane.getPixelStride() * img.getWidth();
            Bitmap bmp = Bitmap.createBitmap(
                    img.getWidth() + rowPadding / plane.getPixelStride(),
                    img.getHeight(), Bitmap.Config.ARGB_8888);
            bmp.copyPixelsFromBuffer(plane.getBuffer());
            Bitmap frame;
            if (rowPadding == 0) {
                frame = bmp;
            } else {
                frame = Bitmap.createBitmap(bmp, 0, 0, img.getWidth(), img.getHeight());
                bmp.recycle();
            }

            NsfwClassifier c = classifier;
            if (c == null) { frame.recycle(); return; }
            float thr = getSharedPreferences("guard", MODE_PRIVATE).getInt("thr", 50) / 100f;

            float best = scan(c, frame, thr);
            frame.recycle();

            if (best >= thr) {
                pausedUntil = now + 5000;
                GuardAccessibilityService s = GuardAccessibilityService.instance;
                if (s != null) s.trigger();
            }
        } finally {
            img.close();
        }
    }

    /** Butun ekran, so'ng 2x3 va 4x6 to'r bo'laklari; chegaradan oshsa darrov to'xtaydi */
    private float scan(NsfwClassifier c, Bitmap f, float thr) {
        float best = c.explicitScore(f);
        if (best >= thr) return best;
        int W = f.getWidth(), H = f.getHeight();
        int[][] grids = { {2, 3}, {4, 6} };
        for (int[] g : grids) {
            int cols = g[0], rows = g[1];
            int tw = W / cols, th = H / rows;
            for (int r = 0; r < rows; r++) {
                for (int q = 0; q < cols; q++) {
                    Bitmap t = Bitmap.createBitmap(f, q * tw, r * th, tw, th);
                    float s = c.explicitScore(t);
                    t.recycle();
                    if (s > best) best = s;
                    if (best >= thr) return best;
                }
            }
        }
        return best;
    }

    private void startAsForeground() {
        NotificationManager nm = getSystemService(NotificationManager.class);
        nm.createNotificationChannel(
                new NotificationChannel("guard", "17-32", NotificationManager.IMPORTANCE_LOW));
        Notification n = new Notification.Builder(this, "guard")
                .setContentTitle("17-32 faol")
                .setContentText("Ekran nazorat qilinmoqda")
                .setSmallIcon(android.R.drawable.ic_lock_idle_lock)
                .setOngoing(true)
                .build();
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
        } else {
            startForeground(1, n);
        }
    }

    @Override
    public void onDestroy() {
        running = false;
        try { if (reader != null) reader.setOnImageAvailableListener(null, null); } catch (Exception ignored) { }
        if (display != null) display.release();
        if (reader != null) reader.close();
        if (projection != null) projection.stop();
        if (thread != null) thread.quitSafely();
        if (classifier != null) classifier.close();
        super.onDestroy();
    }
}
