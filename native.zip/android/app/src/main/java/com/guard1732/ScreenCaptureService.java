package com.guard1732;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.graphics.Bitmap;
import android.graphics.PixelFormat;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.SystemClock;
import android.util.DisplayMetrics;

public class ScreenCaptureService extends Service {

    public static volatile boolean running = false;

    private MediaProjection projection;
    private VirtualDisplay display;
    private ImageReader reader;
    private HandlerThread thread;
    private NsfwClassifier classifier;
    private NudeDetector detector;
    private long lastRun = 0;
    private long pausedUntil = 0;
    private int hits = 0;
    private int deepHits = 0;
    private long lastDeep = 0;
    private long lastHitAt = 0;

    @Override
    public IBinder onBind(Intent i) { return null; }

    @SuppressWarnings("deprecation")
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null) { stopSelf(); return START_NOT_STICKY; }
        startAsForeground();

        int code = intent.getIntExtra("code", 0);
        Intent data = intent.getParcelableExtra("data");
        if (data == null) { stopSelf(); return START_NOT_STICKY; }

        try {
            if (NudeDetector.modelExists(this)) {
                detector = new NudeDetector(this);      // NudeNet: ochiq a'zolarni topadi
            } else {
                classifier = new NsfwClassifier(this);  // zaxira: eski tasniflagich
            }
        } catch (Exception e) {
            stopSelf();
            return START_NOT_STICKY;
        }

        MediaProjectionManager mpm = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
        projection = mpm.getMediaProjection(code, data);

        thread = new HandlerThread("guard-capture");
        thread.start();
        Handler h = new Handler(thread.getLooper());

        projection.registerCallback(new MediaProjection.Callback() {
            @Override public void onStop() { stopSelf(); }
        }, h);

        DisplayMetrics dm = getResources().getDisplayMetrics();
        int w = dm.widthPixels;
        int hh = dm.heightPixels;
        reader = ImageReader.newInstance(w, hh, PixelFormat.RGBA_8888, 2);
        display = projection.createVirtualDisplay("guard", w, hh, dm.densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader.getSurface(), null, h);
        reader.setOnImageAvailableListener(new ImageReader.OnImageAvailableListener() {
            @Override public void onImageAvailable(ImageReader rd) { onFrame(rd); }
        }, h);
        running = true;
        return START_NOT_STICKY;
    }

    private void onFrame(ImageReader rd) {
        Image img;
        try { img = rd.acquireLatestImage(); } catch (Exception e) { return; }
        if (img == null) return;
        try {
            long now = SystemClock.elapsedRealtime();
            if (now - lastRun < 350 || now < pausedUntil) return;
            lastRun = now;

            Image.Plane plane = img.getPlanes()[0];
            int rowPadding = plane.getRowStride() - plane.getPixelStride() * img.getWidth();
            Bitmap bmp = Bitmap.createBitmap(
                    img.getWidth() + rowPadding / plane.getPixelStride(),
                    img.getHeight(), Bitmap.Config.ARGB_8888);
            bmp.copyPixelsFromBuffer(plane.getBuffer());
            Bitmap frame;
            if (rowPadding == 0) {
                frame = bmp;
            } else {
                frame = Bitmap.createBitmap(bmp, 0, 0, img.getWidth(), img.getHeight());
                bmp.recycle();
            }

            NsfwClassifier c = classifier;
            NudeDetector d = detector;
            if (c == null && d == null) { frame.recycle(); return; }
            SharedPreferences sp = getSharedPreferences("guard", MODE_PRIVATE);
            int thrPct = sp.getInt("thr", 60);
            float thr = Math.max(40, Math.min(95, thrPct)) / 100f;

            boolean fire;
            if (d != null) {
                fire = decideDetector(d, frame, sp, thr, now);
            } else {
                float best = scan(c, frame, thr);
                fire = false;
                if (best >= thr) {
                    // juda aniq bo'lsa darrov, aks holda ketma-ket 2 kadrda tasdiqlanadi
                    if (now - lastHitAt > 2500) hits = 0;
                    hits++;
                    lastHitAt = now;
                    if (best >= Math.min(0.97f, thr + 0.25f) || hits >= 2) fire = true;
                } else {
                    hits = 0;
                }
            }
            frame.recycle();

            if (fire) {
                hits = 0;
                deepHits = 0;
                pausedUntil = now + 5000;
                GuardAccessibilityService s = GuardAccessibilityService.instance;
                if (s != null) s.trigger();
            }
        } finally {
            img.close();
        }
    }

    /**
     * 3 tizim:
     *  m1 (standart yoqiq): ochiq jinsiy a'zolar, 2 kadrda tasdiqlanadi (juda aniq bo'lsa darrov)
     *  m2: yopiq, lekin uyatsiz kiyim (lifchik, sochiq...): chegara 15% qattiqroq, doim 2 kadr kerak
     *  m3: mayda rasmlar: ekranni 4x6 bo'lakka bo'lib, har 2 soniyada, 2 skanerda tasdiqlanadi
     */
    private boolean decideDetector(NudeDetector d, Bitmap f, SharedPreferences sp, float thr, long now) {
        boolean m1 = sp.getBoolean("m1", true);
        boolean m2 = sp.getBoolean("m2", false);
        boolean m3 = sp.getBoolean("m3", false);
        if (!m1 && !m2 && !m3) return false;

        int W = f.getWidth(), H = f.getHeight(), half = H / 2;
        float[] cm = d.classMax(f);
        Bitmap top = Bitmap.createBitmap(f, 0, 0, W, half);
        NudeDetector.merge(cm, d.classMax(top));
        top.recycle();
        Bitmap bot = Bitmap.createBitmap(f, 0, half, W, H - half);
        NudeDetector.merge(cm, d.classMax(bot));
        bot.recycle();

        float ex = m1 ? NudeDetector.explicitOf(cm) : 0f;
        float im = m2 ? NudeDetector.immodestOf(cm) - 0.15f : 0f;

        boolean fire = false;
        float cur = Math.max(ex, im);
        if (cur >= thr) {
            if (now - lastHitAt > 2500) hits = 0;
            hits++;
            lastHitAt = now;
            if (ex >= Math.min(0.97f, thr + 0.25f) || hits >= 2) fire = true;
        } else {
            hits = 0;
        }

        // 3-tizim: mayda rasmlar uchun chuqur skaner
        if (!fire && m3 && now - lastDeep > 2000) {
            lastDeep = now;
            float[] dm = new float[18];
            int cols = 4, rows = 6, tw = W / cols, th = H / rows;
            for (int r = 0; r < rows; r++) {
                for (int q = 0; q < cols; q++) {
                    Bitmap t = Bitmap.createBitmap(f, q * tw, r * th, tw, th);
                    if (!NsfwClassifier.isFlat(t)) NudeDetector.merge(dm, d.classMax(t));
                    t.recycle();
                }
            }
            float dex = m1 || m3 ? NudeDetector.explicitOf(dm) : 0f;
            float dim = m2 ? NudeDetector.immodestOf(dm) - 0.15f : 0f;
            // bo'lak kontekstsiz, shuning uchun chegara 10% qattiqroq
            if (Math.max(dex, dim) - 0.10f >= thr) {
                deepHits++;
                if (deepHits >= 2) fire = true;
            } else {
                deepHits = 0;
            }
        }
        return fire;
    }

    /**
     * Butun ekran, so'ng 2x3 bo'laklar. Bir xil rangli bo'laklar o'tkazib yuboriladi,
     * kichik bo'laklar uchun chegara 10% qattiqroq (kontekstsiz bo'lak ishonchsiz).
     */
    private float scan(NsfwClassifier c, Bitmap f, float thr) {
        float best = 0f;
        if (!NsfwClassifier.isFlat(f)) {
            best = c.explicitScore(f);
            if (best >= thr) return best;
        }
        float tileThr = Math.min(0.99f, thr + 0.10f);
        int W = f.getWidth(), H = f.getHeight();
        int cols = 2, rows = 3;
        int tw = W / cols, th = H / rows;
        for (int r = 0; r < rows; r++) {
            for (int q = 0; q < cols; q++) {
                Bitmap t = Bitmap.createBitmap(f, q * tw, r * th, tw, th);
                float s = NsfwClassifier.isFlat(t) ? 0f : c.explicitScore(t);
                t.recycle();
                if (s >= tileThr) return s;
            }
        }
        return Math.min(best, thr - 0.001f);
    }

    private void startAsForeground() {
        NotificationManager nm = getSystemService(NotificationManager.class);
        nm.createNotificationChannel(
                new NotificationChannel("guard", "17-32", NotificationManager.IMPORTANCE_LOW));
        Notification n = new Notification.Builder(this, "guard")
                .setContentTitle("17-32 faol")
                .setContentText("Ekran nazorat qilinmoqda")
                .setSmallIcon(android.R.drawable.ic_lock_idle_lock)
                .setOngoing(true)
                .build();
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
        } else {
            startForeground(1, n);
        }
    }

    @Override
    public void onDestroy() {
        running = false;
        try { if (reader != null) reader.setOnImageAvailableListener(null, null); } catch (Exception ignored) { }
        if (display != null) display.release();
        if (reader != null) reader.close();
        if (projection != null) projection.stop();
        if (thread != null) thread.quitSafely();
        if (classifier != null) classifier.close();
        if (detector != null) detector.close();
        super.onDestroy();
    }
}
