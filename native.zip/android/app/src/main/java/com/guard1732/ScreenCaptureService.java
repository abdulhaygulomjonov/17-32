package com.guard1732;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.graphics.Bitmap;
import android.graphics.PixelFormat;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.SystemClock;
import android.util.DisplayMetrics;

public class ScreenCaptureService extends Service {

    /** Xizmat tirik (ishga tushmoqda yoki ishlayapti). Dastlabki yuklash tugamasdan ham true bo'ladi,
     *  aks holda ilova modelni yuklash paytida "yoqilmagan" deb o'ylab ruxsatni qayta so'rayverardi. */
    public static volatile boolean running = false;
    /** Oxirgi xato sababi (ilova ekranida ko'rsatiladi) */
    public static volatile String lastError = "";
    private boolean frameErrReported = false;

    private MediaProjection projection;
    private VirtualDisplay display;
    private ImageReader reader;
    private HandlerThread thread;
    private NsfwClassifier classifier;
    private NudeDetector detector;
    private long lastRun = 0;
    private long pausedUntil = 0;
    private int hits = 0;
    private int deepHits = 0;
    private int firedSystem = 0;   // qaysi tizim ishga tushdi: 1, 2, 3 (0 = eski model)
    private long lastDeep = 0;
    private long lastHitAt = 0;

    @Override
    public IBinder onBind(Intent i) { return null; }

    @SuppressWarnings("deprecation")
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null) { stopSelf(); return START_NOT_STICKY; }
        if (running && projection != null) {
            // allaqachon ishlayapti: ikkinchi marta ishga tushirmaymiz
            return START_NOT_STICKY;
        }
        lastError = "";
        Dbg.step(this, "xizmat boshlandi");
        running = true;   // darrov: UI qayta ruxsat so'ramasligi uchun
        try {
            startAsForeground();
        } catch (Throwable t) {
            fail("foreground: " + t.getClass().getSimpleName() + " " + t.getMessage());
            return START_NOT_STICKY;
        }

        Dbg.step(this, "foreground OK");
        int code = intent.getIntExtra("code", 0);
        Intent data = intent.getParcelableExtra("data");
        if (data == null) { fail("data yo'q"); return START_NOT_STICKY; }

        try {
            MediaProjectionManager mpm = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
            projection = mpm.getMediaProjection(code, data);
            if (projection == null) { fail("projection null"); return START_NOT_STICKY; }
            Dbg.step(this, "projection OK");
        } catch (Throwable t) {
            fail("projection: " + t.getClass().getSimpleName() + " " + t.getMessage());
            return START_NOT_STICKY;
        }

        thread = new HandlerThread("guard-capture");
        thread.start();
        final Handler h = new Handler(thread.getLooper());

        try {
            projection.registerCallback(new MediaProjection.Callback() {
                @Override public void onStop() {
                    Dbg.step(ScreenCaptureService.this, "projection.onStop (tizim to'xtatdi)");
                    if (running && lastError.isEmpty()) lastError = "tizim ekran yozishni to'xtatdi";
                    stopSelf();
                }
            }, h);
        } catch (Throwable t) {
            fail("callback: " + t.getClass().getSimpleName() + " " + t.getMessage());
            return START_NOT_STICKY;
        }

        // Og'ir qism (model yuklash, ekran oqimi) asosiy oqimni band qilmasligi uchun alohida oqimda
        h.post(new Runnable() {
            @Override public void run() { initCapture(h); }
        });
        return START_NOT_STICKY;
    }

    private void initCapture(Handler h) {
        Dbg.step(this, "model yuklanmoqda");
        try {
            if (NudeDetector.modelExists(this)) {
                detector = new NudeDetector(this);      // NudeNet: ochiq a'zolarni topadi
            } else {
                classifier = new NsfwClassifier(this);  // zaxira: eski tasniflagich
            }
        } catch (Throwable t) {
            fail("model: " + t.getClass().getSimpleName() + " " + t.getMessage());
            return;
        }
        Dbg.step(this, "model OK");
        try {
            DisplayMetrics dm = getResources().getDisplayMetrics();
            int w = dm.widthPixels;
            int hh = dm.heightPixels;
            reader = ImageReader.newInstance(w, hh, PixelFormat.RGBA_8888, 2);
            display = projection.createVirtualDisplay("guard", w, hh, dm.densityDpi,
                    DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader.getSurface(), null, h);
            reader.setOnImageAvailableListener(new ImageReader.OnImageAvailableListener() {
                @Override public void onImageAvailable(ImageReader rd) { onFrame(rd); }
            }, h);
            Dbg.step(this, "ekran oqimi OK, ishlayapti");
        } catch (Throwable t) {
            fail("display: " + t.getClass().getSimpleName() + " " + t.getMessage());
        }
    }

    private void fail(String why) {
        Dbg.step(this, "XATO " + why);
        lastError = why;
        running = false;
        stopSelf();
    }

    private void onFrame(ImageReader rd) {
        try {
            onFrameInner(rd);
        } catch (Throwable t) {
            // ushlanmagan xato butun ilovani yiqitmasin
            if (!frameErrReported) {
                frameErrReported = true;
                lastError = "kadr: " + t.getClass().getSimpleName() + " " + t.getMessage();
            }
        }
    }

    private void onFrameInner(ImageReader rd) {
        Image img;
        try { img = rd.acquireLatestImage(); } catch (Exception e) { return; }
        if (img == null) return;
        try {
            long now = SystemClock.elapsedRealtime();
            if (now - lastRun < 350 || now < pausedUntil) return;
            lastRun = now;

            Image.Plane plane = img.getPlanes()[0];
            int rowPadding = plane.getRowStride() - plane.getPixelStride() * img.getWidth();
            Bitmap bmp = Bitmap.createBitmap(
                    img.getWidth() + rowPadding / plane.getPixelStride(),
                    img.getHeight(), Bitmap.Config.ARGB_8888);
            bmp.copyPixelsFromBuffer(plane.getBuffer());
            Bitmap frame;
            if (rowPadding == 0) {
                frame = bmp;
            } else {
                frame = Bitmap.createBitmap(bmp, 0, 0, img.getWidth(), img.getHeight());
                bmp.recycle();
            }

            NsfwClassifier c = classifier;
            NudeDetector d = detector;
            if (c == null && d == null) { frame.recycle(); return; }
            SharedPreferences sp = getSharedPreferences("guard", MODE_PRIVATE);
            final float thr = 0.60f;   // sezgirlik chegarasi qat'iy, o'zgartirib bo'lmaydi

            boolean fire;
            if (d != null) {
                fire = decideDetector(d, frame, sp, thr, now);
            } else {
                firedSystem = 0;
                float best = scan(c, frame, thr);
                fire = false;
                if (best >= thr) {
                    // juda aniq bo'lsa darrov, aks holda ketma-ket 2 kadrda tasdiqlanadi
                    if (now - lastHitAt > 2500) hits = 0;
                    hits++;
                    lastHitAt = now;
                    if (best >= Math.min(0.97f, thr + 0.25f) || hits >= 2) fire = true;
                } else {
                    hits = 0;
                }
            }
            frame.recycle();

            if (fire) {
                hits = 0;
                deepHits = 0;
                pausedUntil = now + 5000;
                GuardAccessibilityService s = GuardAccessibilityService.instance;
                if (s != null) s.trigger(firedSystem);
            }
        } finally {
            img.close();
        }
    }

    /**
     * 3 tizim:
     *  m1 (standart yoqiq): ochiq jinsiy a'zolar, 2 kadrda tasdiqlanadi (juda aniq bo'lsa darrov)
     *  m2: yopiq, lekin uyatsiz kiyim (lifchik, sochiq...): chegara 15% qattiqroq, doim 2 kadr kerak
     *  m3: mayda rasmlar: ekranni 4x6 bo'lakka bo'lib, har 2 soniyada, 2 skanerda tasdiqlanadi
     */
    private boolean decideDetector(NudeDetector d, Bitmap f, SharedPreferences sp, float thr, long now) {
        // uchala tizim doim yoqiq, o'chirib bo'lmaydi
        final boolean m1 = true, m2 = true, m3 = true;

        int W = f.getWidth(), H = f.getHeight(), half = H / 2;
        float[] cm = d.classMax(f);
        Bitmap top = Bitmap.createBitmap(f, 0, 0, W, half);
        NudeDetector.merge(cm, d.classMax(top));
        top.recycle();
        Bitmap bot = Bitmap.createBitmap(f, 0, half, W, H - half);
        NudeDetector.merge(cm, d.classMax(bot));
        bot.recycle();

        float ex = m1 ? NudeDetector.explicitOf(cm) : 0f;
        float im = m2 ? NudeDetector.immodestOf(cm) - 0.15f : 0f;

        boolean fire = false;
        float cur = Math.max(ex, im);
        if (cur >= thr) {
            if (now - lastHitAt > 2500) hits = 0;
            hits++;
            lastHitAt = now;
            if (ex >= Math.min(0.97f, thr + 0.25f) || hits >= 2) {
                fire = true;
                firedSystem = ex >= im ? 1 : 2;   // 1: ochiq a'zolar, 2: uyatsiz kiyim
            }
        } else {
            hits = 0;
        }

        // 3-tizim: mayda rasmlar uchun chuqur skaner
        if (!fire && m3 && now - lastDeep > 2000) {
            lastDeep = now;
            float[] dm = new float[18];
            int cols = 4, rows = 6, tw = W / cols, th = H / rows;
            for (int r = 0; r < rows; r++) {
                for (int q = 0; q < cols; q++) {
                    Bitmap t = Bitmap.createBitmap(f, q * tw, r * th, tw, th);
                    if (!NsfwClassifier.isFlat(t)) NudeDetector.merge(dm, d.classMax(t));
                    t.recycle();
                }
            }
            float dex = m1 || m3 ? NudeDetector.explicitOf(dm) : 0f;
            float dim = m2 ? NudeDetector.immodestOf(dm) - 0.15f : 0f;
            // bo'lak kontekstsiz, shuning uchun chegara 10% qattiqroq
            if (Math.max(dex, dim) - 0.10f >= thr) {
                deepHits++;
                if (deepHits >= 2) { fire = true; firedSystem = 3; }
            } else {
                deepHits = 0;
            }
        }
        return fire;
    }

    /**
     * Butun ekran, so'ng 2x3 bo'laklar. Bir xil rangli bo'laklar o'tkazib yuboriladi,
     * kichik bo'laklar uchun chegara 10% qattiqroq (kontekstsiz bo'lak ishonchsiz).
     */
    private float scan(NsfwClassifier c, Bitmap f, float thr) {
        float best = 0f;
        if (!NsfwClassifier.isFlat(f)) {
            best = c.explicitScore(f);
            if (best >= thr) return best;
        }
        float tileThr = Math.min(0.99f, thr + 0.10f);
        int W = f.getWidth(), H = f.getHeight();
        int cols = 2, rows = 3;
        int tw = W / cols, th = H / rows;
        for (int r = 0; r < rows; r++) {
            for (int q = 0; q < cols; q++) {
                Bitmap t = Bitmap.createBitmap(f, q * tw, r * th, tw, th);
                float s = NsfwClassifier.isFlat(t) ? 0f : c.explicitScore(t);
                t.recycle();
                if (s >= tileThr) return s;
            }
        }
        return Math.min(best, thr - 0.001f);
    }

    private void startAsForeground() {
        NotificationManager nm = getSystemService(NotificationManager.class);
        nm.createNotificationChannel(
                new NotificationChannel("guard", "17-32", NotificationManager.IMPORTANCE_LOW));
        Notification n = new Notification.Builder(this, "guard")
                .setContentTitle("17-32 faol")
                .setContentText("Ekran nazorat qilinmoqda")
                .setSmallIcon(android.R.drawable.ic_lock_idle_lock)
                .setOngoing(true)
                .build();
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
        } else {
            startForeground(1, n);
        }
    }

    @Override
    public void onDestroy() {
        Dbg.step(this, "xizmat to'xtadi");
        running = false;
        try { if (reader != null) reader.setOnImageAvailableListener(null, null); } catch (Throwable ignored) { }
        try { if (display != null) display.release(); } catch (Throwable ignored) { }
        try { if (reader != null) reader.close(); } catch (Throwable ignored) { }
        try { if (projection != null) projection.stop(); } catch (Throwable ignored) { }
        projection = null;
        try { if (thread != null) thread.quitSafely(); } catch (Throwable ignored) { }
        try { if (classifier != null) classifier.close(); } catch (Throwable ignored) { }
        try { if (detector != null) detector.close(); } catch (Throwable ignored) { }
        super.onDestroy();
    }
}
