package uz.sanalar.app;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.SystemClock;

import org.json.JSONArray;
import org.json.JSONObject;

import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.List;

/**
 * "So'z filtri": foydalanuvchi o'zi kiritgan "Sezuvchi so'zlar" klaviaturada yozilganda o'sha zahoti o'chiriladi.
 * Bloklash rejimidek qattiq: yoqilganda parol va kutish muddatisiz o'chirib bo'lmaydi, ilovani o'chirib yuborish ham to'sib qo'yiladi.
 * Dasturda hech qanday tayyor so'z yo'q: ro'yxatni faqat foydalanuvchi to'ldiradi.
 */
final class Filtr {
    static SharedPreferences p(Context c) {
        return Store.p(c);
    }

    static boolean on(Context c) {
        // avtomatik yoqilgan: yashirin bo'limdan o'chirilgandagina o'chiq turadi
        return p(c).getBoolean("al_on", true);
    }

    static long waitMs(Context c) {
        return Math.max(Blk.MINW, Math.min(Blk.MAXW, p(c).getLong("al_wait", 24L * 3600 * 1000)));
    }

    /* ---------------- so'zlar ---------------- */
    private static String wRaw = null;
    private static List<String> wList = new ArrayList<String>();
    private static List<String> wFold = new ArrayList<String>();

    /** O'rnatilgan yashirin ro'yxat olib tashlangan: faqat foydalanuvchi o'zi kiritgan so'zlar ishlaydi. */
    private static final String[] BUILTIN = {};
    private static List<String> wUser = new ArrayList<String>();

    private static volatile long wChk = 0;
    private static volatile boolean wDirty = true;

    static synchronized List<String> words(Context c) {
        // Har bir ekran tuguni uchun SharedPreferences o'qilmaydi: ro'yxat xotirada, o'zgarsa yoki 1.5 s dan keyin yangilanadi.
        long now = android.os.SystemClock.uptimeMillis();
        if (!wDirty && now - wChk < 1500) return wList;
        wChk = now;
        wDirty = false;
        String s = p(c).getString("al_words", "[]");
        if (!s.equals(wRaw)) {
            List<String> l = new ArrayList<String>();
            try {
                JSONArray a = new JSONArray(s);
                for (int i = 0; i < a.length(); i++) {
                    String x = a.optString(i, "").trim();
                    if (x.length() > 0) l.add(x);
                }
            } catch (Exception e) {
            }
            wUser = new ArrayList<String>(l);
            for (String b : BUILTIN) addUniq(l, b);
            ArrayList<String> fl = new ArrayList<String>();
            for (String x : l) fl.add(fold(x));
            wFold = fl;
            wList = l;
            wRaw = s;
        }
        return wList;
    }

    /** Faqat foydalanuvchi o'zi kiritgan so'zlar (o'rnatilgan ro'yxatsiz) - interfeys uchun. */
    static synchronized List<String> userWords(Context c) {
        words(c);
        return new ArrayList<String>(wUser);
    }

    /** Yoqilmagan paytda ro'yxatni almashtiradi; yoqilgan paytda faqat yangi so'z qo'shishga ruxsat beradi. */
    static String setWords(Context c, String json) {
        try {
            JSONArray a = new JSONArray(json);
            List<String> out = new ArrayList<String>();
            for (int i = 0; i < a.length() && out.size() < 10000; i++) {
                String x = a.optString(i, "").trim().toLowerCase(java.util.Locale.ROOT);
                if (x.length() >= 1 && x.length() <= 60) addUniq(out, x);
            }
            // Filtr yoqilgan paytda so'zni olib tashlab bo'lmaydi: eskilari saqlanadi, faqat yangilari qo'shiladi
            if (on(c)) for (String x : userWords(c)) addUniq(out, x);
            JSONArray o = new JSONArray();
            for (String x : out) o.put(x);
            p(c).edit().putString("al_words", o.toString()).apply();
            wDirty = true;
            return "ok";
        } catch (Exception e) {
            return "err";
        }
    }

    private static void addUniq(List<String> l, String x) {
        String f = fold(x);
        for (String y : l) if (fold(y).equals(f)) return;
        l.add(x);
    }

    /* ---------------- yoqish / o'chirish (parol + kutish) ---------------- */
    static String enable(Context c, String pw, long w) {
        if (!Blk.a11y(c)) return "a11y";
        p(c).edit().putBoolean("al_on", true).putLong("al_req", 0).apply();
        return "ok";
    }

    static boolean pwOk(Context c, String pw) {
        SharedPreferences sp = p(c);
        String salt = sp.getString("al_salt", "");
        return pw != null && salt.length() > 0 && Blk.hash(salt, pw).equals(sp.getString("al_hash", "x"));
    }

    static long reqAt(Context c) {
        return p(c).getLong("al_req", 0);
    }

    static String requestOff(Context c, String pw) {
        if (!on(c)) return "ok";
        if (!pwOk(c, pw)) return "bad_pw";
        if (reqAt(c) == 0) {
            p(c).edit().putLong("al_req", System.currentTimeMillis()).putLong("al_req_el", SystemClock.elapsedRealtime())
                    .putInt("al_req_boot", Blk.boot(c)).apply();
        }
        return "ok";
    }

    static void cancelOff(Context c) {
        p(c).edit().putLong("al_req", 0).apply();
    }

    /** Kutish tugaguncha qolgan millisekund (-1: o'chirish so'ralmagan). Soatni o'zgartirib aldab bo'lmaydi. */
    static long remaining(Context c) {
        long r = reqAt(c);
        if (r == 0) return -1;
        SharedPreferences sp = p(c);
        long left = waitMs(c) - (System.currentTimeMillis() - r);
        if (sp.getInt("al_req_boot", -1) == Blk.boot(c) && Blk.boot(c) != 0) {
            long left2 = waitMs(c) - (SystemClock.elapsedRealtime() - sp.getLong("al_req_el", 0));
            if (left2 > left) left = left2;
        }
        return Math.max(0, left);
    }

    static String off(Context c, String pw) {
        // Ilovaning o'zidan o'chirib bo'lmaydi: faqat yashirin bo'lim (NativeApi.blkRelease) o'chiradi
        return on(c) ? "locked" : "ok";
    }

    static JSONObject state(Context c) {
        JSONObject o = new JSONObject();
        try {
            JSONArray w = new JSONArray();
            for (String x : userWords(c)) w.put(x);
            o.put("on", on(c)).put("a11y", Blk.a11y(c)).put("left", remaining(c)).put("wait", waitMs(c)).put("words", w)
                    .put("hits", p(c).getInt("al_hits", 0));
        } catch (Exception e) {
        }
        return o;
    }

    static void hit(Context c) {
        SharedPreferences sp = p(c);
        sp.edit().putInt("al_hits", sp.getInt("al_hits", 0) + 1).apply();
    }

    /* ---------------- o'chirish ---------------- */
    static final class Res {
        String text;
        int pos;
    }

    /** Harflar sonini saqlagan holda kichik harfga o'tkazadi, turli tutuq belgilarini bitta qiladi. */
    static String fold(String s) {
        char[] a = s.toCharArray();
        for (int i = 0; i < a.length; i++) {
            char ch = a[i];
            if (isApos(ch)) ch = '\'';
            else ch = Character.toLowerCase(ch);
            a[i] = ch;
        }
        return new String(a);
    }


    /** Tutuq / apostrof belgisining barcha ko'rinishlari (hammasi bitta ' ga keltiriladi). */
    static boolean isApos(char ch) {
        switch (ch) {
            case '\'': case '`': case '\u00b4':
            case '\u2018': case '\u2019': case '\u201b': case '\u2032': case '\u2035':
            case '\u02b9': case '\u02bb': case '\u02bc': case '\u02bd': case '\u02be': case '\u02bf':
            case '\u02c8': case '\u02ca': case '\u02cb': case '\u055a': case '\uff07': case '\uff40':
                return true;
            default:
                return false;
        }
    }

    /** fw f ning i-o'rnida AYNAN o'sha so'z sifatida turibdimi: oldidan ham, ketidan ham boshqa harf/raqam bo'lmasligi shart.
     *  Qo'shimchalar HISOBGA OLINMAYDI: ro'yxatda qanday yozilgan bo'lsa, aynan shunday topiladi. */
    private static boolean wholeAt(String f, int i, int n) {
        return boundBefore(f, i) && boundAfter(f, i + n);
    }

    /** Ekrandagi matnda sezuvchi so'z bormi? Topilgan so'zni qaytaradi, bo'lmasa null.
     *  So'z faqat AYNAN o'zi sifatida topiladi (qo'shimchasiz): boshqa so'z ichidagi bo'lak hisoblanmaydi
     *  (masalan "analysis" ichida "anal" topilmaydi). */
    static String find(Context c, String text) {
        List<String> ws, fws;
        synchronized (Filtr.class) {
            ws = words(c);
            fws = wFold;
        }
        if (ws.isEmpty() || text == null || text.length() < 2) return null;
        String f = fold(text);
        int fl = f.length();
        for (int k = 0; k < fws.size(); k++) {
            String fw = fws.get(k);
            int n = fw.length();
            if (n == 0 || n > fl) continue;
            int from = 0;
            while (from <= fl) {
                int i = f.indexOf(fw, from);
                if (i < 0) break;
                if (wholeAt(f, i, n)) return ws.get(k);
                from = i + 1;
            }
        }
        return null;
    }

    /** So'z boshidan oldin chegara bormi (harf/raqam yoki harflar orasidagi tutuq bo'lsa - yo'q). */
    private static boolean boundBefore(String s, int i) {
        if (i <= 0) return true;
        char ch = s.charAt(i - 1);
        if (Character.isLetterOrDigit(ch)) return false;
        return !(ch == '\'' && i - 2 >= 0 && Character.isLetterOrDigit(s.charAt(i - 2)));
    }

    /** So'z oxiridan keyin chegara bormi (harf/raqam yoki keyingi harfga ulangan tutuq bo'lsa - yo'q). */
    private static boolean boundAfter(String s, int e) {
        if (e >= s.length()) return true;
        char ch = s.charAt(e);
        if (Character.isLetterOrDigit(ch)) return false;
        return !(ch == '\'' && e + 1 < s.length() && Character.isLetterOrDigit(s.charAt(e + 1)));
    }

    /** Matndagi sezuvchi so'zlarni olib tashlaydi. Hech narsa topilmasa null. */
    static Res erase(Context c, String text) {
        List<String> ws = words(c);
        if (ws.isEmpty() || text == null || text.length() == 0) return null;
        String t = text, f = fold(text);
        int pos = -1;
        boolean any = false;
        for (int pass = 0; pass < 3; pass++) {
            boolean ch = false;
            for (String w : ws) {
                String fw = fold(w);
                if (fw.length() == 0) continue;
                int from = 0;
                while (from <= f.length()) {
                    int i = f.indexOf(fw, from);
                    if (i < 0) break;
                    if (!wholeAt(f, i, fw.length())) {
                        from = i + 1;
                        continue;
                    }
                    int e = i + fw.length();
                    t = t.substring(0, i) + t.substring(e);
                    f = f.substring(0, i) + f.substring(e);
                    if (i > 0 && i < t.length() && t.charAt(i - 1) == ' ' && t.charAt(i) == ' ') {
                        t = t.substring(0, i) + t.substring(i + 1);
                        f = f.substring(0, i) + f.substring(i + 1);
                    } else if (i == 0 && t.length() > 0 && t.charAt(0) == ' ') {
                        t = t.substring(1);
                        f = f.substring(1);
                    }
                    if (pos < 0 || i < pos) pos = i;
                    any = true;
                    ch = true;
                    from = i;
                }
            }
            if (!ch) break;
        }
        if (!any) return null;
        Res r = new Res();
        r.text = t;
        r.pos = Math.max(0, Math.min(pos, t.length()));
        return r;
    }
}
