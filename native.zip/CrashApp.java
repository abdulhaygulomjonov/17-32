package uz.sanalar.app;

import android.app.Application;
import android.content.Context;
import android.content.Intent;
import android.os.Process;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.PrintWriter;
import java.io.StringWriter;

/** Ilova ishga tushishida yiqilsa, xatoni alohida oynada ko'rsatadi. */
public class CrashApp extends Application {
    @Override
    protected void attachBaseContext(final Context base) {
        super.attachBaseContext(base);
        try {
            String pn = "";
            try {
                BufferedReader r = new BufferedReader(new FileReader("/proc/self/cmdline"));
                pn = r.readLine();
                r.close();
            } catch (Throwable e) {
            }
            if (pn != null && pn.indexOf(":crash") >= 0) return;
            final Thread.UncaughtExceptionHandler old = Thread.getDefaultUncaughtExceptionHandler();
            Thread.setDefaultUncaughtExceptionHandler(new Thread.UncaughtExceptionHandler() {
                @Override
                public void uncaughtException(Thread t, Throwable e) {
                    try {
                        StringWriter sw = new StringWriter();
                        e.printStackTrace(new PrintWriter(sw));
                        String x = sw.toString();
                        if (x.length() > 6000) x = x.substring(0, 6000);
                        Intent i = new Intent();
                        i.setClassName(base.getPackageName(), "uz.sanalar.app.CrashActivity");
                        i.putExtra("log", x);
                        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                        base.startActivity(i);
                        Thread.sleep(800);
                    } catch (Throwable z) {
                    }
                    try {
                        Process.killProcess(Process.myPid());
                    } catch (Throwable z) {
                    }
                    if (old != null) old.uncaughtException(t, e);
                }
            });
        } catch (Throwable e) {
        }
    }
}
