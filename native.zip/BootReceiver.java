package uz.sanalar.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/**
 * Telefon qayta yoqilganda (ekran ochilmasdan oldin ham), ilova yangilanganda, soat/vaqt zonasi o'zgarganda yoki
 * aniq signal ruxsati o'zgarganda barcha budilnik va bildirishnomalarni qayta rejalashtiradi.
 * Telefon o'chiq paytda vaqti o'tib ketgan budilnik (20 daqiqagacha) yoqilishi bilan darhol chaladi.
 */
public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent i) {
        String a = i == null ? null : i.getAction();
        boolean boot = a != null && (a.equals(Intent.ACTION_BOOT_COMPLETED)
                || a.equals("android.intent.action.LOCKED_BOOT_COMPLETED")
                || a.equals("android.intent.action.QUICKBOOT_POWERON")
                || a.equals("com.htc.intent.action.QUICKBOOT_POWERON"));
        boolean restart = boot || (a != null && a.equals(Intent.ACTION_MY_PACKAGE_REPLACED));
        try {
            Notif.channels(c);
        } catch (Exception e) {
        }
        if (boot) Store.catchUpAlarms(c);
        Store.scheduleAlarms(c);
        try {
            TimerN.restore(c);
        } catch (Exception e) {
        }
        // qayta yoqilganda telefon o'chiq paytda o'tib ketgan (45 daqiqagacha) bildirishnomalar ham ko'rsatiladi
        try {
            Store.scheduleNotifs(c, true, restart);
        } catch (Exception e) {
        }
        try {
            TrackerWidget.updateAll(c);
        } catch (Exception e) {
        }
        // sayt bloklash yoqilgan bo'lsa, telefon qayta yoqilganda / ilova yangilanganda VPN (DNS filtr) qayta ishga tushadi
        try {
            if (restart && SiteBlk.on(c) && SiteBlk.vpn(c) && android.net.VpnService.prepare(c) == null) SiteVpn.start(c);
        } catch (Throwable e) {
        }
    }
}
