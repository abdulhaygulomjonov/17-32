package uz.sanalar.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class FocusEndReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent i) {
        Focus.clear(c);
    }
}
