package uz.sanalar.app;

import android.content.ComponentName;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.SystemClock;
import android.provider.Settings;

import org.json.JSONArray;

import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.HashSet;
import java.util.Set;

/** Ilovalarni bloklash: holat, parol va 24 soatlik kutish mantig'i. */
final class Blk {
    static final long MAXW = 365L * 24 * 3600 * 1000, MINW = 60000L;

    static long waitMs(Context c) {
        long w = p(c).getLong("blk_wait", 24L * 3600 * 1000);
        return Math.max(MINW, Math.min(MAXW, w));
    }

    static SharedPreferences p(Context c) {
        return Store.p(c);
    }

    /** Eski o'rnatishdan qolgan limit, filtr, sayt va VPN holatlarini tozalaydi. */
    static void purgeOld(Context c) {
        try {
            p(c).edit().putBoolean("blk_on", false).putLong("blk_req", 0).remove("blk_hash").remove("blk_salt")
                    .remove("blk_pkgs").putBoolean("al_on", false).putLong("al_req", 0).putBoolean("sb_on", false)
                    .putBoolean("sb_novpn", false).putLong("rel_start", 0).apply();
            Lim.clearAll(c);
            SiteVpn.stopIt(c);
        } catch (Throwable t) {
        }
    }

    static boolean on(Context c) {
        // ilovalarni cheklash (qattiq rejim) olib tashlangan: har doim o'chiq
        return false;
    }

    /** Alohida "bloklangan ilovalar" ro'yxati olib tashlangan: faqat kunlik limit qoldi. */
    static Set<String> pkgs(Context c) {
        return new HashSet<String>();
    }

    static void savePkgs(Context c, Set<String> s) {
        JSONArray a = new JSONArray();
        for (String x : s) a.put(x);
        p(c).edit().putString("blk_pkgs", a.toString()).apply();
    }

    static String hash(String salt, String pw) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] b = md.digest((salt + ":" + pw).getBytes("UTF-8"));
            StringBuilder sb = new StringBuilder();
            for (byte x : b) sb.append(String.format("%02x", x));
            return sb.toString();
        } catch (Exception e) {
            return "";
        }
    }

    static boolean pwOk(Context c, String pw) {
        SharedPreferences sp = p(c);
        String salt = sp.getString("blk_salt", "");
        return pw != null && salt.length() > 0 && hash(salt, pw).equals(sp.getString("blk_hash", "x"));
    }

    static void setPw(Context c, String pw) {
        byte[] r = new byte[12];
        new SecureRandom().nextBytes(r);
        StringBuilder sb = new StringBuilder();
        for (byte x : r) sb.append(String.format("%02x", x));
        p(c).edit().putString("blk_salt", sb.toString()).putString("blk_hash", hash(sb.toString(), pw)).apply();
    }

    static boolean a11y(Context c) {
        try {
            String s = Settings.Secure.getString(c.getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
            if (s == null) return false;
            String me = new ComponentName(c, BlkService.class).flattenToString();
            String me2 = new ComponentName(c, BlkService.class).flattenToShortString();
            for (String x : s.split(":")) if (x.equalsIgnoreCase(me) || x.equalsIgnoreCase(me2)) return true;
        } catch (Exception e) {
        }
        return false;
    }

    static int boot(Context c) {
        try {
            if (Build.VERSION.SDK_INT >= 24) return Settings.Global.getInt(c.getContentResolver(), Settings.Global.BOOT_COUNT, 0);
        } catch (Exception e) {
        }
        return 0;
    }

    static long reqAt(Context c) {
        return p(c).getLong("blk_req", 0);
    }

    static void requestOff(Context c) {
        if (reqAt(c) != 0) return;
        p(c).edit().putLong("blk_req", System.currentTimeMillis()).putLong("blk_req_el", SystemClock.elapsedRealtime())
                .putInt("blk_req_boot", boot(c)).apply();
    }

    static void cancelOff(Context c) {
        p(c).edit().putLong("blk_req", 0).apply();
    }

    /* ---- "Qattiq rejimni o'chirish" (avval 40 kunga yopilgan, endi qulf yo'q): 3 ekranli ruxsatlar to'liq berilgandan keyin hisoblanadi (faqat bir marta boshlanadi) ---- */
    static final long REL_MS = 0L; // kutish muddati olib tashlangan: "Qattiq rejimni o'chirish" istalgan payt ishlaydi

    static void relLockStart(Context c) {
        SharedPreferences sp = p(c);
        if (sp.getLong("rel_start", 0) != 0) return;
        sp.edit().putLong("rel_start", System.currentTimeMillis()).putLong("rel_start_el", SystemClock.elapsedRealtime())
                .putInt("rel_boot", boot(c)).apply();
    }

    /** Qulf tugaguncha qolgan millisekund (0 - qulf yo'q yoki tugagan). Soatni o'zgartirib aldab bo'lmaydi. */
    static long relLeftMs(Context c) {
        if (REL_MS <= 0) return 0;
        SharedPreferences sp = p(c);
        long st = sp.getLong("rel_start", 0);
        if (st == 0) return 0;
        long left = REL_MS - (System.currentTimeMillis() - st);
        if (sp.getInt("rel_boot", -1) == boot(c) && boot(c) != 0) {
            long left2 = REL_MS - (SystemClock.elapsedRealtime() - sp.getLong("rel_start_el", 0));
            if (left2 > left) left = left2;
        }
        return Math.max(0, left);
    }

    /** Kutish tugaguncha qolgan millisekund (soat o'zgartirilsa ham aldab bo'lmaydi). */
    static long remaining(Context c) {
        long r = reqAt(c);
        if (r == 0) return -1;
        SharedPreferences sp = p(c);
        long left = waitMs(c) - (System.currentTimeMillis() - r);
        if (sp.getInt("blk_req_boot", -1) == boot(c) && boot(c) != 0) {
            long left2 = waitMs(c) - (SystemClock.elapsedRealtime() - sp.getLong("blk_req_el", 0));
            if (left2 > left) left = left2;
        }
        if (left < 0) left = 0;
        return left;
    }
}
