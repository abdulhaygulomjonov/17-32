package uz.sanalar.app;

import android.app.Notification;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.provider.Settings;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;

import org.json.JSONArray;
import org.json.JSONObject;

/** Bildirishnoma filtri: ruxsat berilmagan ilovalarning bildirishnomalarini yashiradi va jurnalga yozadi. */
public class NotifFilter extends NotificationListenerService {
    @Override
    public void onNotificationPosted(StatusBarNotification sbn) {
        try {
            if (sbn == null || !Sess.flag(this, "nf", false)) return;
            String pkg = sbn.getPackageName();
            if (pkg == null || pkg.equals(getPackageName())) return;
            Notification n = sbn.getNotification();
            if (n == null) return;
            if (sbn.isOngoing() || (n.flags & Notification.FLAG_FOREGROUND_SERVICE) != 0) return;
            String cat = n.category;
            if (Notification.CATEGORY_CALL.equals(cat) || Notification.CATEGORY_ALARM.equals(cat)
                    || Notification.CATEGORY_REMINDER.equals(cat) || Notification.CATEGORY_NAVIGATION.equals(cat)
                    || Notification.CATEGORY_TRANSPORT.equals(cat) || Notification.CATEGORY_PROGRESS.equals(cat)
                    || Notification.CATEGORY_SYSTEM.equals(cat)) return;
            if (pkg.equals("android") || pkg.startsWith("com.android.systemui") || pkg.contains("dialer")
                    || pkg.contains("telecom") || pkg.contains("incallui") || pkg.contains("emergency")) return;
            if (Sess.set(this, "nfAllow").contains(pkg)) return;
            String title = "", text = "", name = pkg;
            Bundle e = n.extras;
            if (e != null) {
                CharSequence a = e.getCharSequence(Notification.EXTRA_TITLE), b = e.getCharSequence(Notification.EXTRA_TEXT);
                if (a != null) title = a.toString();
                if (b != null) text = b.toString();
            }
            try {
                PackageManager pm = getPackageManager();
                name = pm.getApplicationInfo(pkg, 0).loadLabel(pm).toString();
            } catch (Exception ex) {
            }
            log(this, pkg, name, title, text);
            cancelNotification(sbn.getKey());
        } catch (Throwable t) {
        }
    }

    static synchronized void log(Context c, String pkg, String name, String t, String x) {
        try {
            JSONArray old = new JSONArray(Store.p(c).getString("nf_log", "[]"));
            JSONArray nw = new JSONArray();
            nw.put(new JSONObject().put("p", pkg).put("a", name).put("t", cut(t)).put("x", cut(x)).put("w", System.currentTimeMillis()));
            for (int i = 0; i < old.length() && nw.length() < 100; i++) nw.put(old.get(i));
            Store.p(c).edit().putString("nf_log", nw.toString()).apply();
        } catch (Exception e) {
        }
    }

    private static String cut(String s) {
        return s.length() > 160 ? s.substring(0, 160) : s;
    }

    static String get(Context c) {
        return Store.p(c).getString("nf_log", "[]");
    }

    static void clear(Context c) {
        Store.p(c).edit().putString("nf_log", "[]").apply();
    }

    static boolean enabled(Context c) {
        try {
            String s = Settings.Secure.getString(c.getContentResolver(), "enabled_notification_listeners");
            return s != null && s.contains(c.getPackageName());
        } catch (Exception e) {
            return false;
        }
    }
}
