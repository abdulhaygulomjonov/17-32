package uz.sanalar.app;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.net.Uri;
import android.provider.Settings;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.os.VibrationEffect;
import org.json.JSONArray;
import org.json.JSONObject;
import android.os.Vibrator;

public class AlarmService extends Service {
    static volatile boolean running = false;
    static volatile boolean solved = true;
    static volatile String time = "", label = "";
    static AlarmService inst;
    // snooze va fon (budilnik sozlamalaridan)
    static volatile String alarmId = "", wallC1 = "", wallC2 = "", wallImg = "";
    static volatile int snMin = 0, snTimes = 0, snUsed = 0;

    private MediaPlayer mp;
    private Vibrator vib;
    private PowerManager.WakeLock wl;
    private final Handler h = new Handler(Looper.getMainLooper());
    private long lastLaunch = 0;

    // ovoz sozlamalari (sayt sozlamalaridan)
    private int vol = 100, rampS = 20, durS = 0, gapS = 0;
    private long playStart = 0, nextPlayAt = 0;
    private boolean playing = false, quietF = false;
    private int prevVol = -1;

    private final Runnable watch = new Runnable() {
        @Override
        public void run() {
            if (!running) return;
            if (!solved && !AlarmActivity.visible && System.currentTimeMillis() - lastLaunch > 1500) launch();
            h.postDelayed(this, 700);
        }
    };

    /** Ovozni sekin ko'tarish, davomiylik va takrorlashni boshqaradi. */
    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            if (!running || quietF) return;
            long now = System.currentTimeMillis();
            if (playing) {
                float el = (now - playStart) / 1000f;
                try {
                    if (mp != null) {
                        float g = level(el);
                        mp.setVolume(g, g);
                    }
                } catch (Exception e) {
                }
                if (durS > 0 && el >= durS) {
                    pausePlay();
                    if (gapS > 0) nextPlayAt = now + gapS * 1000L;
                }
            } else if (nextPlayAt > 0 && now >= nextPlayAt) {
                resumePlay();
            }
            h.postDelayed(this, 250);
        }
    };

    /** Budilnik xizmatini ishga tushiradi. Tizim cheklovi sabab bo'lmasa false qaytaradi. */
    static boolean ring(Context c, String t, String l, boolean test) {
        return ring(c, null, t, l, 0, test);
    }

    static boolean ring(Context c, String id, String t, String l, int used, boolean test) {
        Intent i = new Intent(c, AlarmService.class);
        i.putExtra("id", id == null ? "" : id);
        i.putExtra("u", used);
        i.putExtra("t", t == null ? "" : t);
        i.putExtra("l", l == null ? "" : l);
        try {
            if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(i);
            else c.startService(i);
            return true;
        } catch (Exception e) {
            try {
                c.startService(i);
                return true;
            } catch (Exception e2) {
                return false;
            }
        }
    }

    /** Foydalanuvchi misolni boshladi: musiqa va tebranish o'chadi, ekran esa yopilmaydi. */
    static void silence() {
        AlarmService s = inst;
        if (s != null) s.quiet();
    }

    /** Snooze hali mumkinmi (yoqilgan va marta tugamagan). */
    static boolean canSnooze() {
        return running && !solved && alarmId.length() > 0 && snMin > 0 && snUsed < snTimes;
    }

    /** Budilnikni snMin daqiqaga keyinga suradi. */
    static void snooze() {
        AlarmService s = inst;
        if (s != null && canSnooze()) s.doSnooze();
    }

    private void doSnooze() {
        try {
            Intent in = new Intent(this, AlarmReceiver.class);
            in.putExtra("id", alarmId);
            in.putExtra("t", time);
            in.putExtra("l", label);
            in.putExtra("u", snUsed + 1);
            PendingIntent pi = PendingIntent.getBroadcast(this, ("s" + alarmId).hashCode(), in, Store.flags());
            PendingIntent show = PendingIntent.getActivity(this, 1, new Intent(this, MainActivity.class), Store.flags());
            Store.am(this).setAlarmClock(new AlarmManager.AlarmClockInfo(System.currentTimeMillis() + snMin * 60000L, show), pi);
        } catch (Exception e) {
        }
        solved = true;
        finishRing();
    }

    /** Misollar to'liq yechildi. */
    static void done() {
        AlarmService s = inst;
        solved = true;
        if (s != null) s.finishRing();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    private float level(float el) {
        float f = rampS > 0 ? Math.min(1f, 0.04f + 0.96f * el / rampS) : 1f;
        return Store.gain(f * vol / 100f);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (running) return START_REDELIVER_INTENT;
        inst = this;
        running = true;
        solved = false;
        quietF = false;
        playing = false;
        nextPlayAt = 0;
        time = intent != null && intent.getStringExtra("t") != null ? intent.getStringExtra("t") : "";
        label = intent != null && intent.getStringExtra("l") != null ? intent.getStringExtra("l") : "";
        alarmId = intent != null && intent.getStringExtra("id") != null ? intent.getStringExtra("id") : "";
        snUsed = intent != null ? intent.getIntExtra("u", 0) : 0;
        snMin = 0;
        snTimes = 0;
        wallC1 = "";
        wallC2 = "";
        wallImg = "";
        if (alarmId.length() > 0) {
            try {
                JSONArray arr = new JSONArray(Store.p(this).getString(Store.AL, "[]"));
                for (int k = 0; k < arr.length(); k++) {
                    JSONObject o = arr.getJSONObject(k);
                    if (!alarmId.equals(o.optString("id"))) continue;
                    snMin = o.optInt("sn", 0);
                    snTimes = o.optInt("st", 0);
                    JSONArray wc = o.optJSONArray("wc");
                    if (wc != null && wc.length() > 1) {
                        wallC1 = wc.optString(0);
                        wallC2 = wc.optString(1);
                    }
                    wallImg = o.optString("wi", "");
                    break;
                }
            } catch (Exception e) {
            }
        }
        vol = Math.max(5, Math.min(100, Store.sndInt(this, "vol", 100)));
        rampS = Math.max(0, Store.sndInt(this, "ramp", 20));
        durS = Math.max(0, Store.sndInt(this, "dur", 0));
        gapS = Math.max(0, Store.sndInt(this, "gap", 0));

        Notif.channels(this);
        Intent ai = new Intent(this, AlarmActivity.class);
        ai.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pi = PendingIntent.getActivity(this, 3, ai, Store.flags());
        Notification.Builder b = Notif.builder(this, "alarm");
        Notif.brand(this, b)
                .setContentTitle("Uyg'otgich " + time)
                .setContentText(label.length() > 0 ? label : "O'chirish uchun misollarni yeching")
                .setContentIntent(pi)
                .setFullScreenIntent(pi, true)
                .setOngoing(true)
                .setCategory(Notification.CATEGORY_ALARM);
        if (Build.VERSION.SDK_INT < 26) b.setPriority(Notification.PRIORITY_MAX);
        Notification n = b.build();
        try {
            if (Build.VERSION.SDK_INT >= 29) startForeground(7001, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);
            else startForeground(7001, n);
        } catch (Exception e) {
            // oldinda ishga tushmasa ham ovoz va tebranish davom etadi
        }

        try {
            PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
            wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "tracker:alarm");
            wl.acquire(60 * 60 * 1000L);
        } catch (Exception e) {
        }
        startSound();
        launch();
        h.postDelayed(watch, 1000);
        h.postDelayed(tick, 250);
        // tizim xizmatni o'chirib qo'ysa, budilnik yechilmaguncha qayta ishga tushadi
        return START_REDELIVER_INTENT;
    }

    private void startSound() {
        try {
            AudioManager am = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
            prevVol = am.getStreamVolume(AudioManager.STREAM_ALARM);
            am.setStreamVolume(AudioManager.STREAM_ALARM, am.getStreamMaxVolume(AudioManager.STREAM_ALARM), 0);
        } catch (Exception e) {
        }
        // 1) foydalanuvchi musiqasi, 2-4) tizimning budilnik/qo'ng'iroq/bildirishnoma ovozi (birortasi albatta ishlaydi)
        mp = null;
        for (int k = 0; k < 4 && mp == null; k++) {
            MediaPlayer m = new MediaPlayer();
            try {
                if (k == 0) {
                    Store.setSource(this, m);
                } else {
                    Uri u = k == 1 ? Settings.System.DEFAULT_ALARM_ALERT_URI
                            : k == 2 ? Settings.System.DEFAULT_RINGTONE_URI : Settings.System.DEFAULT_NOTIFICATION_URI;
                    m.setDataSource(this, u);
                }
                m.setAudioAttributes(Store.alarmAttrs());
                m.setLooping(true);
                float g = level(0);
                m.setVolume(g, g);
                m.prepare();
                m.start();
                mp = m;
            } catch (Exception e) {
                try {
                    m.release();
                } catch (Exception e2) {
                }
            }
        }
        playing = true;
        playStart = System.currentTimeMillis();
        startVib();
    }

    private void startVib() {
        try {
            vib = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
            long[] pat = new long[]{0, 700, 400, 700, 400};
            if (Build.VERSION.SDK_INT >= 26) vib.vibrate(VibrationEffect.createWaveform(pat, 0));
            else vib.vibrate(pat, 0);
        } catch (Exception e) {
        }
    }

    private void pausePlay() {
        playing = false;
        try {
            if (mp != null && mp.isPlaying()) mp.pause();
        } catch (Exception e) {
        }
        try {
            if (vib != null) vib.cancel();
        } catch (Exception e) {
        }
    }

    private void resumePlay() {
        nextPlayAt = 0;
        playStart = System.currentTimeMillis();
        playing = true;
        try {
            if (mp != null) {
                float g = level(0);
                mp.setVolume(g, g);
                mp.start();
            }
        } catch (Exception e) {
        }
        startVib();
    }

    private void quiet() {
        quietF = true;
        h.removeCallbacks(tick);
        pausePlay();
    }

    private void restoreVolume() {
        try {
            if (prevVol >= 0) {
                ((AudioManager) getSystemService(Context.AUDIO_SERVICE)).setStreamVolume(AudioManager.STREAM_ALARM, prevVol, 0);
            }
        } catch (Exception e) {
        }
        prevVol = -1;
    }

    private void launch() {
        lastLaunch = System.currentTimeMillis();
        Intent i = new Intent(this, AlarmActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
        try {
            startActivity(i);
        } catch (Exception e) {
        }
    }

    private void finishRing() {
        running = false;
        h.removeCallbacks(watch);
        h.removeCallbacks(tick);
        try {
            if (mp != null) {
                mp.stop();
                mp.release();
                mp = null;
            }
        } catch (Exception e) {
        }
        try {
            if (vib != null) vib.cancel();
        } catch (Exception e) {
        }
        try {
            if (wl != null && wl.isHeld()) wl.release();
        } catch (Exception e) {
        }
        restoreVolume();
        stopForeground(true);
        stopSelf();
    }

    @Override
    public void onDestroy() {
        running = false;
        inst = null;
        h.removeCallbacks(watch);
        h.removeCallbacks(tick);
        try {
            if (mp != null) {
                mp.release();
                mp = null;
            }
            if (vib != null) vib.cancel();
            if (wl != null && wl.isHeld()) wl.release();
        } catch (Exception e) {
        }
        restoreVolume();
        super.onDestroy();
    }
}
