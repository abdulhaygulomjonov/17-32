package uz.sanalar.app;

import android.accessibilityservice.AccessibilityService;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.ColorSpace;
import android.graphics.Rect;
import android.hardware.HardwareBuffer;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.util.Log;
import android.view.Display;
import android.view.accessibility.AccessibilityEvent;

import org.tensorflow.lite.Interpreter;

import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Rasm filtri: ekran tasviri (Android 11+) qurilma ichidagi model bilan tekshiriladi, internet kerak emas.
 * Ochiq jinsiy a'zolar ("porn") va ichki kiyim / yarim yalang'och ("sexy") toifalari qattiq chegara bilan to'xtatiladi.
 * Aniqlik uchun butun ekran + 2x3 katak + o'rta kvadrat alohida tekshiriladi (kichik rasmlar ham ushlanadi).
 * Model: assets/nsfw.tflite (+ ixtiyoriy assets/nsfw_labels.txt). Model fayli bo'lmasa filtr jim turadi.
 */
final class ImgFilter {
    private static final String TAG = "ImgFilter";
    static final String K_ON = "img_on";
    static final String K_PORN = "img_t_porn";   // 0..100
    static final String K_SEXY = "img_t_sexy";
    static final String K_HENTAI = "img_t_hentai";

    private static final String[] DEF_LABELS = {"drawings", "hentai", "neutral", "porn", "sexy"};

    private static final ExecutorService EX = Executors.newSingleThreadExecutor();
    private static final Handler MAIN = new Handler(Looper.getMainLooper());

    private static Interpreter itp;
    private static boolean loadTried = false;
    private static String[] labels = DEF_LABELS;
    private static int inW = 224, inH = 224;
    private static boolean inFloat = true;
    private static int outN = 5;

    private static volatile boolean busy = false;
    private static volatile long lastShot = 0;
    private static volatile String curPkg = "";
    private static long evAt = 0;

    static boolean on(Context c) {
        return Store.p(c).getBoolean(K_ON, true);
    }

    static boolean ready(Context c) {
        return load(c.getApplicationContext());
    }

    /** Har bir hodisada chaqiriladi: arzon; haqiqiy tekshiruv kechiktirilib, ko'p hodisalar bitta bo'ladi. */
    static void tick(final AccessibilityService s, String pkg, int type, boolean ignore) {
        try {
            if (Build.VERSION.SDK_INT < 30) return;
            if (ignore || pkg == null) return;
            if (type != AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED && type != AccessibilityEvent.TYPE_VIEW_SCROLLED
                    && type != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return;
            if (!on(s)) return;
            curPkg = pkg;
            evAt = System.currentTimeMillis();
            MAIN.removeCallbacks(trigger);
            trigger = new Runnable() {
                @Override
                public void run() {
                    shoot(s);
                }
            };
            MAIN.postDelayed(trigger, 450);
        } catch (Throwable t) {
        }
    }

    private static Runnable trigger = new Runnable() {
        @Override
        public void run() {
        }
    };

    private static void shoot(final AccessibilityService s) {
        try {
            if (busy) {
                // band bo'lsa, birozdan keyin qayta urinadi (skroll to'xtagach oxirgi holat tekshirilsin)
                MAIN.removeCallbacks(trigger);
                trigger = new Runnable() {
                    @Override
                    public void run() {
                        shoot(s);
                    }
                };
                MAIN.postDelayed(trigger, 600);
                return;
            }
            long now = System.currentTimeMillis();
            if (now - lastShot < 800) {
                MAIN.removeCallbacks(trigger);
                trigger = new Runnable() {
                    @Override
                    public void run() {
                        shoot(s);
                    }
                };
                MAIN.postDelayed(trigger, 800 - (now - lastShot) + 20);
                return;
            }
            PowerManager pm = (PowerManager) s.getSystemService(Context.POWER_SERVICE);
            if (pm != null && !pm.isInteractive()) return;
            if (!load(s.getApplicationContext())) return;
            busy = true;
            lastShot = now;
            final String pkgNow = curPkg;
            s.takeScreenshot(Display.DEFAULT_DISPLAY, (Executor) EX, new AccessibilityService.TakeScreenshotCallback() {
                @Override
                public void onSuccess(AccessibilityService.ScreenshotResult r) {
                    Bitmap bmp = null;
                    try {
                        HardwareBuffer hb = r.getHardwareBuffer();
                        ColorSpace cs = r.getColorSpace();
                        Bitmap hw = Bitmap.wrapHardwareBuffer(hb, cs);
                        if (hw != null) bmp = hw.copy(Bitmap.Config.ARGB_8888, false);
                        try {
                            hb.close();
                        } catch (Throwable t) {
                        }
                        if (bmp != null && judge(s, bmp)) {
                            hit(s, pkgNow);
                        }
                    } catch (Throwable t) {
                        Log.w(TAG, "scan fail: " + t);
                    } finally {
                        if (bmp != null) bmp.recycle();
                        busy = false;
                    }
                }

                @Override
                public void onFailure(int code) {
                    busy = false;
                }
            });
        } catch (Throwable t) {
            busy = false;
        }
    }

    private static void hit(final AccessibilityService s, final String pkg) {
        MAIN.post(new Runnable() {
            @Override
            public void run() {
                try {
                    if (s instanceof BlkService) ((BlkService) s).imgHit(pkg);
                } catch (Throwable t) {
                }
            }
        });
    }

    /* ---------------- model ---------------- */
    private static synchronized boolean load(Context c) {
        if (itp != null) return true;
        if (loadTried) return false;
        loadTried = true;
        try {
            InputStream in = c.getAssets().open("nsfw.tflite");
            byte[] all = readAll(in);
            ByteBuffer mb = ByteBuffer.allocateDirect(all.length).order(ByteOrder.nativeOrder());
            mb.put(all);
            mb.rewind();
            Interpreter.Options o = new Interpreter.Options();
            o.setNumThreads(2);
            Interpreter i = new Interpreter(mb, o);
            int[] sh = i.getInputTensor(0).shape();   // [1,H,W,3]
            if (sh.length == 4) {
                inH = sh[1];
                inW = sh[2];
            }
            inFloat = i.getInputTensor(0).dataType() == org.tensorflow.lite.DataType.FLOAT32;
            if (i.getOutputTensor(0).dataType() != org.tensorflow.lite.DataType.FLOAT32) throw new Exception("model chiqishi float emas");
            int[] os = i.getOutputTensor(0).shape();
            outN = os[os.length - 1];
            try {
                String t = new String(readAll(c.getAssets().open("nsfw_labels.txt")), "UTF-8");
                String[] p = t.trim().split("[,\\s]+");
                if (p.length == outN) labels = p;
            } catch (Throwable e) {
                labels = outN == 5 ? DEF_LABELS : labels;
            }
            itp = i;
            return true;
        } catch (Throwable t) {
            Log.w(TAG, "model yo'q yoki o'qilmadi: " + t);
            return false;
        }
    }

    private static byte[] readAll(InputStream in) throws Exception {
        java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream();
        byte[] b = new byte[64 * 1024];
        int n;
        while ((n = in.read(b)) > 0) bo.write(b, 0, n);
        in.close();
        return bo.toByteArray();
    }

    private static int idx(String name) {
        for (int i = 0; i < labels.length; i++) if (labels[i].equalsIgnoreCase(name)) return i;
        return -1;
    }

    /** true: ekranda nomaqbul tasvir bor. Butun ekran, 2x3 katak va o'rta kvadrat tekshiriladi, eng yuqori ball olinadi. */
    private static boolean judge(Context c, Bitmap full) {
        SharedPreferences sp = Store.p(c);
        float tp = sp.getInt(K_PORN, 30) / 100f;      // ochiq jinsiy a'zo: past chegara = qattiq
        float ts = sp.getInt(K_SEXY, 60) / 100f;      // ichki kiyim / yarim yalang'och
        float th = sp.getInt(K_HENTAI, 60) / 100f;
        int ip = idx("porn"), is = idx("sexy"), ih = idx("hentai");
        int W = full.getWidth(), H = full.getHeight();
        // holat paneli va navigatsiya chizig'ini kesib tashlaymiz
        int top = (int) (H * 0.04f), bot = (int) (H * 0.97f);
        Rect[] rs = new Rect[8];
        int k = 0;
        rs[k++] = new Rect(0, top, W, bot);
        int hh = (bot - top) / 3;
        for (int r = 0; r < 3; r++) {
            for (int q = 0; q < 2; q++) {
                int x0 = q * (W / 2), x1 = x0 + W / 2;
                int y0 = top + r * hh, y1 = y0 + hh;
                rs[k++] = new Rect(x0, y0, x1, y1);
            }
        }
        int side = Math.min(W, bot - top);
        int cx = W / 2, cy = (top + bot) / 2;
        rs[k++] = new Rect(cx - side / 2, cy - side / 2, cx + side / 2, cy + side / 2);
        for (Rect r : rs) {
            float[] pr = classify(full, r);
            if (pr == null) continue;
            if (ip >= 0 && pr[ip] >= tp) return true;
            if (is >= 0 && pr[is] >= ts) return true;
            if (ih >= 0 && pr[ih] >= th) return true;
        }
        return false;
    }

    private static synchronized float[] classify(Bitmap full, Rect r) {
        Bitmap crop = null, sc = null;
        try {
            crop = Bitmap.createBitmap(full, r.left, r.top, r.width(), r.height());
            sc = Bitmap.createScaledBitmap(crop, inW, inH, true);
            int[] px = new int[inW * inH];
            sc.getPixels(px, 0, inW, 0, 0, inW, inH);
            ByteBuffer in = ByteBuffer.allocateDirect(inW * inH * 3 * (inFloat ? 4 : 1)).order(ByteOrder.nativeOrder());
            for (int p : px) {
                int rr = (p >> 16) & 0xFF, gg = (p >> 8) & 0xFF, bb = p & 0xFF;
                if (inFloat) {
                    in.putFloat(rr / 255f);
                    in.putFloat(gg / 255f);
                    in.putFloat(bb / 255f);
                } else {
                    in.put((byte) rr);
                    in.put((byte) gg);
                    in.put((byte) bb);
                }
            }
            in.rewind();
            float[][] out = new float[1][outN];
            itp.run(in, out);
            return out[0];
        } catch (Throwable t) {
            return null;
        } finally {
            if (sc != null && sc != crop) sc.recycle();
            if (crop != null && crop != full) crop.recycle();
        }
    }
}
