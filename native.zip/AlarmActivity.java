package uz.sanalar.app;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.LayerDrawable;
import android.util.Base64;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.text.InputType;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

public class AlarmActivity extends Activity {
    static volatile boolean visible = false;

    private final Random rnd = new Random();
    private int need = 3, lvl = 2, ok = 0;
    private String mode = "math";
    private JSONArray own = new JSONArray();
    private String qText;
    private String[] opts = new String[4];
    private int correct;
    private TextView tvDots, tvQ, tvMsg;
    private final Button[] btns = new Button[4];
    private boolean asked = false;
    private boolean typed = false;
    private int nOpts = 4;
    private long ansVal = 0;
    private EditText etIn;
    private Button btOk;
    private int lastOwn = -1;

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true);
            setTurnScreenOn(true);
        } else {
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED
                    | WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
                    | WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD);
        }
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        if (!AlarmService.running || AlarmService.solved) {
            finish();
            return;
        }
        try {
            android.content.SharedPreferences sp = Store.p(this);
            need = Math.max(1, sp.getInt(Store.NEED, 3));
            lvl = sp.getInt(Store.LVL, 2);
            mode = sp.getString(Store.MODE, "math");
            own = new JSONArray(sp.getString(Store.QS, "[]"));
        } catch (Exception e) {
        }

        final boolean off = "off".equals(mode);
        if (off) need = 1;

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setPadding(dp(22), dp(40), dp(22), dp(24));
        root.setBackgroundColor(Color.parseColor("#0A1622"));
        applyWall(root);

        TextView tvTime = text(AlarmService.time, 64, "#FFFFFF", true);
        root.addView(tvTime);
        TextView tvLabel = text((AlarmService.label.length() > 0 ? AlarmService.label + " · " : "")
                + (off ? "budilnikni o'chirish uchun tugmani bosing"
                : "o'chirish uchun " + need + " ta misolga ketma-ket to'g'ri javob bering"), 15, "#9FB4C2", false);
        tvLabel.setPadding(0, dp(4), 0, dp(14));
        root.addView(tvLabel);
        tvDots = text("", 26, "#34D1C0", false);
        root.addView(tvDots);
        tvQ = text("", 38, "#FFFFFF", true);
        tvQ.setPadding(0, dp(18), 0, dp(18));
        root.addView(tvQ);
        for (int i = 0; i < 4; i++) {
            final int k = i;
            Button bt = new Button(this);
            bt.setAllCaps(false);
            bt.setTextSize(22);
            bt.setTextColor(Color.WHITE);
            GradientDrawable g = new GradientDrawable();
            g.setColor(Color.parseColor("#17324A"));
            g.setCornerRadius(dp(16));
            bt.setBackground(g);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(62));
            lp.setMargins(0, dp(6), 0, dp(6));
            bt.setLayoutParams(lp);
            bt.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    answer(k);
                }
            });
            btns[i] = bt;
            root.addView(bt);
        }
        etIn = new EditText(this);
        etIn.setInputType(InputType.TYPE_CLASS_NUMBER);
        etIn.setTextSize(34);
        etIn.setTypeface(Typeface.DEFAULT_BOLD);
        etIn.setTextColor(Color.WHITE);
        etIn.setGravity(Gravity.CENTER_VERTICAL | Gravity.RIGHT);
        etIn.setSingleLine(true);
        etIn.setPadding(dp(20), 0, dp(20), 0);
        GradientDrawable eg = new GradientDrawable();
        eg.setColor(Color.parseColor("#243650"));
        eg.setStroke(dp(3), Color.parseColor("#5B9BFF"));
        eg.setCornerRadius(dp(24));
        etIn.setBackground(eg);
        LinearLayout.LayoutParams elp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(68));
        elp.setMargins(0, dp(6), 0, dp(6));
        etIn.setLayoutParams(elp);
        etIn.setVisibility(View.GONE);
        root.addView(etIn);
        btOk = new Button(this);
        btOk.setAllCaps(false);
        btOk.setTextSize(22);
        btOk.setTextColor(Color.WHITE);
        GradientDrawable og = new GradientDrawable();
        og.setColor(Color.parseColor("#17324A"));
        og.setCornerRadius(dp(16));
        btOk.setBackground(og);
        btOk.setText("OK");
        LinearLayout.LayoutParams olp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(62));
        olp.setMargins(0, dp(6), 0, dp(6));
        btOk.setLayoutParams(olp);
        btOk.setVisibility(View.GONE);
        btOk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                submitTyped();
            }
        });
        root.addView(btOk);
        tvMsg = text("", 16, "#F2B544", false);
        tvMsg.setPadding(0, dp(12), 0, 0);
        root.addView(tvMsg);
        if (AlarmService.canSnooze()) {
            Button sn = new Button(this);
            sn.setAllCaps(false);
            sn.setTextSize(18);
            sn.setTextColor(Color.parseColor("#F2B544"));
            sn.setText("Snooze · " + AlarmService.snMin + " daqiqa (" + (AlarmService.snTimes - AlarmService.snUsed) + " marta qoldi)");
            GradientDrawable sg = new GradientDrawable();
            sg.setColor(Color.parseColor("#99000000"));
            sg.setStroke(dp(2), Color.parseColor("#F2B544"));
            sg.setCornerRadius(dp(16));
            sn.setBackground(sg);
            LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(58));
            slp.setMargins(0, dp(14), 0, dp(6));
            sn.setLayoutParams(slp);
            sn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    AlarmService.snooze();
                    finish();
                }
            });
            root.addView(sn);
        }

        ScrollView sv = new ScrollView(this);
        sv.setFillViewport(true);
        sv.addView(root);
        setContentView(sv);
        next();
    }

    /** Budilnik foni: rasm yoki ikki rangli gradient, ustiga xira qatlam. */
    private void applyWall(View v) {
        try {
            Drawable base = null;
            if (AlarmService.wallImg.length() > 0) {
                String s = AlarmService.wallImg;
                int i = s.indexOf(',');
                byte[] d = Base64.decode(i >= 0 ? s.substring(i + 1) : s, Base64.DEFAULT);
                Bitmap bm = BitmapFactory.decodeByteArray(d, 0, d.length);
                if (bm != null) {
                    BitmapDrawable bd = new BitmapDrawable(getResources(), bm);
                    bd.setGravity(Gravity.FILL);
                    base = bd;
                }
            }
            if (base == null && AlarmService.wallC1.length() > 0) {
                base = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                        new int[]{Color.parseColor(AlarmService.wallC1), Color.parseColor(AlarmService.wallC2)});
            }
            if (base != null) {
                v.setBackground(new LayerDrawable(new Drawable[]{base, new ColorDrawable(0x59000000)}));
            }
        } catch (Throwable e) {
        }
    }

    private TextView text(String s, int sp, String color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(Color.parseColor(color));
        t.setGravity(Gravity.CENTER);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private int rn(int a, int b) {
        return a + rnd.nextInt(b - a + 1);
    }

    private void next() {
        typed = false;
        nOpts = 4;
        if ("off".equals(mode)) {
            qText = "";
            correct = 0;
            opts[0] = "O'chirish";
            render();
            return;
        }
        boolean useOwn = false;
        if (own.length() > 0 && ("own".equals(mode) || ("mix".equals(mode) && rnd.nextBoolean()))) useOwn = true;
        if (useOwn) {
            try {
                int idx = rnd.nextInt(own.length());
                if (own.length() > 1 && idx == lastOwn) idx = (idx + 1) % own.length();
                lastOwn = idx;
                JSONObject x = own.getJSONObject(idx);
                JSONArray oa = x.getJSONArray("o");
                List<Integer> order = new ArrayList<Integer>();
                for (int i = 0; i < 4; i++) order.add(i);
                Collections.shuffle(order, rnd);
                qText = x.getString("q");
                int c = x.getInt("c");
                for (int i = 0; i < 4; i++) {
                    opts[i] = oa.getString(order.get(i));
                    if (order.get(i) == c) correct = i;
                }
                render();
                return;
            } catch (Exception e) {
            }
        }
        math();
        render();
    }

    private void math() {
        long a, b, c, ans;
        String q;
        typed = lvl >= 2;
        nOpts = 3;
        if (lvl <= 1) {
            a = rn(1, 9);
            b = rn(1, 9);
            q = a + "+" + b;
            ans = a + b;
        } else if (lvl == 2) {
            a = rn(5, 9);
            b = rn(5, 9);
            q = a + "+" + b;
            ans = a + b;
        } else if (lvl == 3) {
            a = rn(11, 49);
            b = rn(11, 49);
            q = a + "+" + b;
            ans = a + b;
        } else if (lvl == 4) {
            a = rn(11, 59);
            b = rn(11, 59);
            c = rn(11, 59);
            q = a + "+" + b + "+" + c;
            ans = a + b + c;
        } else if (lvl == 5) {
            a = rn(21, 89);
            b = rn(3, 9);
            c = rn(11, 99);
            q = "(" + a + "×" + b + ")+" + c;
            ans = a * b + c;
        } else if (lvl == 6) {
            a = rn(21, 99);
            b = rn(11, 19);
            c = rn(101, 499);
            q = "(" + a + "×" + b + ")+" + c;
            ans = a * b + c;
        } else {
            a = rn(101, 299);
            b = rn(51, 99);
            c = rn(1001, 2999);
            q = "(" + a + "×" + b + ")+" + c;
            ans = a * b + c;
        }
        qText = q + " =";
        if (typed) {
            ansVal = ans;
            correct = 0;
            return;
        }
        List<Integer> o = new ArrayList<Integer>();
        o.add((int) ans);
        while (o.size() < 3) {
            int v = (int) ans + rn(1, 5) * (rnd.nextBoolean() ? 1 : -1);
            if (v >= 0 && !o.contains(v)) o.add(v);
        }
        Collections.shuffle(o, rnd);
        for (int i = 0; i < 3; i++) {
            opts[i] = String.valueOf(o.get(i));
            if (o.get(i) == (int) ans) correct = i;
        }
    }

    private void submitTyped() {
        String t = etIn.getText().toString().trim();
        if (t.length() == 0) return;
        boolean good = false;
        try {
            good = Long.parseLong(t) == ansVal;
        } catch (Exception e) {
        }
        answer(good ? correct : -1);
    }

    private void render() {
        if ("off".equals(mode)) {
            tvDots.setVisibility(View.GONE);
            tvQ.setVisibility(View.GONE);
            etIn.setVisibility(View.GONE);
            btOk.setVisibility(View.GONE);
            btns[0].setText(opts[0]);
            for (int i = 1; i < 4; i++) btns[i].setVisibility(View.GONE);
            return;
        }
        StringBuilder d = new StringBuilder();
        for (int i = 0; i < need; i++) d.append(i < ok ? "● " : "○ ");
        tvDots.setText(d.toString().trim());
        tvQ.setText(qText);
        boolean own = !typed && nOpts == 4;
        for (int i = 0; i < 4; i++) {
            btns[i].setVisibility(!typed && i < nOpts ? View.VISIBLE : View.GONE);
            btns[i].setText(own ? "ABCD".charAt(i) + ")  " + opts[i] : opts[i]);
        }
        etIn.setVisibility(typed ? View.VISIBLE : View.GONE);
        btOk.setVisibility(typed ? View.VISIBLE : View.GONE);
        if (typed) {
            etIn.setText("");
            etIn.requestFocus();
            etIn.postDelayed(new Runnable() {
                @Override
                public void run() {
                    try {
                        InputMethodManager im = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
                        im.showSoftInput(etIn, InputMethodManager.SHOW_IMPLICIT);
                    } catch (Exception e) {
                    }
                }
            }, 150);
        }
    }

    private void answer(int k) {
        if (!asked) {
            asked = true;
            AlarmService.silence();
        }
        if (k == correct) {
            ok++;
            if (ok >= need) {
                AlarmService.done();
                finish();
                return;
            }
            tvMsg.setText("To'g'ri! Yana " + (need - ok) + " ta qoldi");
        } else {
            ok = 0;
            tvMsg.setText("Noto'g'ri. Boshidan boshlang");
        }
        next();
    }

    @Override
    protected void onResume() {
        super.onResume();
        visible = true;
        if (!AlarmService.running || AlarmService.solved) finish();
    }

    @Override
    protected void onPause() {
        visible = false;
        super.onPause();
    }

    @Override
    public void onBackPressed() {
        /* orqaga qaytish o'chirilgan */
    }

    @Override
    public void onWindowFocusChanged(boolean f) {
        super.onWindowFocusChanged(f);
        if (f) {
            getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                    | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                    | View.SYSTEM_UI_FLAG_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        }
    }
}
