package uz.sanalar.app;

import android.Manifest;
import android.app.Activity;
import android.app.NotificationManager;
import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.content.ContentValues;
import android.provider.MediaStore;
import android.util.Base64;
import java.io.File;
import java.io.OutputStream;
import android.os.Build;
import android.os.Environment;
import android.os.PowerManager;
import android.provider.Settings;
import android.webkit.JavascriptInterface;

import androidx.biometric.BiometricManager;
import androidx.biometric.BiometricPrompt;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.FragmentActivity;

import org.json.JSONObject;

import java.util.Calendar;

public class NativeApi {
    private final Activity a;

    NativeApi(Activity a) {
        this.a = a;
    }

    /* ---------- budilnik ---------- */
    @JavascriptInterface
    public void sync(String alarms, int need, int lvl) {
        Store.saveAlarms(a, alarms, need, lvl);
    }

    @JavascriptInterface
    public void cfg(String mode, String qs) {
        Store.p(a).edit().putString(Store.MODE, mode).putString(Store.QS, qs).apply();
    }

    @JavascriptInterface
    public String popFired() {
        return Store.popFired(a);
    }

    @JavascriptInterface
    public void test() {
        Calendar c = Calendar.getInstance();
        String t = String.format("%02d:%02d", c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE));
        AlarmService.ring(a, t, "Sinov", true);
    }

    /* ---------- ruxsatlar ---------- */
    @JavascriptInterface
    public String permState() {
        JSONObject o = new JSONObject();
        try {
            boolean notif = Notif.canShow(a, null);
            if (Build.VERSION.SDK_INT >= 33 && a.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED)
                notif = false;
            boolean overlay = Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(a);
            boolean exact = true;
            if (Build.VERSION.SDK_INT >= 31) exact = Store.am(a).canScheduleExactAlarms();
            boolean fsi = true;
            if (Build.VERSION.SDK_INT >= 34)
                fsi = ((NotificationManager) a.getSystemService(Context.NOTIFICATION_SERVICE)).canUseFullScreenIntent();
            boolean battery = true;
            if (Build.VERSION.SDK_INT >= 23)
                battery = ((PowerManager) a.getSystemService(Context.POWER_SERVICE)).isIgnoringBatteryOptimizations(a.getPackageName());
            o.put("notif", notif).put("overlay", overlay).put("exact", exact).put("fsi", fsi).put("battery", battery);
            // ba'zi ishlab chiqaruvchilar (Xiaomi, Oppo, Vivo, Huawei...) ilovani fonda o'chirib qo'yadi – "avtoishga tushirish" kerak
            if (oemAuto()) o.put("auto", Store.p(a).getBoolean("auto_done", false));
            // 17-32 VPN (DNS filtr): yoqilgan bo'lsa tizim ruxsati ham berilgan bo'lishi kerak
            boolean modes = SiteBlk.on(a); // "Barcha qattiq rejimni o'chirish" bosilgan bo'lsa rejimlar talab qilinmaydi
            boolean vpnOk = true;
            try {
                if (modes && SiteBlk.vpn(a)) {
                    boolean pr = android.net.VpnService.prepare(a) == null;
                    if (pr && !SiteVpn.running) SiteVpn.start(a);
                    vpnOk = pr && SiteVpn.running; // ruxsat berilgan va VPN haqiqatan ishlab turibdi
                }
            } catch (Exception e) {
            }
            o.put("vpn", vpnOk).put("svc", !modes || BlkService.INST != null);
        } catch (Exception e) {
        }
        return o.toString();
    }

    private boolean oemAuto() {
        String m = (Build.MANUFACTURER + " " + Build.BRAND).toLowerCase(java.util.Locale.ROOT);
        String[] k = {"xiaomi", "redmi", "poco", "oppo", "realme", "oneplus", "vivo", "iqoo", "huawei", "honor",
                "samsung", "tecno", "infinix", "itel", "transsion", "meizu", "asus"};
        for (String x : k) if (m.contains(x)) return true;
        return false;
    }

    /** Ishlab chiqaruvchining "avtoishga tushirish / fonda ishlash" oynasini ochadi (topilmasa false). */
    private boolean openAutoStart() {
        String[][] t = {
                {"com.miui.securitycenter", "com.miui.permcenter.autostart.AutoStartManagementActivity"},
                {"com.coloros.safecenter", "com.coloros.safecenter.permission.startup.StartupAppListActivity"},
                {"com.coloros.safecenter", "com.coloros.safecenter.startupapp.StartupAppListActivity"},
                {"com.oppo.safe", "com.oppo.safe.permission.startup.StartupAppListActivity"},
                {"com.vivo.permissionmanager", "com.vivo.permissionmanager.activity.BgStartUpManagerActivity"},
                {"com.iqoo.secure", "com.iqoo.secure.ui.phoneoptimize.AddWhiteListActivity"},
                {"com.iqoo.secure", "com.iqoo.secure.ui.phoneoptimize.BgStartUpManager"},
                {"com.huawei.systemmanager", "com.huawei.systemmanager.startupmgr.ui.StartupNormalAppListActivity"},
                {"com.huawei.systemmanager", "com.huawei.systemmanager.optimize.process.ProtectActivity"},
                {"com.samsung.android.lool", "com.samsung.android.sm.battery.ui.BatteryActivity"},
                {"com.samsung.android.lool", "com.samsung.android.sm.ui.battery.BatteryActivity"},
                {"com.oneplus.security", "com.oneplus.security.chainlaunch.view.ChainLaunchAppListActivity"},
                {"com.transsion.phonemaster", "com.cyin.himgr.autostart.AutoStartActivity"},
                {"com.asus.mobilemanager", "com.asus.mobilemanager.autostart.AutoStartActivity"},
                {"com.meizu.safe", "com.meizu.safe.security.SHOW_APPSEC"}};
        for (String[] x : t) {
            try {
                Intent i = new Intent().setComponent(new android.content.ComponentName(x[0], x[1]));
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                if (a.getPackageManager().resolveActivity(i, 0) == null) continue;
                a.startActivity(i);
                return true;
            } catch (Exception e) {
            }
        }
        return false;
    }

    @JavascriptInterface
    public void perm(final String which) {
        a.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                try {
                    PermGate.open(a, which);
                    String pkg = "package:" + a.getPackageName();
                    Intent i = null;
                    if ("notif".equals(which)) {
                        boolean settings = true;
                        if (Build.VERSION.SDK_INT >= 33) {
                            boolean granted = a.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == android.content.pm.PackageManager.PERMISSION_GRANTED;
                            boolean asked = Store.p(a).getBoolean("notif_asked", false);
                            // 2 marta rad etilgach tizim oynasi chiqmaydi – to'g'ridan-to'g'ri sozlamalar ochiladi
                            if (!granted && (!asked || a.shouldShowRequestPermissionRationale(Manifest.permission.POST_NOTIFICATIONS))) {
                                Store.p(a).edit().putBoolean("notif_asked", true).apply();
                                a.requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 77);
                                settings = false;
                            }
                        }
                        if (settings)
                            i = new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, a.getPackageName());
                        else return;
                    } else if ("overlay".equals(which)) {
                        i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse(pkg));
                    } else if ("exact".equals(which)) {
                        i = new Intent("android.settings.REQUEST_SCHEDULE_EXACT_ALARM", Uri.parse(pkg));
                    } else if ("fsi".equals(which)) {
                        i = new Intent("android.settings.MANAGE_APP_USE_FULL_SCREEN_INTENT", Uri.parse(pkg));
                    } else if ("auto".equals(which)) {
                        Store.p(a).edit().putBoolean("auto_done", true).apply();
                        if (!openAutoStart()) i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse(pkg));
                    } else if ("battery".equals(which)) {
                        i = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse(pkg));
                    }
                    if (i != null) a.startActivity(i);
                } catch (Exception e) {
                    try {
                        a.startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + a.getPackageName())));
                    } catch (Exception e2) {
                    }
                }
            }
        });
    }

    /* ---------- taymer (ilova yopilsa ham ishlaydi) ---------- */
    @JavascriptInterface
    public void tmSync(String json) {
        TimerN.sync(a, json);
    }

    @JavascriptInterface
    public String tmState() {
        return TimerN.state(a);
    }

    /* ---------- bildirishnomalar ---------- */
    @JavascriptInterface
    public String liveSync(String json) {
        return Live.save(a, json);
    }

    @JavascriptInterface
    public void notifSync(String json) {
        Store.saveNotifs(a, json);
    }

    /** Haqiqiy yo'l bilan sinaydi: 5 soniyadan keyin AlarmManager orqali chiqadi (ekranni qulflab sinab ko'ring). false = ruxsat yo'q. */
    @JavascriptInterface
    public boolean notifTest() {
        Notif.channels(a);
        if (!Notif.canShow(a, "dates")) return false;
        long when = System.currentTimeMillis() + 5000;
        Intent in = new Intent(a, NotifReceiver.class);
        in.putExtra("id", 9001).putExtra("ch", "dates").putExtra("title", "Sinov bildirishnomasi")
                .putExtra("body", "Bildirishnomalar ishlayapti.").putExtra("ts", when);
        android.app.PendingIntent pi = android.app.PendingIntent.getBroadcast(a, 9001, in, Store.flags());
        android.app.AlarmManager am = Store.am(a);
        Store.setExact(am, when, pi, Store.canExact(am));
        return true;
    }

    @JavascriptInterface
    public void notifSettings() {
        a.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                try {
                    a.startActivity(new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, a.getPackageName()));
                } catch (Exception e) {
                }
            }
        });
    }

    /* ---------- budilnik ovozi ---------- */
    @JavascriptInterface
    public void soundCfg(String json) {
        Store.saveSnd(a, json);
    }

    @JavascriptInterface
    public String soundInfo() {
        JSONObject o = new JSONObject();
        try {
            o.put("has", Store.sndFile(a).exists());
            o.put("name", Store.p(a).getString(Store.SNDN, ""));
        } catch (Exception e) {
        }
        return o.toString();
    }

    @JavascriptInterface
    public void soundPick() {
        a.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                try {
                    Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                    i.addCategory(Intent.CATEGORY_OPENABLE);
                    i.setType("audio/*");
                    a.startActivityForResult(i, MainActivity.RQ_SOUND);
                } catch (Exception e) {
                }
            }
        });
    }

    @JavascriptInterface
    public void soundClear() {
        try {
            Store.sndFile(a).delete();
            Store.p(a).edit().remove(Store.SNDN).apply();
        } catch (Exception e) {
        }
    }

    @JavascriptInterface
    public void soundPreview() {
        a.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                SndPreview.toggle(a);
            }
        });
    }

    /* ---------- ilovalarni bloklash ---------- */
    @JavascriptInterface
    public String blkApps() {
        org.json.JSONArray arr = new org.json.JSONArray();
        try {
            android.content.pm.PackageManager pm = a.getPackageManager();
            Intent q = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
            java.util.HashSet<String> seen = new java.util.HashSet<String>();
            java.util.ArrayList<String[]> L = new java.util.ArrayList<String[]>();
            for (android.content.pm.ResolveInfo r : pm.queryIntentActivities(q, 0)) {
                String p = r.activityInfo.packageName;
                if (p.equals(a.getPackageName()) || !seen.add(p)) continue;
                L.add(new String[]{r.loadLabel(pm).toString(), p});
            }
            java.util.Collections.sort(L, new java.util.Comparator<String[]>() {
                public int compare(String[] x, String[] y) {
                    return x[0].compareToIgnoreCase(y[0]);
                }
            });
            for (String[] x : L) arr.put(new JSONObject().put("n", x[0]).put("p", x[1]));
        } catch (Exception e) {
        }
        return arr.toString();
    }

    private final java.util.HashMap<String, String> icCache = new java.util.HashMap<String, String>();

    /** Ilovaning asl ikonkasi (launcher ikonkasi) data:image/png;base64 ko'rinishida */
    @JavascriptInterface
    public String appIcon(String pkg) {
        try {
            if (pkg == null || pkg.length() == 0) return "";
            synchronized (icCache) {
                String c = icCache.get(pkg);
                if (c != null) return c;
            }
            android.content.pm.PackageManager pm = a.getPackageManager();
            android.graphics.drawable.Drawable d = null;
            try {
                Intent li = pm.getLaunchIntentForPackage(pkg);
                if (li != null) d = pm.getActivityIcon(li);
            } catch (Throwable e) {
            }
            if (d == null) d = pm.getApplicationIcon(pkg);
            int sz = 120;
            android.graphics.Bitmap bm = android.graphics.Bitmap.createBitmap(sz, sz, android.graphics.Bitmap.Config.ARGB_8888);
            android.graphics.Canvas cv = new android.graphics.Canvas(bm);
            d.setBounds(0, 0, sz, sz);
            d.draw(cv);
            java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream();
            bm.compress(android.graphics.Bitmap.CompressFormat.PNG, 100, bo);
            bm.recycle();
            String r = "data:image/png;base64," + Base64.encodeToString(bo.toByteArray(), Base64.NO_WRAP);
            synchronized (icCache) {
                icCache.put(pkg, r);
            }
            return r;
        } catch (Throwable t) {
            return "";
        }
    }

    @JavascriptInterface
    public String blkState() {
        JSONObject o = new JSONObject();
        try {
            o.put("on", Blk.on(a)).put("a11y", Blk.a11y(a));
        } catch (Exception e) {
        }
        return o.toString();
    }

    @JavascriptInterface
    public void blkTexts(String json) {
        Blk.p(a).edit().putString("blk_txt", json).apply();
    }

    /* ---------- kunlik limitlar ---------- */
    @JavascriptInterface
    public String limGet() {
        return Lim.state(a);
    }

    /** json: {pkg:{m:daqiqa, d:[saytlar]}}. Yangi qo'shish mumkin; mavjudini o'zgartirish/olib tashlash 7 kundan keyin ("locked" qaytadi). */
    @JavascriptInterface
    public String limSet(String json) {
        return Lim.save(a, json);
    }

    /**
     * Yashirin bo'lim: ilovalarni cheklashni to'liq o'chirish. Barcha kunlik limitlar, bloklar,
     * "Va zinoga yaqinlashmanglar" filtri (so'z), vaqtli bloklar, jadvallar va Focus qulfi bekor qilinadi; 17-32ni o'chirish mumkin bo'ladi.
     */
    @JavascriptInterface
    public String blkRelease() {
        try {
            if (Blk.relLeftMs(a) > 0) return "locked"; // 40 kun ichida o'chirib bo'lmaydi
            Lim.clearAll(a);
            Blk.p(a).edit().putBoolean("blk_on", false).putLong("blk_req", 0).remove("blk_hash").remove("blk_salt").remove("blk_pkgs").apply();
            Blk.p(a).edit().putBoolean("al_on", false).putLong("al_req", 0).apply();
            SiteBlk.setOn(a, false);
            SiteBlk.setNoVpn(a, false);
            SiteVpn.stopIt(a);
            Focus.clear(a);
            Blk.p(a).edit().putString("sx_tb", "{}").putString("sx_sch", "[]").apply(); // vaqtli bloklar va jadvallar
            try {
                Sess.endSession(a);
            } catch (Exception ignored) {
            }
            return "ok";
        } catch (Exception e) {
            return "err";
        }
    }

    @JavascriptInterface
    public void relLockStart() {
        try {
            Blk.relLockStart(a);
        } catch (Exception ignored) {
        }
    }

    @JavascriptInterface
    public long relLockLeft() {
        try {
            return Blk.relLeftMs(a);
        } catch (Exception e) {
            return 0;
        }
    }

    @JavascriptInterface
    public void blkOpenA11y() {
        try {
            PermGate.open(a, "a11y");
            a.startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
        } catch (Exception e) {
        }
    }

    /* ---------- Focus: strict mode va to'liq ekran ---------- */
    @JavascriptInterface
    public void focusSet(int on, String modes, String pkgs, double until) {
        Focus.set(a, on == 1, modes, pkgs, (long) until);
    }

    @JavascriptInterface
    public String focusPerm() {
        JSONObject o = new JSONObject();
        try {
            o.put("a11y", Blk.a11y(a)).put("overlay", Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(a));
        } catch (Exception e) {
        }
        return o.toString();
    }

    @JavascriptInterface
    public void focusReq(String which) {
        try {
            PermGate.open(a, which);
            Intent i;
            if ("overlay".equals(which))
                i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + a.getPackageName()));
            else i = new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS);
            a.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
        } catch (Exception e) {
        }
    }

    @JavascriptInterface
    public void immersive(final boolean on) {
        a.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                try {
                    android.view.Window w = a.getWindow();
                    if (on) {
                        w.addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                        w.getDecorView().setSystemUiVisibility(android.view.View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                                | android.view.View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | android.view.View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                                | android.view.View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | android.view.View.SYSTEM_UI_FLAG_FULLSCREEN
                                | android.view.View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
                    } else {
                        w.clearFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                        w.getDecorView().setSystemUiVisibility(android.view.View.SYSTEM_UI_FLAG_VISIBLE);
                    }
                } catch (Exception e) {
                }
            }
        });
    }

    /** Oyna fonini sahifa fon rangiga moslaydi: telefon chetda bo'sh joy qoldirsa ham u sahifadan farq qilmaydi. css: "rgb(r, g, b)" */
    @JavascriptInterface
    public void winBg(final String css) {
        try {
            String[] p = css.replaceAll("[^0-9.,]", "").split(",");
            final int col = android.graphics.Color.rgb((int) Float.parseFloat(p[0]), (int) Float.parseFloat(p[1]), (int) Float.parseFloat(p[2]));
            a.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    try {
                        a.getWindow().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(col));
                        a.getWindow().getDecorView().setBackgroundColor(col);
                    } catch (Throwable t) {
                    }
                }
            });
        } catch (Throwable t) {
        }
    }

    /** Status bar va navigatsiya paneli rangini veb-sahifa rangiga moslaydi (jadval ekrani uchun). */
    @JavascriptInterface
    public void bar(final String top, final boolean topLight, final String bot, final boolean botLight) {
        a.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                try {
                    android.view.Window w = a.getWindow();
                    w.addFlags(android.view.WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
                    w.setStatusBarColor(android.graphics.Color.parseColor(top));
                    w.setNavigationBarColor(android.graphics.Color.parseColor(bot));
                    int v = w.getDecorView().getSystemUiVisibility();
                    if (android.os.Build.VERSION.SDK_INT >= 23) {
                        if (topLight) v |= android.view.View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
                        else v &= ~android.view.View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
                    }
                    if (android.os.Build.VERSION.SDK_INT >= 26) {
                        if (botLight) v |= android.view.View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
                        else v &= ~android.view.View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
                    }
                    w.getDecorView().setSystemUiVisibility(v);
                } catch (Exception e) {
                }
            }
        });
    }

    /* ---------- launcher (Home) rejimi ---------- */
    @JavascriptInterface
    public boolean isHome() {
        return MainActivity.HOME;
    }

    /** 17-32 hozir tizimning asosiy ekran ilovasi bo'lib o'rnatilganmi */
    @JavascriptInterface
    public boolean homeDefault() {
        try {
            Intent h = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME);
            android.content.pm.ResolveInfo r = a.getPackageManager().resolveActivity(h, android.content.pm.PackageManager.MATCH_DEFAULT_ONLY);
            return r != null && r.activityInfo != null && a.getPackageName().equals(r.activityInfo.packageName);
        } catch (Exception e) {
            return false;
        }
    }

    /** Qurilma qulfli bo'lsa, tizimning PIN/parol/barmoq izi oynasini darhol chiqaradi; qulf ochilgach go ishlaydi. */
    private void afterUnlock(final Runnable go) {
        a.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                try {
                    android.app.KeyguardManager km = (android.app.KeyguardManager) a.getSystemService(Context.KEYGUARD_SERVICE);
                    if (km != null && km.isKeyguardLocked() && Build.VERSION.SDK_INT >= 26) {
                        km.requestDismissKeyguard(a, new android.app.KeyguardManager.KeyguardDismissCallback() {
                            @Override
                            public void onDismissSucceeded() {
                                try {
                                    go.run();
                                } catch (Throwable t) {
                                }
                            }
                        });
                        return;
                    }
                } catch (Throwable t) {
                }
                try {
                    go.run();
                } catch (Throwable t) {
                }
            }
        });
    }

    @JavascriptInterface
    public boolean launchApp(final String pkg) {
        try {
            final Intent i = a.getPackageManager().getLaunchIntentForPackage(pkg);
            if (i == null) return false;
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            afterUnlock(new Runnable() {
                @Override
                public void run() {
                    a.startActivity(i);
                }
            });
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    @JavascriptInterface
    public void appInfo(final String pkg) {
        try {
            a.startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + pkg))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
        } catch (Exception e) {
        }
    }

    /** Bosh ekran rasmini tizim wallpaperi (bosh ekran + qulf ekrani) qilib o'rnatadi:
     *  oxirgi ilovalar oynasida ham telefonning eski wallpaperi emas, shu rasm ko'rinadi. */
    @JavascriptInterface
    public boolean setWall(String dataUrl) {
        try {
            if (dataUrl == null) return false;
            int c = dataUrl.indexOf(',');
            byte[] raw = Base64.decode(dataUrl.substring(c + 1), Base64.DEFAULT);
            final android.graphics.Bitmap bm = android.graphics.BitmapFactory.decodeByteArray(raw, 0, raw.length);
            if (bm == null) return false;
            new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        android.app.WallpaperManager wm = android.app.WallpaperManager.getInstance(a);
                        if (Build.VERSION.SDK_INT >= 24) {
                            wm.setBitmap(bm, null, true, android.app.WallpaperManager.FLAG_SYSTEM | android.app.WallpaperManager.FLAG_LOCK);
                        } else {
                            wm.setBitmap(bm);
                        }
                    } catch (Throwable t) {
                    }
                }
            }).start();
            return true;
        } catch (Throwable t) {
            return false;
        }
    }

    /** Tizimning "Asosiy ekran ilovasi" sozlamasini ochadi */
    @JavascriptInterface
    public void homeSet() {
        try {
            a.startActivity(new Intent(Settings.ACTION_HOME_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
        } catch (Exception e) {
            try {
                a.startActivity(new Intent(Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
            } catch (Exception e2) {
            }
        }
    }

    /** Ilova yorliqlari (LauncherApps). Faqat 17-32 asosiy ekran ilovasi bo'lganda ishlaydi. */
    @JavascriptInterface
    public String shortcuts(String pkg) {
        try {
            if (Build.VERSION.SDK_INT >= 25) return shortcutsImpl(pkg);
        } catch (Exception e) {
        }
        return "[]";
    }

    @android.annotation.TargetApi(25)
    private String shortcutsImpl(String pkg) throws Exception {
        org.json.JSONArray arr = new org.json.JSONArray();
        android.content.pm.LauncherApps la = (android.content.pm.LauncherApps) a.getSystemService(Context.LAUNCHER_APPS_SERVICE);
        if (la == null || !la.hasShortcutHostPermission()) return arr.toString();
        android.content.pm.LauncherApps.ShortcutQuery q = new android.content.pm.LauncherApps.ShortcutQuery();
        q.setPackage(pkg);
        q.setQueryFlags(android.content.pm.LauncherApps.ShortcutQuery.FLAG_MATCH_DYNAMIC
                | android.content.pm.LauncherApps.ShortcutQuery.FLAG_MATCH_MANIFEST
                | android.content.pm.LauncherApps.ShortcutQuery.FLAG_MATCH_PINNED);
        java.util.List<android.content.pm.ShortcutInfo> l = la.getShortcuts(q, android.os.Process.myUserHandle());
        if (l == null) return arr.toString();
        for (android.content.pm.ShortcutInfo si : l) {
            if (arr.length() >= 10) break;
            if (!si.isEnabled()) continue;
            CharSequence n = si.getShortLabel();
            if (n == null) n = si.getLongLabel();
            if (n == null) continue;
            arr.put(new JSONObject().put("id", si.getId()).put("n", n.toString()));
        }
        return arr.toString();
    }

    @JavascriptInterface
    public boolean startShortcut(String pkg, String id) {
        try {
            if (Build.VERSION.SDK_INT >= 25) return startShortcutImpl(pkg, id);
        } catch (Exception e) {
        }
        return false;
    }

    @android.annotation.TargetApi(25)
    private boolean startShortcutImpl(String pkg, String id) {
        android.content.pm.LauncherApps la = (android.content.pm.LauncherApps) a.getSystemService(Context.LAUNCHER_APPS_SERVICE);
        if (la == null) return false;
        la.startShortcut(pkg, id, null, null, android.os.Process.myUserHandle());
        return true;
    }

    /** Ikki marta bosib ekranni qulflash: 1 - bajarildi, 0 - xizmat yoqilmagan, -1 - Android 9 dan past */
    @JavascriptInterface
    public int lockScreen() {
        return BlkService.lock();
    }

    /** Launcherni o'ngga surganda: telefonning oddiy (17-32 bo'lmagan) bosh ekran ilovasini ochadi. 1 - ochildi, 0 - topilmadi */
    @JavascriptInterface
    public int openSysLauncher() {
        try {
            android.content.pm.PackageManager pm = a.getPackageManager();
            Intent h = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME);
            java.util.List<android.content.pm.ResolveInfo> l = pm.queryIntentActivities(h, 0);
            android.content.pm.ResolveInfo best = null;
            boolean bestSys = false;
            for (android.content.pm.ResolveInfo r : l) {
                if (r.activityInfo == null || a.getPackageName().equals(r.activityInfo.packageName)) continue;
                boolean sys = (r.activityInfo.applicationInfo.flags & android.content.pm.ApplicationInfo.FLAG_SYSTEM) != 0;
                if (best == null || (sys && !bestSys)) {
                    best = r;
                    bestSys = sys;
                }
            }
            if (best == null) return 0;
            Intent i = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
                    .setComponent(new ComponentName(best.activityInfo.packageName, best.activityInfo.name))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);
            a.startActivity(i);
            return 1;
        } catch (Throwable e) {
            return 0;
        }
    }

    /** Launcherni chapga surganda: tizimning "oxirgi ilovalar" oynasi. 1 - ochildi, 0 - xizmat yoqilmagan */
    @JavascriptInterface
    public int recents() {
        return BlkService.recents();
    }

    /** "17-32 bloklash" (Maxsus imkoniyatlar) xizmati yoqilganmi */
    @JavascriptInterface
    public boolean a11yOn() {
        try {
            return Blk.a11y(a);
        } catch (Exception e) {
            return false;
        }
    }

    /* ---------- So'z filtri ---------- */
    @JavascriptInterface
    public String alGet() {
        return Filtr.state(a).toString();
    }

    @JavascriptInterface
    public String alEnable(String pw, String waitMs) {
        long w;
        try {
            w = Long.parseLong(waitMs);
        } catch (Exception e) {
            return "bad_wait";
        }
        return Filtr.enable(a, pw, w);
    }

    @JavascriptInterface
    public String alRequestOff(String pw) {
        return Filtr.requestOff(a, pw);
    }

    @JavascriptInterface
    public void alCancelOff() {
        Filtr.cancelOff(a);
    }

    @JavascriptInterface
    public String alOff(String pw) {
        return Filtr.off(a, pw);
    }

    @JavascriptInterface
    public String alWords(String json) {
        return Filtr.setWords(a, json);
    }

    /* ---------- Sayt bloklash (yashirin bo'lim): lokal VPN (DNS filtr) + maxsus imkoniyat (brauzer manzil satri) ---------- */
    @JavascriptInterface
    public String sbGet() {
        JSONObject o = new JSONObject();
        try {
            o.put("on", SiteBlk.on(a)).put("vpn", SiteBlk.vpn(a)).put("novpn", SiteBlk.noVpn(a)).put("run", SiteVpn.running).put("a11y", Blk.a11y(a));
            boolean perm = true;
            try {
                perm = android.net.VpnService.prepare(a) == null;
            } catch (Exception e) {
            }
            o.put("perm", perm);
            String pd = "";
            try {
                pd = Settings.Global.getString(a.getContentResolver(), "private_dns_mode");
            } catch (Exception e) {
            }
            o.put("pdns", pd == null ? "" : pd);
            org.json.JSONArray d = new org.json.JSONArray();
            for (String x : SiteBlk.list(a)) d.put(x);
            o.put("domains", d);
        } catch (Exception e) {
        }
        return o.toString();
    }

    @JavascriptInterface
    public String sbDomains(String json) {
        return SiteBlk.setList(a, json);
    }

    /** "ok" - yoqildi; "ask" - VPN ruxsati so'raldi (natija MainActivity.onActivityResult'da). */
    @JavascriptInterface
    public String sbEnable() {
        try {
            final Intent i = android.net.VpnService.prepare(a);
            if (i != null) {
                a.runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            a.startActivityForResult(i, MainActivity.RQ_VPN);
                        } catch (Exception e) {
                        }
                    }
                });
                return "ask";
            }
            SiteBlk.setVpn(a, true);
            SiteBlk.setNoVpn(a, true);
            SiteBlk.setOn(a, true);
            SiteVpn.start(a);
            return "ok";
        } catch (Exception e) {
            return "err";
        }
    }

    /** Faqat maxsus imkoniyat (VPNsiz): boshqa VPN yoki shaxsiy DNS bilan birga ishlaydi. */
    @JavascriptInterface
    public String sbEnableA11y() {
        try {
            SiteBlk.setVpn(a, false);
            SiteBlk.setNoVpn(a, true);
            SiteBlk.setOn(a, true);
            SiteVpn.stopIt(a);
            return "ok";
        } catch (Exception e) {
            return "err";
        }
    }

    @JavascriptInterface
    public String sbNoVpn(boolean on) {
        if (!on && SiteBlk.on(a) && SiteBlk.noVpn(a)) return "locked";
        SiteBlk.setNoVpn(a, on);
        return "ok";
    }

    /** Tizimning VPN sozlamalari: 17-32 -> "Doimiy VPN" va "VPNsiz ulanishlarni bloklash". */
    @JavascriptInterface
    public void sbOpenVpnSettings() {
        SiteBlk.setGrace(a, System.currentTimeMillis() + 180000L); // 3 daqiqa: "Doimiy VPN" ni sozlash uchun
        try {
            a.startActivity(new Intent("android.settings.VPN_SETTINGS").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
        } catch (Exception e) {
            try {
                a.startActivity(new Intent(Settings.ACTION_WIRELESS_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
            } catch (Exception e2) {
            }
        }
    }

    /* ---------- minimalist rejim: vaqt so'rash, bloklar, jadvallar, filtr ---------- */
    @JavascriptInterface
    public String sxCfgGet() {
        return Sess.p(a).getString("sx_cfg", "{}");
    }

    @JavascriptInterface
    public void sxCfgSet(String json) {
        try {
            new JSONObject(json);
            Sess.p(a).edit().putString("sx_cfg", json).apply();
        } catch (Exception e) {
        }
    }

    @JavascriptInterface
    public String sxState() {
        JSONObject o = new JSONObject();
        try {
            o.put("a11y", Blk.a11y(a)).put("mono", Sess.monoOk(a)).put("nf", NotifFilter.enabled(a))
                    .put("nfCount", new org.json.JSONArray(NotifFilter.get(a)).length());
        } catch (Exception e) {
        }
        return o.toString();
    }

    /** Ilovani ochishdan oldin "qancha vaqt?" oynasini ko'rsatadi, tanlangach ilovani ochadi. */
    @JavascriptInterface
    public boolean sxAsk(String pkg) {
        try {
            final Intent ai = new Intent(a, AskActivity.class).putExtra("pkg", pkg).putExtra("mode", "ask").putExtra("launch", true)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NO_ANIMATION);
            afterUnlock(new Runnable() {
                @Override
                public void run() {
                    a.startActivity(ai);
                }
            });
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    /** ms <= 0 - butunlay bloklash. pkgs - JSON massiv. */
    @JavascriptInterface
    public void sxBlock(String pkgs, double ms) {
        try {
            org.json.JSONArray arr = new org.json.JSONArray(pkgs);
            for (int i = 0; i < arr.length(); i++) {
                String p = arr.getString(i);
                if (!p.equals(a.getPackageName())) Sess.blockFor(a, p, (long) ms);
            }
        } catch (Exception e) {
        }
    }

    /** Faqat "butunlay" bloklarni olib tashlash mumkin; vaqtli (1/2 soat) bloklar tugaguncha ochilmaydi. */
    @JavascriptInterface
    public boolean sxUnblock(String pkg) {
        return Sess.unblock(a, pkg);
    }

    @JavascriptInterface
    public String sxBlocks() {
        return Sess.tbActive(a);
    }

    @JavascriptInterface
    public String schedGet() {
        JSONObject o = new JSONObject();
        try {
            org.json.JSONArray arr = Sess.sch(a), out = new org.json.JSONArray();
            for (int i = 0; i < arr.length(); i++) {
                JSONObject s = arr.getJSONObject(i);
                JSONObject c = new JSONObject(s.toString());
                c.put("act", Sess.schedActiveNow(s));
                out.put(c);
            }
            o.put("list", out);
        } catch (Exception e) {
        }
        return o.toString();
    }

    @JavascriptInterface
    public String schedSave(String json) {
        return Sess.schedSave(a, json);
    }

    @JavascriptInterface
    public String nfLog() {
        return NotifFilter.get(a);
    }

    @JavascriptInterface
    public void nfClear() {
        NotifFilter.clear(a);
    }

    @JavascriptInterface
    public void nfOpenSettings() {
        try {
            a.startActivity(new Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
        } catch (Exception e) {
        }
    }

    /* ---------- barmoq izi ---------- */
    private static final int BIO_AUTH = BiometricManager.Authenticators.BIOMETRIC_STRONG
            | BiometricManager.Authenticators.BIOMETRIC_WEAK;

    @JavascriptInterface
    public boolean bioAvail() {
        try {
            return BiometricManager.from(a).canAuthenticate(BIO_AUTH) == BiometricManager.BIOMETRIC_SUCCESS;
        } catch (Throwable t) {
            return false;
        }
    }

    private void bioJs(final String js) {
        a.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                try {
                    ((MainActivity) a).getBridge().getWebView().evaluateJavascript(js, null);
                } catch (Throwable t) {
                }
            }
        });
    }

    @JavascriptInterface
    public void bioAuth() {
        a.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                try {
                    BiometricPrompt.PromptInfo info = new BiometricPrompt.PromptInfo.Builder()
                            .setTitle("17-32")
                            .setSubtitle("Barmoq izi bilan oching")
                            .setAllowedAuthenticators(BIO_AUTH)
                            .setNegativeButtonText("PIN")
                            .build();
                    new BiometricPrompt((FragmentActivity) a, ContextCompat.getMainExecutor(a),
                            new BiometricPrompt.AuthenticationCallback() {
                                @Override
                                public void onAuthenticationSucceeded(BiometricPrompt.AuthenticationResult r) {
                                    bioJs("window.lkBio&&window.lkBio(true)");
                                }

                                @Override
                                public void onAuthenticationError(int code, CharSequence msg) {
                                    bioJs("window.lkBio&&window.lkBio(false,'pin')");
                                }
                            }).authenticate(info);
                } catch (Throwable t) {
                    bioJs("window.lkBio&&window.lkBio(false,'pin')");
                }
            }
        });
    }

    @JavascriptInterface
    public void exitApp() {
        a.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                a.finish();
            }
        });
    }


    /** Save a vault item into the user's Downloads collection. */
    @JavascriptInterface
    public boolean saveVaultFile(String name, String mime, String base64) {
        if (name == null || base64 == null) return false;
        OutputStream out = null;
        Uri uri = null;
        try {
            byte[] data = Base64.decode(base64, Base64.DEFAULT);
            if (Build.VERSION.SDK_INT >= 29) {
                ContentValues values = new ContentValues();
                values.put(MediaStore.Downloads.DISPLAY_NAME, name.replace("/", "_").replace("\\", "_"));
                values.put(MediaStore.Downloads.MIME_TYPE, mime == null ? "application/octet-stream" : mime);
                values.put(MediaStore.Downloads.IS_PENDING, 1);
                uri = a.getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
                if (uri == null) return false;
                out = a.getContentResolver().openOutputStream(uri);
                if (out == null) throw new java.io.IOException("Output stream unavailable");
                out.write(data);
                out.flush();
                out.close(); out = null;
                values.clear();
                values.put(MediaStore.Downloads.IS_PENDING, 0);
                a.getContentResolver().update(uri, values, null, null);
                return true;
            }
            File dir = android.os.Environment.getExternalStoragePublicDirectory(android.os.Environment.DIRECTORY_DOWNLOADS);
            if (!dir.exists() && !dir.mkdirs()) return false;
            File target = new File(dir, name.replace("/", "_").replace("\\", "_"));
            out = new java.io.FileOutputStream(target);
            out.write(data); out.flush(); out.close(); out = null;
            return true;
        } catch (Exception e) {
            try { if (uri != null) a.getContentResolver().delete(uri, null, null); } catch (Exception ignored) {}
            return false;
        } finally {
            try { if (out != null) out.close(); } catch (Exception ignored) {}
        }
    }

    /* ---------- Yordamchi (suzuvchi) tugma: ilova yopiq bo'lsa ham ishlaydi ---------- */
    @JavascriptInterface
    public String astGet() {
        return FloatBtn.get(a);
    }

    @JavascriptInterface
    public void astSet(String json) {
        FloatBtn.set(a, json);
    }

    /** Native tugma ishlayaptimi (shunda sahifadagi nusxasi yashiriladi) */
    @JavascriptInterface
    public boolean astNative() {
        return FloatBtn.active();
    }

    /** Sahifa tugma ko'rinishi kerakmi (qulf/budilnik ekranida false) */
    @JavascriptInterface
    public void astVis(boolean v) {
        FloatBtn.jsVis(v);
    }

    /** Tugma menyusidan tanlangan, ilova ichida bajarilishi kerak bo'lgan amal */
    @JavascriptInterface
    public String astTake() {
        return FloatBtn.take();
    }
}
