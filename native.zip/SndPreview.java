package uz.sanalar.app;

import android.content.Context;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.Handler;
import android.os.Looper;

/** Sozlamalarda budilnik musiqasini eshitib ko'rish (8 soniya, yana bosilsa to'xtaydi). */
final class SndPreview {
    private static MediaPlayer mp;
    private static Context ctx;
    private static int prev = -1;
    private static final Handler h = new Handler(Looper.getMainLooper());
    private static final Runnable stopper = new Runnable() {
        @Override
        public void run() {
            stop();
        }
    };

    private SndPreview() {}

    static synchronized void toggle(Context c) {
        ctx = c.getApplicationContext();
        if (mp != null) {
            stop();
            return;
        }
        try {
            AudioManager am = (AudioManager) ctx.getSystemService(Context.AUDIO_SERVICE);
            prev = am.getStreamVolume(AudioManager.STREAM_ALARM);
            am.setStreamVolume(AudioManager.STREAM_ALARM, am.getStreamMaxVolume(AudioManager.STREAM_ALARM), 0);
            mp = new MediaPlayer();
            Store.setSource(ctx, mp);
            mp.setAudioAttributes(Store.alarmAttrs());
            mp.setLooping(true);
            float g = Store.gain(Store.sndInt(ctx, "vol", 100) / 100f);
            mp.setVolume(g, g);
            mp.prepare();
            mp.start();
            h.postDelayed(stopper, 8000);
        } catch (Exception e) {
            stop();
        }
    }

    static synchronized void stop() {
        h.removeCallbacks(stopper);
        try {
            if (mp != null) {
                mp.stop();
                mp.release();
            }
        } catch (Exception e) {
        }
        mp = null;
        try {
            if (ctx != null && prev >= 0) {
                ((AudioManager) ctx.getSystemService(Context.AUDIO_SERVICE)).setStreamVolume(AudioManager.STREAM_ALARM, prev, 0);
            }
        } catch (Exception e) {
        }
        prev = -1;
    }
}
