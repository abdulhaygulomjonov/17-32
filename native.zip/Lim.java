package uz.sanalar.app;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.SystemClock;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Calendar;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

/**
 * Ilovalar uchun kunlik limit. Limit qo'yilgan zahoti qattiq rejim (o'chirish / sozlama sahifalarini yopish) yoqiladi.
 * Limit tugagach ilova (va uning sayti) ertangi kungacha bloklanadi.
 * Qo'yilgan limitni 7 kun davomida tahrirlab ham, olib tashlab ham bo'lmaydi. Yangi ilova qo'shish mumkin.
 * Faqat yashirin bo'limdagi \"Ilovalarni cheklashni o'chirish\" (release) hammasini bekor qiladi.
 */
final class Lim {
    private static final String K_LIM = "lim_cfg", K_USE = "lim_use", K_HIT = "lim_hit", K_DAY = "lim_day";
    private static final Object LOCK = new Object();
    static final long LOCK_MS = 7L * 24 * 3600 * 1000;

    private static boolean loaded = false;
    private static String dayKey = "";
    private static long dayEl = 0, dayRem = 0;
    private static int dayBoot = 0;
    private static final Map<String, Long> use = new HashMap<String, Long>();
    private static long lastFlush = 0;
    private static boolean dirty = false;

    static SharedPreferences p(Context c) {
        return Store.p(c);
    }

    /* ---------- sozlama: {pkg: {m: daqiqa, d: [domenlar]}} ---------- */
    static JSONObject cfg(Context c) {
        try {
            JSONObject o = new JSONObject(p(c).getString(K_LIM, "{}"));
            boolean mig = false;
            Iterator<String> it = o.keys();
            while (it.hasNext()) {
                JSONObject v = o.optJSONObject(it.next());
                if (v != null && !v.has("t")) { // eski versiyadan qolgan limit: 7 kunlik qulf hozirdan boshlanadi
                    stamp(c, v);
                    mig = true;
                }
            }
            if (mig) p(c).edit().putString(K_LIM, o.toString()).apply();
            return o;
        } catch (Exception e) {
            return new JSONObject();
        }
    }

    /** Qulf boshlanish vaqti: devor soati + elapsedRealtime + boot (soatni o'zgartirib aldab bo'lmasligi uchun). */
    private static void stamp(Context c, JSONObject v) {
        try {
            v.put("t", System.currentTimeMillis()).put("e", SystemClock.elapsedRealtime()).put("b", Blk.boot(c));
        } catch (Exception e) {
        }
    }

    /** Limitni tahrirlash/olib tashlash yana qancha vaqt (ms) mumkin emas. 0 - mumkin. */
    static long lockLeft(Context c, JSONObject v) {
        if (v == null) return 0;
        long t = v.optLong("t", 0);
        if (t == 0) return LOCK_MS;
        long left = LOCK_MS - (System.currentTimeMillis() - t);
        int b = v.optInt("b", 0);
        if (b != 0 && b == Blk.boot(c)) {
            long l2 = LOCK_MS - (SystemClock.elapsedRealtime() - v.optLong("e", 0));
            if (l2 > left) left = l2;
        }
        return Math.max(0, left);
    }

    /** Qattiq rejim limit bor ekan, doim yoqiq. */
    static boolean on(Context c) {
        return Blk.on(c) && cfg(c).length() > 0;
    }

    static long limitMs(Context c, String pkg) {
        JSONObject o = cfg(c).optJSONObject(pkg);
        if (o == null) return 0;
        int m = o.optInt("m", 0);
        return m >= 1 ? m * 60000L : 0;
    }

    static boolean has(Context c, String pkg) {
        return limitMs(c, pkg) > 0;
    }

    /**
     * Yangi ilova qo'shish har doim mumkin. Mavjud limitni o'zgartirish yoki olib tashlash faqat 7 kun o'tgach mumkin.
     * Qulf ichida o'zgartirishga urinilsa - hech narsa yozilmaydi va "locked" qaytadi.
     */
    static String save(Context c, String json) {
        try {
            JSONObject in = new JSONObject(json);
            JSONObject old = cfg(c);
            JSONObject out = new JSONObject();
            // eskilari: qulfdan chiqmagan bo'lsa, ro'yxatda bo'lishi shart
            Iterator<String> it = old.keys();
            while (it.hasNext()) {
                String k = it.next();
                JSONObject v = old.getJSONObject(k);
                if (!in.has(k)) {
                    if (lockLeft(c, v) > 0) return "locked"; // olib tashlab bo'lmaydi
                    continue;
                }
                out.put(k, new JSONObject(v.toString()));
            }
            it = in.keys();
            while (it.hasNext()) {
                String pkg = it.next();
                if (pkg.equals(c.getPackageName())) continue;
                JSONObject v = in.optJSONObject(pkg);
                if (v == null) continue;
                int m = v.optInt("m", 0);
                if (m < 1 || m > 1440) continue;
                Set<String> nds = new HashSet<String>();
                JSONArray nd = v.optJSONArray("d");
                if (nd != null) for (int i = 0; i < nd.length(); i++) {
                    String d = nd.optString(i).trim().toLowerCase(java.util.Locale.ROOT);
                    if (d.length() > 2 && d.length() < 80 && d.matches("[a-z0-9.\\-]+")) nds.add(d);
                }
                JSONObject cur = out.optJSONObject(pkg);
                if (cur != null) {
                    Set<String> ods = new HashSet<String>();
                    JSONArray od = cur.optJSONArray("d");
                    if (od != null) for (int i = 0; i < od.length(); i++) ods.add(od.optString(i));
                    boolean same = cur.optInt("m", 0) == m && ods.equals(nds);
                    if (same) continue; // o'zgarmagan
                    if (lockLeft(c, cur) > 0) return "locked"; // 7 kun tahrirlab bo'lmaydi
                }
                JSONObject nv = new JSONObject().put("m", m);
                JSONArray da = new JSONArray();
                for (String d : nds) da.put(d);
                nv.put("d", da);
                stamp(c, nv);
                out.put(pkg, nv);
            }
            p(c).edit().putString(K_LIM, out.toString()).putBoolean("blk_on", out.length() > 0).apply();
            return "ok";
        } catch (Exception e) {
            return "err";
        }
    }

    /** Yashirin bo'limdan: barcha limitlar, hisob va bloklarni to'liq bekor qiladi (7 kunlik qulf ham). */
    static void clearAll(Context c) {
        synchronized (LOCK) {
            use.clear();
            dirty = false;
            loaded = false;
            dayKey = "";
            p(c).edit().remove(K_LIM).remove(K_USE).remove(K_HIT).remove(K_DAY).putBoolean("blk_on", false).apply();
        }
    }

    /* ---------- kun hisobi (soatni o'zgartirib aldab bo'lmasligi uchun elapsedRealtime bilan tekshiriladi) ---------- */
    private static String keyOf(long t) {
        Calendar c = Calendar.getInstance();
        c.setTimeInMillis(t);
        return c.get(Calendar.YEAR) + "-" + (c.get(Calendar.MONTH) + 1) + "-" + c.get(Calendar.DAY_OF_MONTH);
    }

    static long nextMidnight(long t) {
        Calendar c = Calendar.getInstance();
        c.setTimeInMillis(t);
        c.set(Calendar.HOUR_OF_DAY, 0);
        c.set(Calendar.MINUTE, 0);
        c.set(Calendar.SECOND, 0);
        c.set(Calendar.MILLISECOND, 0);
        c.add(Calendar.DAY_OF_MONTH, 1);
        return c.getTimeInMillis();
    }

    private static void load(Context c) {
        if (loaded) return;
        loaded = true;
        try {
            JSONObject d = new JSONObject(p(c).getString(K_DAY, "{}"));
            dayKey = d.optString("k", "");
            dayEl = d.optLong("e", 0);
            dayRem = d.optLong("r", 0);
            dayBoot = d.optInt("b", 0);
            JSONObject u = new JSONObject(p(c).getString(K_USE, "{}"));
            Iterator<String> it = u.keys();
            while (it.hasNext()) {
                String k = it.next();
                use.put(k, u.optLong(k, 0));
            }
        } catch (Exception e) {
        }
    }

    private static void persist(Context c) {
        try {
            JSONObject u = new JSONObject();
            for (Map.Entry<String, Long> e : use.entrySet()) u.put(e.getKey(), e.getValue());
            JSONObject d = new JSONObject().put("k", dayKey).put("e", dayEl).put("r", dayRem).put("b", dayBoot);
            p(c).edit().putString(K_USE, u.toString()).putString(K_DAY, d.toString()).apply();
            lastFlush = SystemClock.elapsedRealtime();
            dirty = false;
        } catch (Exception e) {
        }
    }

    /** Yangi kun boshlandimi? Soat oldinga surilsa, haqiqiy vaqt (elapsedRealtime) o'tmaguncha yangi kun hisoblanmaydi. */
    private static void roll(Context c) {
        load(c);
        long now = System.currentTimeMillis(), el = SystemClock.elapsedRealtime();
        int boot = Blk.boot(c);
        String key = keyOf(now);
        if (dayKey.length() == 0) {
            dayKey = key;
            dayEl = el;
            dayRem = nextMidnight(now) - now;
            dayBoot = boot;
            persist(c);
            return;
        }
        if (key.equals(dayKey)) {
            if (boot != 0 && boot != dayBoot) { // telefon qayta yoqilgan: tayanch nuqtani yangilaymiz
                dayBoot = boot;
                dayEl = el;
                dayRem = nextMidnight(now) - now;
                dirty = true;
            }
            return;
        }
        boolean ok = boot == 0 || boot != dayBoot || el - dayEl >= dayRem - 60000L;
        if (!ok) return;
        dayKey = key;
        dayEl = el;
        dayRem = nextMidnight(now) - now;
        dayBoot = boot;
        use.clear();
        persist(c);
    }

    /** Hisobdagi kun tugashigacha qolgan vaqt (ms). Soat surilgan bo'lsa, haqiqiy o'tgan vaqtga tayanadi. */
    private static long dayLeft(Context c, long now) {
        synchronized (LOCK) {
            roll(c);
            if (keyOf(now).equals(dayKey)) return Math.max(1000L, nextMidnight(now) - now);
            long el = SystemClock.elapsedRealtime();
            return Math.max(60000L, dayRem - (el - dayEl));
        }
    }

    static long used(Context c, String pkg) {
        synchronized (LOCK) {
            roll(c);
            Long v = use.get(pkg);
            return v == null ? 0 : v;
        }
    }

    static void add(Context c, String pkg, long ms) {
        if (ms <= 0) return;
        synchronized (LOCK) {
            roll(c);
            Long v = use.get(pkg);
            use.put(pkg, (v == null ? 0 : v) + ms);
            dirty = true;
            if (SystemClock.elapsedRealtime() - lastFlush > 5000) persist(c);
        }
    }

    static void flush(Context c) {
        synchronized (LOCK) {
            if (loaded && dirty) persist(c);
        }
    }

    /* ---------- limit tugashi ---------- */
    private static JSONObject hits(Context c) {
        try {
            return new JSONObject(p(c).getString(K_HIT, "{}"));
        } catch (Exception e) {
            return new JSONObject();
        }
    }

    /** Limit tugagan bo'lsa, shu ilovani ertangi kungacha bloklash yozuvini qo'shadi. true - endi bloklangan. */
    static boolean check(Context c, String pkg) {
        long lim = limitMs(c, pkg);
        if (lim <= 0) return false;
        long now = System.currentTimeMillis();
        if (until(c, pkg, now) > now) return true;
        if (used(c, pkg) < lim) return false;
        try {
            JSONObject h = hits(c);
            long left = dayLeft(c, now), w = now + left;
            JSONObject r = new JSONObject().put("w", w).put("e", SystemClock.elapsedRealtime() + left).put("b", Blk.boot(c));
            h.put(pkg, r);
            // eskirganlarini tozalaymiz
            Iterator<String> it = h.keys();
            java.util.ArrayList<String> dead = new java.util.ArrayList<String>();
            while (it.hasNext()) {
                String k = it.next();
                if (h.optJSONObject(k) == null || h.optJSONObject(k).optLong("w", 0) <= now) dead.add(k);
            }
            for (String k : dead) if (!k.equals(pkg)) h.remove(k);
            p(c).edit().putString(K_HIT, h.toString()).apply();
        } catch (Exception e) {
        }
        flush(c);
        return true;
    }

    /** Limit tufayli ilova qaysi paytgacha bloklangan (0 - bloklanmagan). Soat orqaga surilsa ham ochilmaydi. */
    static long until(Context c, String pkg, long now) {
        if (!Blk.on(c)) return 0;
        try {
            JSONObject h = hits(c).optJSONObject(pkg);
            if (h == null) return 0;
            long r = 0, w = h.optLong("w", 0);
            if (w > now) r = w;
            int b = h.optInt("b", 0);
            if (b != 0 && b == Blk.boot(c)) {
                long left = h.optLong("e", 0) - SystemClock.elapsedRealtime();
                if (left > 0) r = Math.max(r, now + left);
            }
            return r;
        } catch (Exception e) {
            return 0;
        }
    }

    static boolean anyHit(Context c) {
        if (!Blk.on(c)) return false;
        long now = System.currentTimeMillis();
        Iterator<String> it = cfg(c).keys();
        while (it.hasNext()) if (until(c, it.next(), now) > now) return true;
        return false;
    }

    /** Limiti tugagan ilovalarning qo'shimcha (foydalanuvchi kiritgan) saytlari. */
    static Set<String> hitDomains(Context c, long now) {
        Set<String> out = new HashSet<String>();
        if (!Blk.on(c)) return out;
        JSONObject cf = cfg(c);
        Iterator<String> it = cf.keys();
        while (it.hasNext()) {
            String pkg = it.next();
            if (until(c, pkg, now) <= now) continue;
            JSONArray d = cf.optJSONObject(pkg).optJSONArray("d");
            if (d != null) for (int i = 0; i < d.length(); i++) out.add(d.optString(i));
        }
        return out;
    }

    /** JS uchun holat: {on, list:{pkg:{m, d, used, until}}} */
    static String state(Context c) {
        JSONObject o = new JSONObject();
        try {
            long now = System.currentTimeMillis();
            JSONObject cf = cfg(c), list = new JSONObject();
            Iterator<String> it = cf.keys();
            while (it.hasNext()) {
                String k = it.next();
                JSONObject v = cf.getJSONObject(k);
                list.put(k, new JSONObject().put("m", v.optInt("m", 0)).put("d", v.optJSONArray("d") == null ? new JSONArray() : v.optJSONArray("d"))
                        .put("used", used(c, k)).put("until", until(c, k, now)).put("lock", lockLeft(c, v)));
            }
            o.put("on", Blk.on(c)).put("list", list);
        } catch (Exception e) {
        }
        return o.toString();
    }
}
