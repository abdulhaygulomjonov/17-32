package uz.sanalar.app;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

public class CrashActivity extends Activity {
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        final String log = String.valueOf(getIntent().getStringExtra("log"));
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(24, 80, 24, 24);
        TextView h = new TextView(this);
        h.setText("Ilova yiqildi. Shu matnning skrinshotini yuboring:");
        h.setTextSize(16);
        l.addView(h);
        Button cp = new Button(this);
        cp.setText("Nusxalash");
        cp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ((ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("log", log));
            }
        });
        l.addView(cp);
        ScrollView sv = new ScrollView(this);
        TextView t = new TextView(this);
        t.setText(log);
        t.setTextSize(11);
        t.setTextIsSelectable(true);
        sv.addView(t);
        l.addView(sv);
        setContentView(l);
    }
}
