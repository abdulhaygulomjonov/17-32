package uz.sanalar.app;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.os.Bundle;
import android.util.Base64;
import android.util.TypedValue;
import android.view.View;
import android.widget.RemoteViews;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Calendar;

public class TrackerWidget extends AppWidgetProvider {
    private static final int[] LINES = {R.id.l1, R.id.l2, R.id.l3, R.id.l4, R.id.l5, R.id.l6};

    @Override
    public void onUpdate(Context c, AppWidgetManager m, int[] ids) {
        for (int id : ids) m.updateAppWidget(id, build(c, m, id));
        schedule(c);
    }

    @Override
    public void onAppWidgetOptionsChanged(Context c, AppWidgetManager m, int id, Bundle opts) {
        m.updateAppWidget(id, build(c, m, id));
    }

    static void updateAll(Context c) {
        try {
            AppWidgetManager m = AppWidgetManager.getInstance(c);
            int[] ids = m.getAppWidgetIds(new ComponentName(c, TrackerWidget.class));
            for (int id : ids) m.updateAppWidget(id, build(c, m, id));
        } catch (Exception e) {
        }
    }

    static void schedule(Context c) {
        try {
            Calendar x = Calendar.getInstance();
            x.add(Calendar.DAY_OF_YEAR, 1);
            x.set(Calendar.HOUR_OF_DAY, 0);
            x.set(Calendar.MINUTE, 1);
            x.set(Calendar.SECOND, 0);
            Intent i = new Intent(c, TrackerWidget.class).setAction(AppWidgetManager.ACTION_APPWIDGET_UPDATE);
            AppWidgetManager m = AppWidgetManager.getInstance(c);
            i.putExtra(AppWidgetManager.EXTRA_APPWIDGET_IDS, m.getAppWidgetIds(new ComponentName(c, TrackerWidget.class)));
            PendingIntent pi = PendingIntent.getBroadcast(c, 9, i, Store.flags());
            Store.am(c).set(AlarmManager.RTC, x.getTimeInMillis(), pi);
        } catch (Exception e) {
        }
    }

    static Bitmap roundedBg(Context c, String data, int wdp, int hdp, int dim) {
        try {
            byte[] b = Base64.decode(data.substring(data.indexOf(',') + 1), Base64.DEFAULT);
            Bitmap src = BitmapFactory.decodeByteArray(b, 0, b.length);
            if (src == null) return null;
            float d = c.getResources().getDisplayMetrics().density;
            float w = Math.max(100f, wdp * d), h = Math.max(60f, hdp * d);
            float k = Math.min(1f, 560f / Math.max(w, h));
            int tw = Math.max(1, (int) (w * k)), th = Math.max(1, (int) (h * k));
            float sr = (float) src.getWidth() / src.getHeight(), tr = (float) tw / th;
            int cw = src.getWidth(), ch = src.getHeight();
            if (sr > tr) cw = (int) (ch * tr);
            else ch = (int) (cw / tr);
            int x = (src.getWidth() - cw) / 2, y = (src.getHeight() - ch) / 2;
            Bitmap crop = Bitmap.createBitmap(src, x, y, Math.max(1, cw), Math.max(1, ch));
            Bitmap scaled = Bitmap.createScaledBitmap(crop, tw, th, true);
            Bitmap out = Bitmap.createBitmap(tw, th, Bitmap.Config.ARGB_8888);
            Canvas cv = new Canvas(out);
            Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
            p.setShader(new BitmapShader(scaled, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP));
            float r = 20f * d * k;
            RectF rf = new RectF(0, 0, tw, th);
            cv.drawRoundRect(rf, r, r, p);
            if (dim > 0) {
                Paint p2 = new Paint(Paint.ANTI_ALIAS_FLAG);
                p2.setColor(Color.argb(Math.min(255, dim * 255 / 100), 0, 0, 0));
                cv.drawRoundRect(rf, r, r, p2);
            }
            return out;
        } catch (Throwable e) {
            return null;
        }
    }

    static RemoteViews build(Context c, AppWidgetManager m, int id) {
        int wdp = 250, hdp = 120;
        try {
            Bundle o = m.getAppWidgetOptions(id);
            wdp = o.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, wdp);
            hdp = o.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT, hdp);
        } catch (Exception e) {
        }
        RemoteViews rv = new RemoteViews(c.getPackageName(), R.layout.widget_tracker);
        String title = "Madeena", theme = "dark", bgData = "";
        int dim = 0;
        int size = 14;
        JSONArray lines = null;
        JSONObject dates = null;
        try {
            String s = Store.p(c).getString(Store.WID, "");
            if (s.length() > 0) {
                JSONObject o = new JSONObject(s);
                title = o.optString("title", title);
                theme = o.optString("theme", theme);
                size = o.optInt("size", 14);
                lines = o.optJSONArray("lines");
                dates = o.optJSONObject("dates");
                bgData = o.optString("bg", "");
                dim = o.optInt("dim", 0);
            }
        } catch (Exception e) {
        }
        int bg, fg, mu;
        if ("light".equals(theme)) {
            bg = R.drawable.widget_bg_light;
            fg = Color.parseColor("#0F2233");
            mu = Color.parseColor("#56707F");
        } else if ("glass".equals(theme)) {
            bg = R.drawable.widget_bg_glass;
            fg = Color.WHITE;
            mu = Color.parseColor("#D0DCE4");
        } else {
            bg = R.drawable.widget_bg_dark;
            fg = Color.parseColor("#E8F1F2");
            mu = Color.parseColor("#8CA5B3");
        }
        Bitmap bmp = bgData.length() > 0 ? roundedBg(c, bgData, wdp, hdp, dim) : null;
        if (bmp != null) {
            rv.setImageViewBitmap(R.id.wbg, bmp);
            rv.setViewVisibility(R.id.wbg, View.VISIBLE);
            rv.setInt(R.id.wroot, "setBackgroundColor", Color.TRANSPARENT);
            fg = Color.WHITE;
            mu = Color.parseColor("#E0E8EE");
        } else {
            rv.setViewVisibility(R.id.wbg, View.GONE);
            rv.setInt(R.id.wroot, "setBackgroundResource", bg);
        }
        rv.setTextViewText(R.id.wtitle, title);
        rv.setTextColor(R.id.wtitle, mu);
        rv.setViewVisibility(R.id.wtitle, title.length() > 0 ? View.VISIBLE : View.GONE);

        Calendar n = Calendar.getInstance();
        String key = String.format("%04d-%02d-%02d", n.get(Calendar.YEAR), n.get(Calendar.MONTH) + 1, n.get(Calendar.DAY_OF_MONTH));
        int shown = 0;
        for (int i = 0; i < LINES.length; i++) {
            String txt = "";
            try {
                if (lines != null && i < lines.length()) {
                    JSONObject l = lines.getJSONObject(i);
                    String k = l.optString("k"), lb = l.optString("lb"), v = l.optString("v");
                    if ("date_g".equals(k) || "date_h".equals(k)) {
                        JSONObject d = dates == null ? null : dates.optJSONObject(key);
                        v = d == null ? "" : d.optString("date_g".equals(k) ? "g" : "h", "");
                    }
                    if (v.length() > 0 || lb.length() > 0) txt = (lb.length() > 0 && v.length() > 0 ? lb + ": " : lb) + v;
                } else if (lines == null && i == 0) {
                    txt = "Sozlash uchun ilovani oching";
                }
            } catch (Exception e) {
            }
            if (txt.length() > 0) {
                rv.setTextViewText(LINES[i], txt);
                rv.setTextColor(LINES[i], fg);
                rv.setTextViewTextSize(LINES[i], TypedValue.COMPLEX_UNIT_SP, size);
                rv.setViewVisibility(LINES[i], View.VISIBLE);
                shown++;
            } else {
                rv.setViewVisibility(LINES[i], View.GONE);
            }
        }
        PendingIntent pi = PendingIntent.getActivity(c, 4, new Intent(c, MainActivity.class), Store.flags());
        rv.setOnClickPendingIntent(R.id.wroot, pi);
        return rv;
    }
}
