package uz.sanalar.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/** Ilova ochilganda "qancha vaqtdan keyin chiqasiz?" deb so'raydi; vaqt tugaganda ham chiqadi. */
public class AskActivity extends Activity {
    private final Handler h = new Handler(Looper.getMainLooper());
    private String pkg = "", mode = "ask";
    private boolean launch = false;
    private float d;
    private final java.util.ArrayList<View> gated = new java.util.ArrayList<View>();
    private int left = 0;
    private TextView breath;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        d = getResources().getDisplayMetrics().density;
        read(getIntent());
        build();
    }

    @Override
    protected void onNewIntent(Intent i) {
        super.onNewIntent(i);
        setIntent(i);
        read(i);
        build();
    }

    @Override
    protected void onResume() {
        super.onResume();
        Sess.askUp = true;
    }

    @Override
    protected void onPause() {
        Sess.askUp = false;
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        Sess.askUp = false;
        h.removeCallbacksAndMessages(null);
        super.onDestroy();
    }

    private void read(Intent i) {
        pkg = i.getStringExtra("pkg") == null ? "" : i.getStringExtra("pkg");
        mode = i.getStringExtra("mode") == null ? "ask" : i.getStringExtra("mode");
        launch = i.getBooleanExtra("launch", false);
    }

    private String label() {
        try {
            PackageManager pm = getPackageManager();
            return pm.getApplicationInfo(pkg, 0).loadLabel(pm).toString();
        } catch (Exception e) {
            return pkg;
        }
    }

    private static String fmt(long ms) {
        long m = ms / 60000;
        if (m >= 60 && m % 60 == 0) return (m / 60) + " soat";
        if (m >= 60) return (m / 60) + " soat " + (m % 60) + " daq";
        return m + " daq";
    }

    private Button btn(String t, boolean primary) {
        Button bt = new Button(this);
        bt.setText(t);
        bt.setAllCaps(false);
        bt.setTextColor(Color.WHITE);
        bt.setTextSize(16);
        GradientDrawable g = new GradientDrawable();
        g.setColor(primary ? Color.parseColor("#1f8a5b") : Color.parseColor("#26384a"));
        g.setCornerRadius(24 * d);
        bt.setBackground(g);
        bt.setPadding((int) (14 * d), (int) (10 * d), (int) (14 * d), (int) (10 * d));
        return bt;
    }

    private LinearLayout.LayoutParams lp(float w) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, w);
        p.setMargins((int) (4 * d), (int) (4 * d), (int) (4 * d), (int) (4 * d));
        return p;
    }

    private void build() {
        gated.clear();
        h.removeCallbacksAndMessages(null);
        boolean exp = "expired".equals(mode);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setPadding((int) (24 * d), (int) (56 * d), (int) (24 * d), (int) (24 * d));
        root.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{Color.parseColor("#0a1622"), Color.parseColor("#12392f")}));

        TextView nm = new TextView(this);
        nm.setText(label());
        nm.setTextColor(Color.parseColor("#7fd6a8"));
        nm.setTextSize(20);
        nm.setGravity(Gravity.CENTER);
        nm.setSingleLine(true);
        TextView tt = new TextView(this);
        tt.setText(exp ? "Vaqt tugadi" : "Qancha vaqtdan keyin chiqasiz?");
        tt.setTextColor(Color.WHITE);
        tt.setTextSize(24);
        tt.setTypeface(Typeface.DEFAULT_BOLD);
        tt.setGravity(Gravity.CENTER);
        tt.setPadding(0, (int) (14 * d), 0, (int) (6 * d));
        root.addView(nm);
        root.addView(tt);

        int mind = exp ? 0 : Sess.mindful(this);
        breath = new TextView(this);
        breath.setTextColor(Color.parseColor("#b8c7d4"));
        breath.setTextSize(15);
        breath.setGravity(Gravity.CENTER);
        breath.setPadding(0, 0, 0, (int) (12 * d));
        root.addView(breath);

        long[] o = Sess.opts(this);
        LinearLayout row = null;
        for (int i = 0; i < o.length; i++) {
            if (i % 2 == 0) {
                row = new LinearLayout(this);
                row.setOrientation(LinearLayout.HORIZONTAL);
                root.addView(row, new LinearLayout.LayoutParams(-1, -2));
            }
            final long ms = o[i];
            Button bt = btn((exp ? "Yana " : "") + fmt(ms), true);
            bt.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    choose(ms);
                }
            });
            gated.add(bt);
            row.addView(bt, lp(1));
            if (i == o.length - 1 && i % 2 == 0) row.addView(new View(this), lp(1));
        }
        LinearLayout r2 = new LinearLayout(this);
        r2.setOrientation(LinearLayout.HORIZONTAL);
        Button other = btn("Boshqa…", false);
        other.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                custom();
            }
        });
        gated.add(other);
        r2.addView(other, lp(1));
        root.addView(r2, new LinearLayout.LayoutParams(-1, -2));

        View gap = new View(this);
        root.addView(gap, new LinearLayout.LayoutParams(-1, (int) (18 * d)));
        Button ex = btn("Chiqish", false);
        ex.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                exit(0);
            }
        });
        Button exb = btn("Chiqish va 5 daqiqa bloklash", false);
        exb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                exit(5 * 60000L);
            }
        });
        LinearLayout.LayoutParams full = new LinearLayout.LayoutParams(-1, -2);
        full.setMargins((int) (4 * d), (int) (4 * d), (int) (4 * d), (int) (4 * d));
        root.addView(ex, full);
        root.addView(exb, full);

        ScrollView sv = new ScrollView(this);
        sv.setFillViewport(true);
        sv.addView(root);
        setContentView(sv);

        if (mind > 0) {
            left = mind;
            for (View v : gated) {
                v.setEnabled(false);
                v.setAlpha(0.35f);
            }
            tickBreath();
        } else {
            breath.setText(exp ? "Yana davom etasizmi yoki chiqasizmi?" : "Ongli tanlang: bu vaqt ichida nima qilmoqchisiz?");
        }
    }

    private void tickBreath() {
        if (left <= 0) {
            breath.setText("Endi tanlang");
            for (View v : gated) {
                v.setEnabled(true);
                v.setAlpha(1f);
            }
            return;
        }
        breath.setText("Chuqur nafas oling… " + left);
        left--;
        h.postDelayed(new Runnable() {
            @Override
            public void run() {
                tickBreath();
            }
        }, 1000);
    }

    private void custom() {
        final EditText et = new EditText(this);
        et.setInputType(InputType.TYPE_CLASS_NUMBER);
        et.setHint("daqiqa (1-600)");
        new AlertDialog.Builder(this).setTitle("Necha daqiqa?").setView(et)
                .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dlg, int w) {
                        try {
                            int m = Integer.parseInt(et.getText().toString().trim());
                            if (m >= 1 && m <= 600) choose(m * 60000L);
                        } catch (Exception e) {
                        }
                    }
                }).setNegativeButton("Bekor", null).show();
    }

    private void choose(long ms) {
        Sess.start(this, pkg, ms);
        if (launch) {
            try {
                Intent i = getPackageManager().getLaunchIntentForPackage(pkg);
                if (i != null) startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
            } catch (Exception e) {
            }
        }
        finish();
    }

    private void exit(long blockMs) {
        if (blockMs > 0 && pkg.length() > 0) Sess.blockFor(this, pkg, blockMs);
        Sess.endSession(this);
        Intent hm = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(hm);
        finish();
    }

    @Override
    public void onBackPressed() {
        exit(0);
    }
}
