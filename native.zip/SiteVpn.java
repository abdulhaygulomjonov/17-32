package uz.sanalar.app;

import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.LinkProperties;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.VpnService;
import android.os.ParcelFileDescriptor;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Sayt bloklash: lokal VPN orqali DNS filtr (NextDNS / Blokada kabi).
 * Faqat DNS so'rovlari (10.7.0.2:53) shu ilovaga keladi, boshqa trafik VPNsiz, odatdagidek ketadi.
 * Ro'yxatdagi domen (va uning quyi domenlari) uchun javob NXDOMAIN; qolganlari telefonning o'z DNS serveriga uzatiladi.
 * Tashqi serverga hech narsa yuborilmaydi.
 */
public class SiteVpn extends VpnService {
    static volatile boolean running = false;
    private static final String ADDR = "10.7.0.1";
    private static final String DNS = "10.7.0.2";

    private volatile ParcelFileDescriptor tun;
    private volatile Thread th;
    private volatile boolean stop = false;
    private volatile ExecutorService pool;
    private List<InetAddress> ups = new ArrayList<InetAddress>();
    private long upsAt = 0;

    static void start(Context c) {
        try {
            c.startService(new Intent(c, SiteVpn.class));
        } catch (Throwable t) {
        }
    }

    static void stopIt(Context c) {
        try {
            c.startService(new Intent(c, SiteVpn.class).setAction("stop"));
        } catch (Throwable t) {
        }
    }

    @Override
    public int onStartCommand(Intent i, int flags, int id) {
        if (i != null && "stop".equals(i.getAction())) {
            shut();
            stopSelf();
            return START_NOT_STICKY;
        }
        boolean need = SiteBlk.on(this) && SiteBlk.vpn(this);
        boolean perm = false;
        try {
            perm = VpnService.prepare(this) == null;
        } catch (Throwable t) {
        }
        if (!need || !perm) {
            shut();
            stopSelf();
            return START_NOT_STICKY;
        }
        if (tun == null || th == null || !th.isAlive()) open();
        return START_STICKY;
    }

    @Override
    public void onRevoke() {
        shut();
        if (SiteBlk.on(this) && SiteBlk.vpn(this)) {
            // foydalanuvchi uzib qo'ysa, 0.6 soniyadan keyin o'zi qayta ulanadi (boshqa VPN egallagan bo'lsa to'xtaydi)
            new android.os.Handler(android.os.Looper.getMainLooper()).postDelayed(new Runnable() {
                @Override
                public void run() {
                    try {
                        if (SiteBlk.on(SiteVpn.this) && SiteBlk.vpn(SiteVpn.this) && VpnService.prepare(SiteVpn.this) == null) {
                            open();
                            return;
                        }
                    } catch (Throwable t) {
                    }
                    stopSelf();
                }
            }, 600);
            return;
        }
        stopSelf();
        super.onRevoke();
    }

    @Override
    public void onDestroy() {
        shut();
        super.onDestroy();
    }

    private synchronized void open() {
        shut();
        ParcelFileDescriptor fd = null;
        try {
            Builder b = new Builder();
            b.setSession("Madeena saytlar filtri");
            b.addAddress(ADDR, 32);
            b.addDnsServer(DNS);
            b.addRoute(DNS, 32);
            b.setMtu(4200);
            b.setBlocking(true);
            fd = b.establish();
        } catch (Throwable t) {
            fd = null;
        }
        if (fd == null) return;
        tun = fd;
        stop = false;
        pool = Executors.newFixedThreadPool(6);
        final ParcelFileDescriptor f = fd;
        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                loop(f);
            }
        }, "madeena-dns");
        t.setDaemon(true);
        th = t;
        running = true;
        t.start();
    }

    private synchronized void shut() {
        stop = true;
        running = false;
        try {
            if (pool != null) pool.shutdownNow();
        } catch (Throwable t) {
        }
        pool = null;
        try {
            if (tun != null) tun.close();
        } catch (Throwable t) {
        }
        tun = null;
        th = null;
    }

    private void loop(ParcelFileDescriptor fd) {
        FileInputStream in = new FileInputStream(fd.getFileDescriptor());
        FileOutputStream out = new FileOutputStream(fd.getFileDescriptor());
        byte[] buf = new byte[8192];
        try {
            while (!stop && fd == tun) {
                int n = in.read(buf);
                if (n < 0) break;
                if (n < 28) continue;
                if (((buf[0] & 0xFF) >> 4) != 4) continue;
                int ihl = (buf[0] & 0x0F) * 4;
                if (ihl < 20 || n < ihl + 8) continue;
                if (buf[9] != 17) continue;
                if ((buf[16] & 0xFF) != 10 || (buf[17] & 0xFF) != 7 || buf[18] != 0 || (buf[19] & 0xFF) != 2) continue;
                int dport = ((buf[ihl + 2] & 0xFF) << 8) | (buf[ihl + 3] & 0xFF);
                if (dport != 53) continue;
                int ulen = ((buf[ihl + 4] & 0xFF) << 8) | (buf[ihl + 5] & 0xFF);
                int plen = Math.min(ulen - 8, n - ihl - 8);
                if (plen < 12) continue;
                byte[] q = new byte[plen];
                System.arraycopy(buf, ihl + 8, q, 0, plen);
                byte[] src = new byte[]{buf[12], buf[13], buf[14], buf[15]};
                int sport = ((buf[ihl] & 0xFF) << 8) | (buf[ihl + 1] & 0xFF);
                handle(q, src, sport, out);
            }
        } catch (Throwable t) {
        } finally {
            if (fd == tun) running = false;
        }
    }

    private void handle(final byte[] q, final byte[] src, final int sport, final FileOutputStream out) {
        String name = qname(q);
        if (name != null && SiteBlk.blocked(this, name)) {
            reply(out, src, sport, nx(q));
            return;
        }
        ExecutorService ex = pool;
        if (ex == null) return;
        try {
            ex.execute(new Runnable() {
                @Override
                public void run() {
                    byte[] r = forward(q);
                    if (r != null) reply(out, src, sport, r);
                }
            });
        } catch (Throwable t) {
        }
    }

    /** DNS so'rovidagi domen nomi (kichik harflarda), topilmasa null. */
    private static String qname(byte[] q) {
        int qd = ((q[4] & 0xFF) << 8) | (q[5] & 0xFF);
        if (qd < 1) return null;
        StringBuilder sb = new StringBuilder();
        int i = 12;
        while (i < q.length) {
            int l = q[i] & 0xFF;
            if (l == 0) return sb.length() > 0 ? sb.toString().toLowerCase(java.util.Locale.ROOT) : null;
            if ((l & 0xC0) != 0 || i + 1 + l > q.length) return null;
            if (sb.length() > 0) sb.append('.');
            for (int k = 0; k < l; k++) sb.append((char) (q[i + 1 + k] & 0xFF));
            i += l + 1;
        }
        return null;
    }

    /** NXDOMAIN javobi: sarlavha + savol qismi. */
    private static byte[] nx(byte[] q) {
        int i = 12;
        while (i < q.length && (q[i] & 0xFF) != 0) i += (q[i] & 0xFF) + 1;
        int end = Math.min(q.length, i + 1 + 4);
        byte[] r = new byte[end];
        System.arraycopy(q, 0, r, 0, end);
        r[2] = (byte) (0x80 | (q[2] & 0x01));
        r[3] = (byte) (0x80 | 0x03);
        r[4] = 0;
        r[5] = 1;
        r[6] = 0;
        r[7] = 0;
        r[8] = 0;
        r[9] = 0;
        r[10] = 0;
        r[11] = 0;
        return r;
    }

    /** So'rovni telefonning haqiqiy DNS serveriga (VPNdan tashqari) uzatadi. */
    private byte[] forward(byte[] q) {
        for (InetAddress up : upstreams()) {
            DatagramSocket s = null;
            try {
                s = new DatagramSocket();
                protect(s);
                s.setSoTimeout(3500);
                s.connect(up, 53);
                s.send(new DatagramPacket(q, q.length));
                byte[] rb = new byte[4096];
                DatagramPacket rp = new DatagramPacket(rb, rb.length);
                s.receive(rp);
                byte[] r = new byte[rp.getLength()];
                System.arraycopy(rb, 0, r, 0, r.length);
                return r;
            } catch (Throwable t) {
            } finally {
                try {
                    if (s != null) s.close();
                } catch (Throwable z) {
                }
            }
        }
        return null;
    }

    private synchronized List<InetAddress> upstreams() {
        long now = System.currentTimeMillis();
        if (!ups.isEmpty() && now - upsAt < 8000) return ups;
        List<InetAddress> out = new ArrayList<InetAddress>();
        try {
            ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
            Network[] ns = cm.getAllNetworks();
            if (ns != null) {
                for (Network n : ns) {
                    NetworkCapabilities nc = cm.getNetworkCapabilities(n);
                    if (nc == null || nc.hasTransport(NetworkCapabilities.TRANSPORT_VPN)) continue;
                    if (!nc.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)) continue;
                    LinkProperties lp = cm.getLinkProperties(n);
                    if (lp == null) continue;
                    for (InetAddress a : lp.getDnsServers()) {
                        if (a instanceof Inet4Address && !out.contains(a)) out.add(a);
                    }
                }
            }
        } catch (Throwable t) {
        }
        try {
            out.add(InetAddress.getByAddress(new byte[]{1, 1, 1, 1}));
            out.add(InetAddress.getByAddress(new byte[]{8, 8, 8, 8}));
        } catch (Throwable t) {
        }
        ups = out;
        upsAt = now;
        return out;
    }

    /** DNS javobini IPv4/UDP paketiga o'rab, TUN'ga yozadi. */
    private void reply(FileOutputStream out, byte[] dst, int dport, byte[] pl) {
        try {
            int total = 28 + pl.length;
            byte[] p = new byte[total];
            p[0] = 0x45;
            p[2] = (byte) (total >> 8);
            p[3] = (byte) total;
            p[6] = 0x40;
            p[8] = 64;
            p[9] = 17;
            p[12] = 10;
            p[13] = 7;
            p[14] = 0;
            p[15] = 2;
            System.arraycopy(dst, 0, p, 16, 4);
            int ck = csum(p, 20);
            p[10] = (byte) (ck >> 8);
            p[11] = (byte) ck;
            p[20] = 0;
            p[21] = 53;
            p[22] = (byte) (dport >> 8);
            p[23] = (byte) dport;
            int ul = 8 + pl.length;
            p[24] = (byte) (ul >> 8);
            p[25] = (byte) ul;
            System.arraycopy(pl, 0, p, 28, pl.length);
            synchronized (out) {
                out.write(p);
            }
        } catch (Throwable t) {
        }
    }

    private static int csum(byte[] b, int len) {
        long sum = 0;
        for (int i = 0; i + 1 < len; i += 2) sum += ((b[i] & 0xFF) << 8) | (b[i + 1] & 0xFF);
        while ((sum >> 16) != 0) sum = (sum & 0xFFFF) + (sum >> 16);
        return (int) (~sum & 0xFFFF);
    }
}
