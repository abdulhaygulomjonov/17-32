package uz.sanalar.app;

import android.app.NotificationManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.PowerManager;
import android.provider.Settings;

/**
 * Ruxsat oynasi: 17-32 ichidagi "Ruxsat berish" tugmasi bosilganda tegishli sozlama sahifasi
 * qisqa muddat (4 daqiqa) himoyadan ozod qilinadi. Faqat shu ruxsat hali berilmagan bo'lsa ishlaydi va
 * ruxsat berilishi bilan tez (4 soniyada) yopiladi. Boshqa yo'l bilan Sozlamalarga kirilsa himoya ishlayveradi.
 */
final class PermGate {
    static boolean granted(Context c, String w) {
        try {
            if ("a11y".equals(w)) return Blk.a11y(c);
            if ("notif".equals(w)) {
                boolean ok = Notif.canShow(c, null);
                if (Build.VERSION.SDK_INT >= 33 && c.checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED)
                    ok = false;
                return ok;
            }
            if ("overlay".equals(w)) return Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(c);
            if ("exact".equals(w)) return Build.VERSION.SDK_INT < 31 || Store.am(c).canScheduleExactAlarms();
            if ("fsi".equals(w))
                return Build.VERSION.SDK_INT < 34 || ((NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE)).canUseFullScreenIntent();
            if ("battery".equals(w))
                return Build.VERSION.SDK_INT < 23 || ((PowerManager) c.getSystemService(Context.POWER_SERVICE)).isIgnoringBatteryOptimizations(c.getPackageName());
        } catch (Throwable t) {
        }
        return false; // "auto" va noma'lumlar: muddat tugaguncha ochiq
    }

    static void open(Context c, String which) {
        try {
            Store.p(c).edit().putString("pg_which", which == null ? "" : which).putLong("pg_until", System.currentTimeMillis() + 240000L).apply();
        } catch (Throwable t) {
        }
    }

    static boolean active(Context c) {
        try {
            SharedPreferences p = Store.p(c);
            long now = System.currentTimeMillis();
            long u = p.getLong("pg_until", 0);
            if (u <= now) return false;
            String w = p.getString("pg_which", "");
            if (granted(c, w) && u > now + 4000) {
                u = now + 4000;
                p.edit().putLong("pg_until", u).apply();
            }
            return u > now;
        } catch (Throwable t) {
            return false;
        }
    }
}
