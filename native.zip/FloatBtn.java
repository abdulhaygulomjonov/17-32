package uz.sanalar.app;

import android.accessibilityservice.AccessibilityService;
import android.animation.ValueAnimator;
import android.app.KeyguardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.DashPathEffect;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Yordamchi (suzuvchi) tugma: ilova yopiq bo'lsa ham boshqa ilovalar ustida turadi.
 * Maxsus imkoniyatlar xizmati (BlkService) oynasi orqali chiziladi, shuning uchun alohida
 * "boshqa ilovalar ustida ko'rsatish" ruxsati shart emas. Tugmani surish mumkin (chetga yopishadi),
 * bosilganda ilovadagi bilan bir xil 3x3 tezkor menyu ochiladi.
 */
final class FloatBtn {
    /** Menyudan tanlangan, lekin hali ilova ichida bajarilmagan amal (qr, sn, dl, tl, pick) */
    static volatile String pending = null;
    /** Ilova ichidagi sahifa (qulf/budilnik ekrani) tugmani vaqtincha yashirishni so'ragan vaqt */
    static volatile long jsHideUntil = 0;

    private static final String K_ON = "ast_on", K_SIDE = "ast_side", K_Y = "ast_y", K_FAV = "ast_fav",
            K_TH = "ast_th", K_INIT = "ast_init";

    /* ------------------------------------------------------------------ JS <-> native holat */

    static String get(Context c) {
        JSONObject o = new JSONObject();
        try {
            SharedPreferences p = Store.p(c);
            JSONArray fav;
            try {
                fav = new JSONArray(p.getString(K_FAV, "[]"));
            } catch (Exception e) {
                fav = new JSONArray();
            }
            o.put("init", p.getBoolean(K_INIT, false) ? 1 : 0)
                    .put("on", p.getBoolean(K_ON, true))
                    .put("side", p.getInt(K_SIDE, 1))
                    .put("y", (double) p.getFloat(K_Y, 0.62f))
                    .put("fav", fav)
                    .put("a11y", Blk.a11y(c));
        } catch (Exception e) {
        }
        return o.toString();
    }

    static void set(Context c, String json) {
        try {
            JSONObject o = new JSONObject(json);
            SharedPreferences.Editor e = Store.p(c).edit();
            if (o.has("on")) e.putBoolean(K_ON, o.optBoolean("on", true));
            if (o.has("side")) e.putInt(K_SIDE, o.optInt("side", 1) == 0 ? 0 : 1);
            if (o.has("y")) e.putFloat(K_Y, (float) Math.max(0, Math.min(1, o.optDouble("y", 0.62))));
            JSONArray f = o.optJSONArray("fav");
            if (f != null) e.putString(K_FAV, f.toString());
            JSONObject t = o.optJSONObject("th");
            if (t != null && t.length() > 0) e.putString(K_TH, t.toString());
            e.putBoolean(K_INIT, true).apply();
        } catch (Exception x) {
        }
        BlkService.floatRefresh();
    }

    /** Native tugma ishlayaptimi (xizmat yoqilgan va tugma yoqilgan) */
    static boolean active() {
        BlkService s = BlkService.INST;
        if (s == null) return false;
        try {
            return Store.p(s).getBoolean(K_ON, true);
        } catch (Throwable t) {
            return false;
        }
    }

    static void jsVis(boolean v) {
        jsHideUntil = v ? 0 : System.currentTimeMillis() + 2500;
    }

    static String take() {
        String k = pending;
        pending = null;
        return k == null ? "" : k;
    }

    /* ------------------------------------------------------------------ oyna */

    private final BlkService s;
    private final WindowManager wm;
    private final Handler hd = new Handler(Looper.getMainLooper());
    private final float dens;
    private boolean running;
    private Btn btn;
    private WindowManager.LayoutParams blp;
    private FrameLayout panel;
    private int W, H;
    private int cAc = 0xFF8A5A3C, cCard = 0xFFFFFAF8, cBd = 0xFFECD9D2, cTx = 0xFF2B1D17, cBg = 0xFFFCF4F2, cMu = 0xFF8A6A58;
    private final Map<String, Intent> sysCache = new HashMap<String, Intent>();

    FloatBtn(BlkService s) {
        this.s = s;
        this.wm = (WindowManager) s.getSystemService(Context.WINDOW_SERVICE);
        this.dens = s.getResources().getDisplayMetrics().density;
    }

    private int dp(float v) {
        return Math.round(v * dens);
    }

    private float dpf(float v) {
        return v * dens;
    }

    void start() {
        running = true;
        hd.removeCallbacks(tick);
        hd.post(tick);
    }

    void stop() {
        running = false;
        hd.removeCallbacks(tick);
        closePanel();
        removeBtn();
    }

    /** Sozlama (yoqish/o'chirish, rang, joy) o'zgarganda qayta chizadi */
    void refresh() {
        closePanel();
        removeBtn();
        hd.removeCallbacks(tick);
        if (running) hd.post(tick);
    }

    /** Ekran burilganda joyni to'g'rilaydi */
    void reclamp() {
        closePanel();
        if (btn != null) {
            metrics();
            place();
            upd();
        }
    }

    /** Boshqa oyna ochilganda (bildirishnoma paneli, boshqa ilova) menyu yopiladi */
    void windowChanged(CharSequence pkg) {
        if (panel == null) return;
        // Menyuning o'z oynasi (va tugma oynasi) ham "oyna o'zgardi" hodisasini yuboradi: uni e'tiborsiz qoldiramiz,
        // aks holda menyu ochilishi bilanoq yopilib qoladi.
        if (pkg != null && pkg.toString().equals(s.getPackageName())) return;
        // Menyu endigina ochilgan bo'lsa, tizimning kechikkan hodisalari uni yopmasin.
        if (System.currentTimeMillis() - openedAt < 1500) return;
        closePanel();
    }

    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            try {
                apply();
            } catch (Throwable t) {
            }
            if (running) hd.postDelayed(this, 1000);
        }
    };

    private boolean locked() {
        try {
            KeyguardManager km = (KeyguardManager) s.getSystemService(Context.KEYGUARD_SERVICE);
            return km != null && km.isKeyguardLocked();
        } catch (Throwable t) {
            return false;
        }
    }

    private void apply() {
        boolean want = Store.p(s).getBoolean(K_ON, true) && !locked() && !AlarmService.running
                && System.currentTimeMillis() >= jsHideUntil;
        if (want && btn == null) {
            addBtn();
        } else if (!want && btn != null) {
            closePanel();
            removeBtn();
        }
    }

    private void metrics() {
        DisplayMetrics m = new DisplayMetrics();
        wm.getDefaultDisplay().getRealMetrics(m);
        W = m.widthPixels;
        H = m.heightPixels;
    }

    private static int parseCol(String v, int d) {
        try {
            if (v == null) return d;
            v = v.trim();
            if (v.startsWith("#")) return Color.parseColor(v);
            Matcher m = Pattern.compile("rgba?\\(\\s*(\\d+)[ ,]+(\\d+)[ ,]+(\\d+)(?:[ ,/]+([0-9.]+))?\\s*\\)").matcher(v);
            if (m.find()) {
                int a = m.group(4) == null ? 255 : Math.round(Float.parseFloat(m.group(4)) * 255f);
                return Color.argb(a, Integer.parseInt(m.group(1)), Integer.parseInt(m.group(2)), Integer.parseInt(m.group(3)));
            }
        } catch (Throwable t) {
        }
        return d;
    }

    private void loadTheme() {
        try {
            JSONObject t = new JSONObject(Store.p(s).getString(K_TH, "{}"));
            cAc = parseCol(t.optString("ac", ""), 0xFF8A5A3C);
            cCard = parseCol(t.optString("card", ""), 0xFFFFFAF8);
            cBd = parseCol(t.optString("bd", ""), 0xFFECD9D2);
            cTx = parseCol(t.optString("tx", ""), 0xFF2B1D17);
            cBg = parseCol(t.optString("bg", ""), 0xFFFCF4F2);
            cMu = parseCol(t.optString("mu", ""), 0xFF8A6A58);
        } catch (Throwable t) {
        }
    }

    private static int clamp(int v, int lo, int hi) {
        return Math.max(lo, Math.min(hi, v));
    }

    private void addBtn() {
        try {
            metrics();
            loadTheme();
            int S = dp(54);
            btn = new Btn(s);
            btn.setContentDescription("Yordamchi tugma");
            blp = new WindowManager.LayoutParams(S, S, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                            | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                    PixelFormat.TRANSLUCENT);
            blp.gravity = Gravity.TOP | Gravity.START;
            place();
            wm.addView(btn, blp);
            btn.wake();
        } catch (Throwable t) {
            btn = null;
        }
    }

    private void removeBtn() {
        try {
            if (btn != null) {
                btn.cancel();
                wm.removeView(btn);
            }
        } catch (Throwable t) {
        }
        btn = null;
    }

    private void place() {
        SharedPreferences p = Store.p(s);
        int S = blp.width, M = dp(6);
        int side = p.getInt(K_SIDE, 1);
        float yf = p.getFloat(K_Y, 0.62f);
        blp.x = side == 0 ? M : W - S - M;
        blp.y = clamp((int) (yf * H), dp(46), H - S - dp(76));
    }

    private void upd() {
        try {
            if (btn != null) wm.updateViewLayout(btn, blp);
        } catch (Throwable t) {
        }
    }

    /* ------------------------------------------------------------------ tugma */

    private final class Btn extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF rf = new RectF();
        private float dx, dy;
        private int sx, sy;
        private boolean moved;
        private ValueAnimator va;
        private final Runnable idle = new Runnable() {
            @Override
            public void run() {
                animate().alpha(0.5f).setDuration(250).start();
            }
        };

        Btn(Context c) {
            super(c);
        }

        void wake() {
            removeCallbacks(idle);
            animate().cancel();
            setAlpha(1f);
            postDelayed(idle, 3000);
        }

        void cancel() {
            removeCallbacks(idle);
            if (va != null) va.cancel();
        }

        @Override
        protected void onDraw(Canvas c) {
            float w = getWidth(), h = getHeight(), r = dpf(16);
            rf.set(dpf(0.5f), dpf(0.5f), w - dpf(0.5f), h - dpf(0.5f));
            p.setStyle(Paint.Style.FILL);
            p.setColor(cCard);
            c.drawRoundRect(rf, r, r, p);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(dpf(1));
            p.setColor(cBd);
            c.drawRoundRect(rf, r, r, p);
            p.setStyle(Paint.Style.FILL);
            p.setColor(cAc);
            c.drawCircle(w / 2f, h / 2f, dpf(16), p);
            p.setColor(cCard);
            c.drawCircle(w / 2f, h / 2f, dpf(10.5f), p);
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    dx = e.getRawX();
                    dy = e.getRawY();
                    sx = blp.x;
                    sy = blp.y;
                    moved = false;
                    wake();
                    return true;
                case MotionEvent.ACTION_MOVE: {
                    float mx = e.getRawX() - dx, my = e.getRawY() - dy;
                    if (!moved && Math.abs(mx) + Math.abs(my) > dp(8)) {
                        moved = true;
                        removeCallbacks(idle);
                        setScaleX(1.06f);
                        setScaleY(1.06f);
                        setAlpha(1f);
                    }
                    if (moved) {
                        blp.x = clamp((int) (sx + mx), 0, W - blp.width);
                        blp.y = clamp((int) (sy + my), 0, H - blp.height);
                        upd();
                    }
                    return true;
                }
                case MotionEvent.ACTION_UP:
                    setScaleX(1f);
                    setScaleY(1f);
                    if (moved) endDrag();
                    else openPanel();
                    wake();
                    return true;
                case MotionEvent.ACTION_CANCEL:
                    setScaleX(1f);
                    setScaleY(1f);
                    if (moved) endDrag();
                    wake();
                    return true;
                default:
                    return true;
            }
        }

        private void endDrag() {
            int cx = blp.x + blp.width / 2;
            int side = cx < W / 2 ? 0 : 1;
            float yf = Math.max(0f, Math.min(1f, blp.y / (float) H));
            Store.p(s).edit().putInt(K_SIDE, side).putFloat(K_Y, yf).apply();
            int tx = side == 0 ? dp(6) : W - blp.width - dp(6);
            va = ValueAnimator.ofInt(blp.x, tx);
            va.setDuration(160);
            va.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
                @Override
                public void onAnimationUpdate(ValueAnimator a) {
                    if (btn == null) return;
                    blp.x = (Integer) a.getAnimatedValue();
                    upd();
                }
            });
            va.start();
        }
    }

    /* ------------------------------------------------------------------ menyu */

    private long openedAt = 0;

    private void openPanel() {
        if (panel != null) return;
        try {
            openedAt = System.currentTimeMillis();
            sysCache.clear();
            panel = new FrameLayout(s);
            panel.setBackgroundColor(Color.argb(82, 43, 29, 23));
            panel.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    closePanel();
                }
            });
            WindowManager.LayoutParams lp = new WindowManager.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                            | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                    PixelFormat.TRANSLUCENT);
            fill(false);
            wm.addView(panel, lp);
        } catch (Throwable t) {
            panel = null;
        }
    }

    private void closePanel() {
        picking = false;
        if (panel == null) return;
        try {
            wm.removeView(panel);
        } catch (Throwable t) {
        }
        panel = null;
    }

    private GradientDrawable rr(int fill, float radiusDp, int stroke) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(dpf(radiusDp));
        if (stroke != 0) g.setStroke(dp(1), stroke);
        return g;
    }

    private TextView label(String t, float sp, boolean bold, int color) {
        TextView v = new TextView(s);
        v.setText(t);
        v.setTextSize(sp);
        v.setTextColor(color);
        v.setGravity(Gravity.CENTER);
        if (bold) v.setTypeface(Typeface.DEFAULT_BOLD);
        return v;
    }

    /** Kvadrat katak: balandligi kengligiga teng */
    private final class Sq extends LinearLayout {
        Sq(Context c) {
            super(c);
        }

        @Override
        protected void onMeasure(int w, int h) {
            super.onMeasure(w, w);
        }
    }

    /** Balandligi cheklangan aylantirish oynasi */
    private final class Cap extends ScrollView {
        private final int max;

        Cap(Context c, int max) {
            super(c);
            this.max = max;
        }

        @Override
        protected void onMeasure(int w, int h) {
            super.onMeasure(w, View.MeasureSpec.makeMeasureSpec(max, View.MeasureSpec.AT_MOST));
        }
    }

    private Sq tile(String key, String text, Ic icon, boolean textOnly) {
        Sq t = new Sq(s);
        t.setOrientation(LinearLayout.VERTICAL);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(6), dp(6), dp(6), dp(6));
        t.setBackground(rr(cCard, 24, cBd));
        if (textOnly) {
            t.addView(label(text, 14, true, cAc));
        } else {
            if (icon != null) t.addView(icon, new LinearLayout.LayoutParams(dp(44), dp(44)));
            TextView l = label(text, 11, true, cAc);
            l.setMaxLines(2);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.topMargin = dp(5);
            t.addView(l, lp);
        }
        final String k = key;
        t.setClickable(true);
        t.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                act(k);
            }
        });
        if (k.startsWith("pkg:")) {
            t.setLongClickable(true);
            t.setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View v) {
                    removeFav(k.substring(4));
                    fill(true);
                    return true;
                }
            });
        }
        return t;
    }

    private void addRow(LinearLayout parent, List<View> row) {
        LinearLayout r = new LinearLayout(s);
        r.setOrientation(LinearLayout.HORIZONTAL);
        for (int i = 0; i < 3; i++) {
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
            lp.setMargins(dp(5), dp(5), dp(5), dp(5));
            if (i < row.size()) {
                r.addView(row.get(i), lp);
            } else {
                View e = new View(s);
                r.addView(e, lp);
            }
        }
        parent.addView(r, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
    }

    private void fill(boolean apps) {
        if (panel == null) return;
        panel.removeAllViews();
        int bw = Math.min(dp(330), (int) (W * 0.9f));
        LinearLayout wrap = new LinearLayout(s);
        wrap.setOrientation(LinearLayout.VERTICAL);
        wrap.setGravity(Gravity.CENTER_HORIZONTAL);
        wrap.setClickable(false);

        LinearLayout box = new LinearLayout(s);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(14), dp(14), dp(14), dp(14));
        box.setBackground(rr(cBg, 26, cBd));
        box.setClickable(true);

        if (apps) {
            warmApps();
            LinearLayout head = new LinearLayout(s);
            head.setOrientation(LinearLayout.HORIZONTAL);
            head.setGravity(Gravity.CENTER_VERTICAL);
            Ic back = new Ic(s, Ic.BACK);
            back.setClickable(true);
            back.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    act("main");
                }
            });
            head.addView(back, new LinearLayout.LayoutParams(dp(36), dp(36)));
            TextView tt = label("Ilovalar", 16, true, cTx);
            LinearLayout.LayoutParams tl = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT);
            tl.leftMargin = dp(6);
            head.addView(tt, tl);
            LinearLayout.LayoutParams hl = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT);
            hl.bottomMargin = dp(8);
            box.addView(head, hl);

            LinearLayout grid = new LinearLayout(s);
            grid.setOrientation(LinearLayout.VERTICAL);
            List<View> cells = new java.util.ArrayList<View>();
            PackageManager pm = s.getPackageManager();
            try {
                JSONArray fav = new JSONArray(Store.p(s).getString(K_FAV, "[]"));
                for (int i = 0; i < fav.length(); i++) {
                    JSONObject o = fav.optJSONObject(i);
                    if (o == null) continue;
                    String pk = o.optString("p", "");
                    if (pk.length() == 0 || pm.getLaunchIntentForPackage(pk) == null) continue;
                    Drawable d = null;
                    try {
                        d = pm.getApplicationIcon(pk);
                    } catch (Throwable t) {
                    }
                    Ic ic = d != null ? new Ic(s, d) : new Ic(s, Ic.APPS);
                    cells.add(tile("pkg:" + pk, o.optString("n", pk), ic, false));
                }
            } catch (Throwable t) {
            }
            cells.add(tile("pick", "Qo\u2019shish", new Ic(s, Ic.PLUS), false));
            for (int i = 0; i < cells.size(); i += 3) {
                addRow(grid, cells.subList(i, Math.min(cells.size(), i + 3)));
            }
            Cap sv = new Cap(s, (int) (H * 0.6f));
            sv.addView(grid, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            box.addView(sv, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            TextView hint = label("Olib tashlash: ilovani bosib turing", 12, false, cMu);
            hint.setGravity(Gravity.CENTER);
            LinearLayout.LayoutParams hnl = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            hnl.topMargin = dp(8);
            box.addView(hint, hnl);
        } else {
            String[][] L = {{"qr", "Qur\u2019on"}, {"sn", "Sunnat"}, {"dl", "Daloil ul-Xayrot"}, {"pa", "Ilovalar"},
                    {"hm", "Home"}, {"tl", "Timeline"}, {"ph", "Telefon"}, {"sm", "SMS"}, {"cm", "Kamera"}};
            List<View> cells = new java.util.ArrayList<View>();
            for (String[] x : L) {
                String k = x[0];
                if (k.equals("qr") || k.equals("sn") || k.equals("dl")) {
                    cells.add(tile(k, x[1], null, true));
                } else if (k.equals("ph") || k.equals("sm") || k.equals("cm")) {
                    int kd = k.equals("ph") ? Ic.PHONE : k.equals("sm") ? Ic.SMS : Ic.CAM;
                    cells.add(tile(k, x[1], new Ic(s, kd), false));
                } else {
                    int kind = k.equals("hm") ? Ic.HOME : k.equals("tl") ? Ic.TL : Ic.APPS;
                    cells.add(tile(k, x[1], new Ic(s, kind), false));
                }
            }
            for (int i = 0; i < 9; i += 3) addRow(box, cells.subList(i, i + 3));
        }
        wrap.addView(box, new LinearLayout.LayoutParams(bw, ViewGroup.LayoutParams.WRAP_CONTENT));

        if (!apps) {
            TextView hide = label("Tugmani yashirish", 12, false, cMu);
            hide.setPadding(dp(16), dp(8), dp(16), dp(8));
            hide.setBackground(rr(cCard, 14, cBd));
            hide.setClickable(true);
            hide.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    act("hide");
                }
            });
            LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT);
            hp.topMargin = dp(10);
            wrap.addView(hide, hp);
        }
        panel.addView(wrap, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER));
    }

    /* ------------------------------------------------------------------ ilova tanlash (ilovani ochmasdan) */

    private static volatile java.util.List<Object[]> appCache = null;
    private static volatile long appCacheAt = 0;
    private static volatile boolean appLoading = false;
    private volatile boolean picking = false;

    /** O'rnatilgan ilovalar ro'yxati: {paket, nom, belgi}. Orqa oqimda chaqiriladi. */
    private java.util.List<Object[]> loadApps() {
        long now = System.currentTimeMillis();
        java.util.List<Object[]> c = appCache;
        if (c != null && now - appCacheAt < 120000) return c;
        java.util.List<Object[]> out = new java.util.ArrayList<Object[]>();
        try {
            PackageManager pm = s.getPackageManager();
            Intent q = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
            List<ResolveInfo> l = pm.queryIntentActivities(q, 0);
            java.util.HashSet<String> seen = new java.util.HashSet<String>();
            for (ResolveInfo r : l) {
                String pk = r.activityInfo.packageName;
                if (pk.equals(s.getPackageName()) || !seen.add(pk)) continue;
                CharSequence lb = r.loadLabel(pm);
                Drawable d = null;
                try {
                    d = r.loadIcon(pm);
                } catch (Throwable t) {
                }
                out.add(new Object[]{pk, lb == null ? pk : lb.toString(), d});
            }
            java.util.Collections.sort(out, new java.util.Comparator<Object[]>() {
                @Override
                public int compare(Object[] a, Object[] b) {
                    return ((String) a[1]).compareToIgnoreCase((String) b[1]);
                }
            });
        } catch (Throwable t) {
        }
        appCache = out;
        appCacheAt = System.currentTimeMillis();
        return out;
    }

    /** "Ilovalar" ko'rinishi ochilganda ro'yxatni orqa oqimda tayyorlab qo'yadi, shunda "Qo'shish" darrov ochiladi */
    private void warmApps() {
        if (appLoading) return;
        java.util.List<Object[]> c = appCache;
        if (c != null && System.currentTimeMillis() - appCacheAt < 120000) return;
        appLoading = true;
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    loadApps();
                } catch (Throwable t) {
                }
                appLoading = false;
            }
        }).start();
    }

    private void fillPick() {
        if (panel == null) return;
        picking = true;
        java.util.List<Object[]> c = appCache;
        if (c != null) {
            buildPick(c);
            return;
        }
        buildPick(null);
        new Thread(new Runnable() {
            @Override
            public void run() {
                final java.util.List<Object[]> items = loadApps();
                hd.post(new Runnable() {
                    @Override
                    public void run() {
                        if (panel != null && picking) buildPick(items);
                    }
                });
            }
        }).start();
    }

    private void removeFav(String pk) {
        try {
            SharedPreferences p = Store.p(s);
            JSONArray fav = new JSONArray(p.getString(K_FAV, "[]"));
            JSONArray out = new JSONArray();
            for (int i = 0; i < fav.length(); i++) {
                JSONObject o = fav.optJSONObject(i);
                if (o != null && pk.equals(o.optString("p", ""))) continue;
                out.put(o);
            }
            p.edit().putString(K_FAV, out.toString()).putBoolean(K_INIT, true).apply();
        } catch (Throwable t) {
        }
    }

    private void addFav(String pk, String nm) {
        try {
            SharedPreferences p = Store.p(s);
            JSONArray fav;
            try {
                fav = new JSONArray(p.getString(K_FAV, "[]"));
            } catch (Exception e) {
                fav = new JSONArray();
            }
            for (int i = 0; i < fav.length(); i++) {
                JSONObject o = fav.optJSONObject(i);
                if (o != null && pk.equals(o.optString("p", ""))) return;
            }
            fav.put(new JSONObject().put("p", pk).put("n", nm));
            p.edit().putString(K_FAV, fav.toString()).putBoolean(K_INIT, true).apply();
        } catch (Throwable t) {
        }
    }

    private void buildPick(java.util.List<Object[]> items) {
        if (panel == null) return;
        panel.removeAllViews();
        int bw = Math.min(dp(330), (int) (W * 0.9f));
        LinearLayout wrap = new LinearLayout(s);
        wrap.setOrientation(LinearLayout.VERTICAL);
        wrap.setGravity(Gravity.CENTER_HORIZONTAL);
        wrap.setClickable(false);

        LinearLayout box = new LinearLayout(s);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(14), dp(14), dp(14), dp(14));
        box.setBackground(rr(cBg, 26, cBd));
        box.setClickable(true);

        LinearLayout head = new LinearLayout(s);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(Gravity.CENTER_VERTICAL);
        Ic back = new Ic(s, Ic.BACK);
        back.setClickable(true);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                picking = false;
                fill(true);
            }
        });
        head.addView(back, new LinearLayout.LayoutParams(dp(36), dp(36)));
        TextView tt = label("Ilova tanlang", 16, true, cTx);
        LinearLayout.LayoutParams tl = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        tl.leftMargin = dp(6);
        head.addView(tt, tl);
        LinearLayout.LayoutParams hl = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        hl.bottomMargin = dp(8);
        box.addView(head, hl);

        java.util.HashSet<String> have = new java.util.HashSet<String>();
        try {
            JSONArray fav = new JSONArray(Store.p(s).getString(K_FAV, "[]"));
            for (int i = 0; i < fav.length(); i++) {
                JSONObject o = fav.optJSONObject(i);
                if (o != null) have.add(o.optString("p", ""));
            }
        } catch (Throwable t) {
        }

        if (items == null) {
            TextView ld = label("Yuklanmoqda\u2026", 14, false, cMu);
            ld.setPadding(dp(8), dp(24), dp(8), dp(24));
            box.addView(ld, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT));
        } else {
            LinearLayout list = new LinearLayout(s);
            list.setOrientation(LinearLayout.VERTICAL);
            int n = 0;
            for (Object[] it : items) {
                final String pk = (String) it[0];
                final String nm = (String) it[1];
                if (have.contains(pk)) continue;
                n++;
                LinearLayout row = new LinearLayout(s);
                row.setOrientation(LinearLayout.HORIZONTAL);
                row.setGravity(Gravity.CENTER_VERTICAL);
                row.setPadding(dp(10), dp(8), dp(10), dp(8));
                row.setBackground(rr(cCard, 16, cBd));
                row.setClickable(true);
                row.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        addFav(pk, nm);
                        picking = false;
                        fill(true);
                    }
                });
                Drawable d = (Drawable) it[2];
                Ic ic = d != null ? new Ic(s, d) : new Ic(s, Ic.APPS);
                row.addView(ic, new LinearLayout.LayoutParams(dp(36), dp(36)));
                TextView lb = new TextView(s);
                lb.setText(nm);
                lb.setTextSize(15);
                lb.setTextColor(cTx);
                lb.setSingleLine(true);
                lb.setEllipsize(android.text.TextUtils.TruncateAt.END);
                LinearLayout.LayoutParams ll = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
                ll.leftMargin = dp(12);
                row.addView(lb, ll);
                LinearLayout.LayoutParams rl = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT);
                rl.bottomMargin = dp(6);
                list.addView(row, rl);
            }
            if (n == 0) {
                TextView em = label("Qo\u2019shadigan boshqa ilova yo\u2019q", 14, false, cMu);
                em.setPadding(dp(8), dp(24), dp(8), dp(24));
                list.addView(em, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT));
            }
            Cap sv = new Cap(s, (int) (H * 0.6f));
            sv.addView(list, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT));
            box.addView(sv, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT));
        }
        wrap.addView(box, new LinearLayout.LayoutParams(bw, ViewGroup.LayoutParams.WRAP_CONTENT));
        panel.addView(wrap, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER));
    }

    /* ------------------------------------------------------------------ amallar */

    private void act(String k) {
        try {
            if ("pa".equals(k)) {
                fill(true);
                return;
            }
            if ("main".equals(k)) {
                fill(false);
                return;
            }
            if ("hide".equals(k)) {
                Store.p(s).edit().putBoolean(K_ON, false).apply();
                closePanel();
                removeBtn();
                return;
            }
            if ("pick".equals(k)) {
                fillPick();
                return;
            }
            closePanel();
            if ("hm".equals(k)) {
                s.performGlobalAction(AccessibilityService.GLOBAL_ACTION_HOME);
            } else if ("ph".equals(k) || "sm".equals(k) || "cm".equals(k)) {
                Intent i = sysIntent(k);
                if (i != null) launch(i);
            } else if ("qr".equals(k) || "sn".equals(k) || "dl".equals(k) || "tl".equals(k) || "pick".equals(k)) {
                pending = k;
                Intent i = new Intent(s, MainActivity.class);
                i.putExtra("ast", k);
                launch(i);
            } else if (k.startsWith("pkg:")) {
                Intent i = s.getPackageManager().getLaunchIntentForPackage(k.substring(4));
                if (i != null) launch(i);
            }
        } catch (Throwable t) {
        }
    }

    private void launch(Intent i) {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        s.startActivity(i);
    }

    private static final String[] PH = {"com.google.android.dialer", "com.samsung.android.dialer", "com.android.dialer",
            "com.oplus.dialer", "com.huawei.contacts", "com.android.contacts", "com.asus.contacts", "com.motorola.dialer"};
    private static final String[] SM = {"com.google.android.apps.messaging", "com.samsung.android.messaging",
            "com.android.mms", "com.android.messaging", "com.huawei.message", "com.oplus.mms", "com.asus.message"};
    private static final String[] CM = {"com.android.camera", "com.android.camera2", "com.oplus.camera", "com.oppo.camera",
            "com.coloros.camera", "com.google.android.GoogleCamera", "com.sec.android.app.camera", "com.huawei.camera",
            "com.motorola.camera3", "com.asus.camera"};

    /** Telefon / SMS / kamera: telefondagi mos ilovani topadi (ilovadagi kabi) */
    private Intent sysIntent(String k) {
        if (sysCache.containsKey(k)) return sysCache.get(k);
        Intent res = null;
        try {
            PackageManager pm = s.getPackageManager();
            String[] pk = "ph".equals(k) ? PH : "sm".equals(k) ? SM : CM;
            for (String p : pk) {
                Intent li = pm.getLaunchIntentForPackage(p);
                if (li != null) {
                    res = li;
                    break;
                }
            }
            if (res == null) {
                Pattern nm = Pattern.compile("ph".equals(k) ? "^(telefon|phone|dialer|qo.?ng.?iroqlar?|calls?)$"
                        : "sm".equals(k) ? "^(sms|xabarlar|xabar|messages|messaging|message)$" : "^(camera|kamera)$",
                        Pattern.CASE_INSENSITIVE);
                Intent q = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
                List<ResolveInfo> l = pm.queryIntentActivities(q, 0);
                for (ResolveInfo r : l) {
                    CharSequence lb = r.loadLabel(pm);
                    if (lb != null && nm.matcher(lb.toString().trim()).matches()) {
                        res = pm.getLaunchIntentForPackage(r.activityInfo.packageName);
                        if (res != null) break;
                    }
                }
            }
            if (res == null) {
                Intent f = "ph".equals(k) ? new Intent(Intent.ACTION_DIAL)
                        : "sm".equals(k) ? Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_MESSAGING)
                        : new Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA);
                if (pm.resolveActivity(f, 0) != null) res = f;
            }
        } catch (Throwable t) {
        }
        sysCache.put(k, res);
        return res;
    }

    private Drawable sysIcon(String k) {
        try {
            Intent i = sysIntent(k);
            if (i == null) return null;
            PackageManager pm = s.getPackageManager();
            String pkg = i.getComponent() != null ? i.getComponent().getPackageName() : i.getPackage();
            if (pkg == null) {
                ResolveInfo r = pm.resolveActivity(i, 0);
                if (r != null && r.activityInfo != null) pkg = r.activityInfo.packageName;
            }
            if (pkg == null || "android".equals(pkg)) return null;
            return pm.getApplicationIcon(pkg);
        } catch (Throwable t) {
            return null;
        }
    }

    /* ------------------------------------------------------------------ belgilar */

    private final class Ic extends View {
        static final int HOME = 1, TL = 2, APPS = 3, PLUS = 4, BACK = 5, APP = 6, PHONE = 7, SMS = 8, CAM = 9;
        private final int kind;
        private final Drawable dr;
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);

        Ic(Context c, int kind) {
            super(c);
            this.kind = kind;
            this.dr = null;
        }

        Ic(Context c, Drawable d) {
            super(c);
            this.kind = APP;
            this.dr = d;
        }

        @Override
        protected void onDraw(Canvas c) {
            float w = getWidth(), h = getHeight(), sz = Math.min(w, h);
            float cx = w / 2f, cy = h / 2f;
            if (kind == APP && dr != null) {
                float r = sz * 0.5f;
                c.save();
                Path cl = new Path();
                cl.addRoundRect(new RectF(cx - r, cy - r, cx + r, cy + r), sz * 0.24f, sz * 0.24f, Path.Direction.CW);
                c.clipPath(cl);
                dr.setBounds((int) (cx - r), (int) (cy - r), (int) (cx + r), (int) (cy + r));
                dr.draw(c);
                c.restore();
                return;
            }
            if (kind != BACK) {
                p.setStyle(Paint.Style.STROKE);
                p.setStrokeWidth(dpf(kind == PLUS ? 1.5f : 1f));
                p.setColor((cMu & 0x00FFFFFF) | 0x99000000);
                p.setPathEffect(kind == PLUS ? new DashPathEffect(new float[]{dpf(4), dpf(3)}, 0) : null);
                c.drawCircle(cx, cy, sz / 2f - dpf(1), p);
                p.setPathEffect(null);
            }
            c.save();
            float sc = sz * (kind == BACK ? 0.62f : 0.46f) / 24f;
            c.translate(cx, cy);
            c.scale(sc, sc);
            c.translate(-12f, -12f);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(kind == BACK ? 2f : 1.8f);
            p.setStrokeCap(Paint.Cap.ROUND);
            p.setStrokeJoin(Paint.Join.ROUND);
            p.setColor(kind == PLUS ? cMu : cAc);
            Path g = new Path();
            switch (kind) {
                case HOME:
                    g.moveTo(4, 11);
                    g.lineTo(12, 4);
                    g.lineTo(20, 11);
                    g.lineTo(20, 20);
                    g.lineTo(15, 20);
                    g.lineTo(15, 14);
                    g.lineTo(9, 14);
                    g.lineTo(9, 20);
                    g.lineTo(4, 20);
                    g.close();
                    break;
                case TL:
                    g.addRoundRect(new RectF(3.5f, 5f, 20.5f, 20f), 3f, 3f, Path.Direction.CW);
                    g.moveTo(3.5f, 10f);
                    g.lineTo(20.5f, 10f);
                    g.moveTo(8, 3);
                    g.lineTo(8, 7);
                    g.moveTo(16, 3);
                    g.lineTo(16, 7);
                    g.moveTo(8, 14);
                    g.lineTo(12, 14);
                    break;
                case APPS:
                    g.addRoundRect(new RectF(4f, 4f, 10.5f, 10.5f), 1.5f, 1.5f, Path.Direction.CW);
                    g.addRoundRect(new RectF(13.5f, 4f, 20f, 10.5f), 1.5f, 1.5f, Path.Direction.CW);
                    g.addRoundRect(new RectF(4f, 13.5f, 10.5f, 20f), 1.5f, 1.5f, Path.Direction.CW);
                    g.addRoundRect(new RectF(13.5f, 13.5f, 20f, 20f), 1.5f, 1.5f, Path.Direction.CW);
                    break;
                case PLUS:
                    g.moveTo(12, 6);
                    g.lineTo(12, 18);
                    g.moveTo(6, 12);
                    g.lineTo(18, 12);
                    break;
                case PHONE:
                    g.moveTo(5, 4);
                    g.lineTo(9, 4);
                    g.lineTo(10.5f, 8.5f);
                    g.lineTo(8.5f, 10);
                    g.cubicTo(9.5f, 12.5f, 11.5f, 14.5f, 14, 15.5f);
                    g.lineTo(15.5f, 13.5f);
                    g.lineTo(20, 15);
                    g.lineTo(20, 19);
                    g.cubicTo(11, 20, 4, 13, 5, 4);
                    g.close();
                    break;
                case SMS:
                    g.addRoundRect(new RectF(4f, 5f, 20f, 16f), 3f, 3f, Path.Direction.CW);
                    g.moveTo(9, 16);
                    g.lineTo(9, 20);
                    g.lineTo(13, 16);
                    break;
                case CAM:
                    g.addRoundRect(new RectF(3.5f, 7f, 20.5f, 19f), 3f, 3f, Path.Direction.CW);
                    g.moveTo(8.5f, 7);
                    g.lineTo(10, 4.5f);
                    g.lineTo(14, 4.5f);
                    g.lineTo(15.5f, 7);
                    g.addCircle(12, 13, 3.5f, Path.Direction.CW);
                    break;
                case BACK:
                    g.moveTo(19, 12);
                    g.lineTo(5, 12);
                    g.moveTo(11, 6);
                    g.lineTo(5, 12);
                    g.lineTo(11, 18);
                    break;
                default:
                    break;
            }
            c.drawPath(g, p);
            c.restore();
        }
    }
}
