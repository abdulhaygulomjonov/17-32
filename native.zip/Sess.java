package uz.sanalar.app;

import android.content.Context;
import android.content.SharedPreferences;
import android.provider.Settings;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Calendar;
import java.util.HashSet;
import java.util.Set;

/** Vaqt so'rash seanslari, vaqtli bloklar, jadvallar va sozlamalar (minimalist rejim). */
final class Sess {
    static final long GRACE = 20000L;
    static volatile boolean askUp = false;

    static SharedPreferences p(Context c) {
        return Store.p(c);
    }

    /* ---------- sozlamalar (JS bilan umumiy JSON) ---------- */
    private static String cfgRaw = null;
    private static JSONObject cfgObj = new JSONObject();

    static synchronized JSONObject cfg(Context c) {
        String s = p(c).getString("sx_cfg", "{}");
        if (!s.equals(cfgRaw)) {
            try {
                cfgObj = new JSONObject(s);
            } catch (Exception e) {
                cfgObj = new JSONObject();
            }
            cfgRaw = s;
        }
        return cfgObj;
    }

    static boolean flag(Context c, String k, boolean d) {
        return cfg(c).optInt(k, d ? 1 : 0) == 1;
    }

    static Set<String> set(Context c, String k) {
        Set<String> s = new HashSet<String>();
        JSONArray a = cfg(c).optJSONArray(k);
        if (a != null) for (int i = 0; i < a.length(); i++) s.add(a.optString(i));
        return s;
    }

    static boolean askOn(Context c) {
        return flag(c, "ask", true);
    }

    static int mindful(Context c) {
        return Math.max(0, Math.min(30, cfg(c).optInt("mindful", 0)));
    }

    static long[] opts(Context c) {
        JSONArray a = cfg(c).optJSONArray("opts");
        java.util.ArrayList<Long> l = new java.util.ArrayList<Long>();
        if (a != null) for (int i = 0; i < a.length() && l.size() < 8; i++) {
            int m = a.optInt(i, 0);
            if (m >= 1 && m <= 600) l.add(m * 60000L);
        }
        if (l.isEmpty()) {
            int[] d = {1, 2, 5, 10, 15, 30, 60};
            for (int m : d) l.add(m * 60000L);
        }
        long[] r = new long[l.size()];
        for (int i = 0; i < r.length; i++) r[i] = l.get(i);
        return r;
    }

    /** Hech narsa yoqilmagan bo'lsa xizmat ortiqcha ish qilmaydi. */
    static boolean relevant(Context c) {
        JSONObject o = cfg(c);
        return o.optInt("ask", 1) == 1 || o.optInt("shorts", 0) == 1 || o.optInt("sites", 0) == 1
                || o.optInt("mono", 0) == 1 || hasBlocks(c) || Lim.on(c);
    }

    static boolean hasBlocks(Context c) {
        SharedPreferences sp = p(c);
        return !"{}".equals(sp.getString("sx_tb", "{}")) || !"[]".equals(sp.getString("sx_sch", "[]"));
    }

    /* ---------- seans ---------- */
    static String sPkg(Context c) {
        return p(c).getString("sx_pkg", "");
    }

    static long sUntil(Context c) {
        return p(c).getLong("sx_until", 0);
    }

    static long sTotal(Context c) {
        return p(c).getLong("sx_total", 0);
    }

    static long sLeft(Context c) {
        return p(c).getLong("sx_left", 0);
    }

    static void start(Context c, String pkg, long ms) {
        long now = System.currentTimeMillis();
        p(c).edit().putString("sx_pkg", pkg).putLong("sx_until", now + ms).putLong("sx_total", ms).putLong("sx_left", 0).apply();
    }

    static void markLeft(Context c) {
        p(c).edit().putLong("sx_left", System.currentTimeMillis()).apply();
    }

    static void clearLeft(Context c) {
        p(c).edit().putLong("sx_left", 0).apply();
    }

    static void endSession(Context c) {
        p(c).edit().putString("sx_pkg", "").putLong("sx_until", 0).putLong("sx_left", 0).apply();
    }

    /** Seans shu ilova uchun hali amal qilyaptimi (tez qaytish 20 soniyagacha kechiriladi) */
    static boolean valid(Context c, String pkg, long now) {
        if (!pkg.equals(sPkg(c)) || now >= sUntil(c)) return false;
        long l = sLeft(c);
        return l == 0 || now - l <= GRACE;
    }

    /* ---------- vaqtli bloklar ---------- */
    static JSONObject tb(Context c) {
        try {
            return new JSONObject(p(c).getString("sx_tb", "{}"));
        } catch (Exception e) {
            return new JSONObject();
        }
    }

    /** ms <= 0 bo'lsa - butunlay (qo'lda ochilguncha) */
    static void blockFor(Context c, String pkg, long ms) {
        try {
            JSONObject o = tb(c);
            long now = System.currentTimeMillis();
            long u = ms <= 0 ? Long.MAX_VALUE : now + ms;
            if (o.optLong(pkg, 0) > u && o.optLong(pkg, 0) > now) return;
            o.put(pkg, u);
            pruneInto(o, now);
            p(c).edit().putString("sx_tb", o.toString()).apply();
        } catch (Exception e) {
        }
    }

    private static void pruneInto(JSONObject o, long now) {
        java.util.ArrayList<String> dead = new java.util.ArrayList<String>();
        java.util.Iterator<String> it = o.keys();
        while (it.hasNext()) {
            String k = it.next();
            if (o.optLong(k, 0) <= now) dead.add(k);
        }
        for (String k : dead) o.remove(k);
    }

    static boolean unblock(Context c, String pkg) {
        try {
            JSONObject o = tb(c);
            if (o.optLong(pkg, 0) != Long.MAX_VALUE) return false;
            o.remove(pkg);
            p(c).edit().putString("sx_tb", o.toString()).apply();
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    static String tbActive(Context c) {
        JSONObject o = tb(c);
        pruneInto(o, System.currentTimeMillis());
        return o.toString();
    }

    /* ---------- jadvallar ---------- */
    static JSONArray sch(Context c) {
        try {
            return new JSONArray(p(c).getString("sx_sch", "[]"));
        } catch (Exception e) {
            return new JSONArray();
        }
    }

    private static boolean inWindow(JSONObject s, Calendar cal) {
        int st = s.optInt("s", 0), en = s.optInt("e", 0);
        int now = cal.get(Calendar.HOUR_OF_DAY) * 60 + cal.get(Calendar.MINUTE);
        int dow = cal.get(Calendar.DAY_OF_WEEK) - 1; // 0 = yakshanba
        JSONArray d = s.optJSONArray("d");
        boolean[] days = new boolean[7];
        if (d == null || d.length() == 0) java.util.Arrays.fill(days, true);
        else for (int i = 0; i < d.length(); i++) {
            int x = d.optInt(i, -1);
            if (x >= 0 && x < 7) days[x] = true;
        }
        if (st == en) return false;
        if (st < en) return days[dow] && now >= st && now < en;
        // tundan oshadigan oraliq: 22:00-06:00
        if (now >= st) return days[dow];
        if (now < en) return days[(dow + 6) % 7];
        return false;
    }

    private static long untilEnd(JSONObject s, Calendar cal) {
        int en = s.optInt("e", 0);
        int now = cal.get(Calendar.HOUR_OF_DAY) * 60 + cal.get(Calendar.MINUTE);
        int diff = en - now;
        if (diff <= 0) diff += 24 * 60;
        return System.currentTimeMillis() + diff * 60000L;
    }

    static boolean covers(JSONObject s, String pkg) {
        JSONArray pk = s.optJSONArray("p");
        if (pk == null) return false;
        boolean all = false, in = false;
        for (int i = 0; i < pk.length(); i++) {
            String x = pk.optString(i);
            if ("*".equals(x)) all = true;
            else if (x.equals(pkg)) in = true;
        }
        if (in) return true;
        if (!all) return false;
        JSONArray ex = s.optJSONArray("x");
        if (ex != null) for (int i = 0; i < ex.length(); i++) if (pkg.equals(ex.optString(i))) return false;
        return true;
    }

    static boolean schedActiveNow(JSONObject s) {
        return inWindow(s, Calendar.getInstance());
    }

    /** Ilova hozir qaysi paytgacha bloklangan (0 - bloklanmagan) */
    static long blockedUntil(Context c, String pkg, long now) {
        long r = Lim.until(c, pkg, now);
        try {
            long t = tb(c).optLong(pkg, 0);
            if (t > now) r = t;
            JSONArray a = sch(c);
            if (a.length() > 0) {
                Calendar cal = Calendar.getInstance();
                for (int i = 0; i < a.length(); i++) {
                    JSONObject s = a.optJSONObject(i);
                    if (s != null && covers(s, pkg) && inWindow(s, cal)) r = Math.max(r, untilEnd(s, cal));
                }
            }
        } catch (Exception e) {
        }
        return r;
    }

    private static String canon(JSONObject s) {
        StringBuilder b = new StringBuilder();
        b.append(s.optString("id")).append('|').append(s.optInt("s")).append('|').append(s.optInt("e")).append('|');
        java.util.TreeSet<String> d = new java.util.TreeSet<String>(), pk = new java.util.TreeSet<String>(), x = new java.util.TreeSet<String>();
        JSONArray a = s.optJSONArray("d");
        if (a != null) for (int i = 0; i < a.length(); i++) d.add(String.valueOf(a.optInt(i)));
        a = s.optJSONArray("p");
        if (a != null) for (int i = 0; i < a.length(); i++) pk.add(a.optString(i));
        a = s.optJSONArray("x");
        if (a != null) for (int i = 0; i < a.length(); i++) x.add(a.optString(i));
        return b.append(d).append(pk).append(x).toString();
    }

    /** Qattiq rejim: hozir faol jadvalni o'chirib yoki o'zgartirib bo'lmaydi. */
    static String schedSave(Context c, String json) {
        try {
            JSONArray nw = new JSONArray(json);
            JSONArray old = sch(c);
            Calendar cal = Calendar.getInstance();
            for (int i = 0; i < old.length(); i++) {
                JSONObject o = old.optJSONObject(i);
                if (o == null || !inWindow(o, cal)) continue;
                boolean same = false;
                for (int j = 0; j < nw.length(); j++) {
                    JSONObject n = nw.optJSONObject(j);
                    if (n != null && canon(n).equals(canon(o))) same = true;
                }
                if (!same) return "locked";
            }
            p(c).edit().putString("sx_sch", nw.toString()).apply();
            return "ok";
        } catch (Exception e) {
            return "err";
        }
    }

    /* ---------- oq-qora rejim ---------- */
    static boolean monoOk(Context c) {
        return c.checkCallingOrSelfPermission("android.permission.WRITE_SECURE_SETTINGS") == android.content.pm.PackageManager.PERMISSION_GRANTED;
    }

    private static boolean grayOn = false;

    static void gray(Context c, boolean on) {
        if (on == grayOn) return;
        try {
            android.content.ContentResolver cr = c.getContentResolver();
            if (on) {
                Settings.Secure.putInt(cr, "accessibility_display_daltonizer", 0);
                Settings.Secure.putInt(cr, "accessibility_display_daltonizer_enabled", 1);
            } else {
                Settings.Secure.putInt(cr, "accessibility_display_daltonizer_enabled", 0);
            }
            grayOn = on;
        } catch (Throwable e) {
        }
    }
}
