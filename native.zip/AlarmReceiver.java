package uz.sanalar.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.PowerManager;

public class AlarmReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent i) {
        // xizmat ishga tushguncha telefon uxlab qolmasligi uchun qisqa wake lock
        try {
            PowerManager pm = (PowerManager) c.getSystemService(Context.POWER_SERVICE);
            pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "tracker:alarmrx").acquire(20000L);
        } catch (Exception e) {
        }
        String id = i.getStringExtra("id");
        String t = i.getStringExtra("t"), l = i.getStringExtra("l");
        boolean ok = AlarmService.ring(c, id, t, l, i.getIntExtra("u", 0), false);
        if (!ok) Store.missed(c, id, t == null ? "" : t, l, System.currentTimeMillis());
        Store.onFired(c, id);
    }
}
