package uz.sanalar.app;

import android.app.AlarmManager;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.HashSet;
import java.util.Set;

/** Focus "Strict mode": faol sessiya holati, rejimlar va bildirishnomalarni vaqtincha o'chirish. */
final class Focus {
    static boolean active(Context c) {
        SharedPreferences p = Store.p(c);
        return p.getBoolean("fx_on", false) && System.currentTimeMillis() < p.getLong("fx_until", 0);
    }

    static boolean mode(Context c, String k) {
        try {
            return new JSONObject(Store.p(c).getString("fx_modes", "{}")).optInt(k, 0) == 1;
        } catch (Exception e) {
            return false;
        }
    }

    static Set<String> pkgs(Context c) {
        Set<String> s = new HashSet<String>();
        try {
            JSONArray a = new JSONArray(Store.p(c).getString("fx_pkgs", "[]"));
            for (int i = 0; i < a.length(); i++) s.add(a.getString(i));
        } catch (Exception e) {
        }
        return s;
    }

    static boolean dndOk(Context c) {
        try {
            if (Build.VERSION.SDK_INT < 23) return false;
            return ((NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE)).isNotificationPolicyAccessGranted();
        } catch (Exception e) {
            return false;
        }
    }

    static PendingIntent endPi(Context c) {
        return PendingIntent.getBroadcast(c, 7731, new Intent(c, FocusEndReceiver.class), Store.flags());
    }

    static void set(Context c, boolean on, String modes, String pkgs, long until) {
        SharedPreferences sp = Store.p(c);
        sp.edit().putBoolean("fx_on", on).putString("fx_modes", modes == null ? "{}" : modes)
                .putString("fx_pkgs", pkgs == null ? "[]" : pkgs).putLong("fx_until", until).apply();
        AlarmManager am = Store.am(c);
        try {
            am.cancel(endPi(c));
            if (on) {
                if (Build.VERSION.SDK_INT >= 23) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, until + 1500, endPi(c));
                else am.set(AlarmManager.RTC_WAKEUP, until + 1500, endPi(c));
            }
        } catch (Exception e) {
        }
        dnd(c, false); // DND endi yoqilmaydi (faqat eski versiyada saqlangan holat tiklanadi)
    }

    static void clear(Context c) {
        Store.p(c).edit().putBoolean("fx_on", false).apply();
        dnd(c, false);
    }

    /** Bildirishnomalarni jim qiladi (ruxsat berilgan bo'lsa), tugagach avvalgi holatni tiklaydi. */
    private static void dnd(Context c, boolean on) {
        try {
            if (Build.VERSION.SDK_INT < 23 || !dndOk(c)) return;
            NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
            SharedPreferences sp = Store.p(c);
            if (on) {
                if (!sp.contains("fx_dnd_prev")) sp.edit().putInt("fx_dnd_prev", nm.getCurrentInterruptionFilter()).apply();
                nm.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_NONE);
            } else if (sp.contains("fx_dnd_prev")) {
                int prev = sp.getInt("fx_dnd_prev", NotificationManager.INTERRUPTION_FILTER_ALL);
                if (prev == NotificationManager.INTERRUPTION_FILTER_UNKNOWN) prev = NotificationManager.INTERRUPTION_FILTER_ALL;
                nm.setInterruptionFilter(prev);
                sp.edit().remove("fx_dnd_prev").apply();
            }
        } catch (Exception e) {
        }
    }
}
