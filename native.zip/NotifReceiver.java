package uz.sanalar.app;

import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/**
 * Uch vazifa: (1) rejalashtirilgan bildirishnomani ko'rsatish, (2) "10 daqiqadan keyin" tugmasi,
 * (3) har 20 daqiqada "yurak urishi" – kechikkan yoki tizim o'chirib yuborgan signallarni tiklaydi.
 */
public class NotifReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent i) {
        if (i == null) return;
        try {
            if (i.getBooleanExtra("live", false)) return; // jonli bildirishnoma finally ichida yangilanadi
            if (i.getBooleanExtra("hb", false)) {
                Store.fireDue(c);
                return;
            }
            if ("snooze".equals(i.getStringExtra("act"))) {
                snooze(c, i);
                return;
            }
            String sid = i.getStringExtra("sid");
            long ts = i.getLongExtra("ts", System.currentTimeMillis());
            String ch = i.getStringExtra("ch");
            // ruxsat/kanal o'chiq bo'lsa "ko'rsatildi" deb belgilanmaydi – ruxsat berilgach 45 daqiqagacha chiqadi
            if (Notif.canShow(c, ch) && (sid == null || sid.length() == 0 || Store.claim(c, sid, ts))) {
                Notif.show(c, i.getIntExtra("id", 1), ch, i.getStringExtra("title"), i.getStringExtra("body"), ts);
            }
            // yaqin (yoki kechikkan) boshqa bildirishnomalar ham shu paytda chiqib ketadi
            Store.fireDue(c);
        } catch (Throwable t) {
        } finally {
            try {
                // ilova ochilmasa ham keyingilari saqlangan ro'yxatdan oldinga qo'yilib turadi
                Store.scheduleNotifs(c, false, false);
            } catch (Throwable t) {
            }
        }
    }

    private void snooze(Context c, Intent i) {
        int id = i.getIntExtra("id", 1);
        try {
            ((NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE)).cancel(id);
        } catch (Throwable t) {
        }
        long when = System.currentTimeMillis() + Notif.SNOOZE_MS;
        Intent in = new Intent(c, NotifReceiver.class);
        in.putExtra("id", id).putExtra("ch", i.getStringExtra("ch")).putExtra("title", i.getStringExtra("title"))
                .putExtra("body", i.getStringExtra("body")).putExtra("ts", when);
        PendingIntent pi = PendingIntent.getBroadcast(c, ("z" + id).hashCode(), in, Store.flags());
        android.app.AlarmManager am = Store.am(c);
        Store.setExact(am, when, pi, Store.canExact(am));
    }
}
