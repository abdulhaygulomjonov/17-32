package uz.sanalar.app;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.util.Calendar;
import java.util.HashSet;
import java.util.Set;

final class Store {
    static final String NXT = "alarm_next";
    static final long MISS_MS = 20 * 60 * 1000L; // telefon o'chiq paytda o'tib ketgan budilnik shu vaqtgacha yoqilganda chaladi
    static final String AL = "alarms", NEED = "need", LVL = "lvl", MODE = "mode", QS = "qs";
    static final String FIRED = "fired", ACODES = "alarm_codes", NOT = "notifs", NCODES = "notif_codes", WID = "widget";

    private static volatile boolean moved = false;

    /**
     * Budilnik ma'lumotlari "device protected" xotirada saqlanadi: telefon qayta yoqilgandan keyin
     * ekran birinchi marta ochilmasdan turib ham o'qiladi (shunda budilnik shu holatda ham chaladi).
     */
    static Context dctx(Context c) {
        Context a = c.getApplicationContext() != null ? c.getApplicationContext() : c;
        if (Build.VERSION.SDK_INT >= 24) {
            try {
                Context d = a.createDeviceProtectedStorageContext();
                if (!moved) {
                    boolean unlocked = true;
                    try {
                        unlocked = ((android.os.UserManager) a.getSystemService(Context.USER_SERVICE)).isUserUnlocked();
                    } catch (Exception e) {
                    }
                    if (unlocked) {
                        try {
                            d.moveSharedPreferencesFrom(a, "tracker_native");
                        } catch (Exception e) {
                        }
                        moved = true;
                    }
                }
                return d;
            } catch (Exception e) {
            }
        }
        return a;
    }

    static SharedPreferences p(Context c) {
        return dctx(c).getSharedPreferences("tracker_native", Context.MODE_PRIVATE);
    }

    static int flags() {
        int f = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= 23) f |= PendingIntent.FLAG_IMMUTABLE;
        return f;
    }

    static AlarmManager am(Context c) {
        return (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
    }

    /* ---------------- budilniklar ---------------- */
    static void saveAlarms(Context c, String json, int need, int lvl) {
        p(c).edit().putString(AL, json).putInt(NEED, need).putInt(LVL, lvl).apply();
        scheduleAlarms(c);
    }

    static long nextTime(String t, String rep, JSONArray days) {
        try {
            String[] a = t.split(":");
            int h = Integer.parseInt(a[0]), m = Integer.parseInt(a[1]);
            for (int k = 0; k < 9; k++) {
                Calendar x = Calendar.getInstance();
                x.add(Calendar.DAY_OF_YEAR, k);
                x.set(Calendar.HOUR_OF_DAY, h);
                x.set(Calendar.MINUTE, m);
                x.set(Calendar.SECOND, 0);
                x.set(Calendar.MILLISECOND, 0);
                if (x.getTimeInMillis() <= System.currentTimeMillis()) continue;
                int w = x.get(Calendar.DAY_OF_WEEK); // 1 = yakshanba ... 7 = shanba
                if (days != null && days.length() > 0) {
                    boolean okDay = false;
                    for (int j = 0; j < days.length(); j++) {
                        if (days.optInt(j, -1) + 1 == w) okDay = true; // sayt: 0 = yakshanba
                    }
                    if (!okDay) continue;
                } else if ("weekdays".equals(rep)) {
                    if (w == Calendar.SATURDAY || w == Calendar.SUNDAY) continue;
                }
                return x.getTimeInMillis();
            }
        } catch (Exception e) {
        }
        return 0;
    }

    static void scheduleAlarms(Context c) {
        try {
            AlarmManager am = am(c);
            SharedPreferences sp = p(c);
            Set<String> old = sp.getStringSet(ACODES, new HashSet<String>());
            for (String s : old) {
                PendingIntent pi = PendingIntent.getBroadcast(c, Integer.parseInt(s), new Intent(c, AlarmReceiver.class), flags());
                am.cancel(pi);
            }
            Set<String> now = new HashSet<String>();
            JSONObject nx = new JSONObject();
            JSONArray arr = new JSONArray(sp.getString(AL, "[]"));
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.getJSONObject(i);
                if (!o.optBoolean("on", false)) continue;
                String id = o.optString("id"), t = o.optString("t"), rep = o.optString("rep", "daily");
                long ts = nextTime(t, rep, o.optJSONArray("days"));
                if (ts == 0) continue;
                int code = ("a" + id).hashCode();
                Intent in = new Intent(c, AlarmReceiver.class);
                in.putExtra("id", id);
                in.putExtra("t", t);
                in.putExtra("l", o.optString("l", ""));
                PendingIntent pi = PendingIntent.getBroadcast(c, code, in, flags());
                PendingIntent show = PendingIntent.getActivity(c, 1, new Intent(c, MainActivity.class), flags());
                am.setAlarmClock(new AlarmManager.AlarmClockInfo(ts, show), pi);
                now.add(String.valueOf(code));
                nx.put(id, ts);
            }
            sp.edit().putStringSet(ACODES, now).putString(NXT, nx.toString()).apply();
        } catch (Exception e) {
        }
    }

    /**
     * Telefon o'chiq (yoki qayta yuklanayotgan) paytda vaqti o'tib ketgan budilniklarni (20 daqiqagacha)
     * telefon yoqilishi bilan darhol chaladi. Rejalashtirishdan OLDIN chaqirilishi kerak.
     */
    static synchronized void catchUpAlarms(Context c) {
        try {
            SharedPreferences sp = p(c);
            JSONObject nx = new JSONObject(sp.getString(NXT, "{}"));
            JSONArray arr = new JSONArray(sp.getString(AL, "[]"));
            long cur = System.currentTimeMillis();
            java.util.ArrayList<String> ids = new java.util.ArrayList<String>();
            boolean rang = false;
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.getJSONObject(i);
                if (!o.optBoolean("on", false)) continue;
                String id = o.optString("id");
                long ts = nx.optLong(id, 0);
                if (ts <= 0 || ts > cur || cur - ts > MISS_MS) continue;
                ids.add(id);
                if (!rang) {
                    rang = AlarmService.ring(c, id, o.optString("t"), o.optString("l", ""), 0, false);
                    if (!rang) missed(c, id, o.optString("t"), o.optString("l", ""), ts);
                }
            }
            for (String id : ids) onFired(c, id);
        } catch (Exception e) {
        }
    }

    /** Budilnikni chalib bo'lmasa (tizim cheklovi) – kamida ko'zga tashlanadigan bildirishnoma chiqaradi. */
    static void missed(Context c, String id, String t, String l, long when) {
        try {
            Notif.show(c, ("m" + id).hashCode(), "dates", "Uyg'otgich " + t,
                    (l != null && l.length() > 0 ? l + " · " : "") + "Uyg'otgich vaqti o'tib ketdi", when);
        } catch (Exception e) {
        }
    }

    static void onFired(Context c, String id) {
        try {
            SharedPreferences sp = p(c);
            JSONArray arr = new JSONArray(sp.getString(AL, "[]"));
            JSONArray fired = new JSONArray(sp.getString(FIRED, "[]"));
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.getJSONObject(i);
                if (id != null && id.equals(o.optString("id")) && "once".equals(o.optString("rep"))) {
                    o.put("on", false);
                    fired.put(id);
                }
            }
            sp.edit().putString(AL, arr.toString()).putString(FIRED, fired.toString()).apply();
        } catch (Exception e) {
        }
        scheduleAlarms(c);
    }

    static String popFired(Context c) {
        SharedPreferences sp = p(c);
        String s = sp.getString(FIRED, "[]");
        sp.edit().putString(FIRED, "[]").apply();
        return s;
    }

    /* ---------------- bildirishnomalar ---------------- */
    static final String SHOWN = "notif_shown";
    static final int WINDOW = 200;                  // bir vaqtda rejalashtiriladigan eng ko'p signal (tizim limiti 500)
    static final long CATCHUP_MS = 45 * 60 * 1000L; // kechikkan/o'tkazib yuborilganlarni shu vaqtgacha ko'rsatadi
    static final long HB_MS = 20 * 60 * 1000L;      // "yurak urishi": signal kechiksa yoki o'chib qolsa tiklaydi
    static final int HB_CODE = 7771;

    static boolean canExact(AlarmManager am) {
        if (Build.VERSION.SDK_INT >= 31) {
            try {
                return am.canScheduleExactAlarms();
            } catch (Exception e) {
                return false;
            }
        }
        return true;
    }

    /** Signal qo'yadi (uyqu rejimida ham). Aniq ruxsat bo'lmasa yoki rad etilsa – noaniq usulga o'tadi. false = limit/xato. */
    static boolean setExact(AlarmManager am, long ts, PendingIntent pi, boolean exact) {
        try {
            if (Build.VERSION.SDK_INT >= 23) {
                if (exact) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, ts, pi);
                else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, ts, pi);
            } else {
                am.setExact(AlarmManager.RTC_WAKEUP, ts, pi);
            }
            return true;
        } catch (SecurityException se) {
            try {
                if (Build.VERSION.SDK_INT >= 23) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, ts, pi);
                else am.set(AlarmManager.RTC_WAKEUP, ts, pi);
                return true;
            } catch (Exception e2) {
                return false;
            }
        } catch (Exception e) {
            return false; // masalan: 500 ta signal limiti
        }
    }

    static void saveNotifs(Context c, String json) {
        fireDue(c); // eski ro'yxatdagi vaqti kelib bo'lgan (lekin hali chiqmagan) bildirishnomalar yo'qolmasin
        p(c).edit().putString(NOT, json).apply();
        scheduleNotifs(c);
    }

    /** To'liq qayta rejalashtirish: eskilarini bekor qiladi, eng yaqin WINDOW tasini qo'yadi. */
    static void scheduleNotifs(Context c) {
        scheduleNotifs(c, true, true);
    }

    /**
     * full=true  : eski signallarni bekor qilib, ro'yxatdan qaytadan qo'yadi (ilova ochilganda, boot, vaqt o'zgarganda).
     * full=false : hech narsani bekor qilmaydi, faqat qayta/oldinga qo'yadi (bildirishnoma chiqqanda, yurak urishida).
     * catchUp    : vaqti o'tib ketgan (so'nggi 45 daqiqa) va hali ko'rsatilmaganlarini hozir ko'rsatadi.
     */
    static synchronized void scheduleNotifs(Context c, boolean full, boolean catchUp) {
        if (catchUp) fireDue(c);
        Set<String> now = new HashSet<String>();
        try {
            AlarmManager am = am(c);
            SharedPreferences sp = p(c);
            long cur = System.currentTimeMillis();

            Set<String> old = sp.getStringSet(NCODES, new HashSet<String>());
            if (full) {
                for (String s : old) {
                    try {
                        int code = Integer.parseInt(s.split("\\|")[0]);
                        am.cancel(PendingIntent.getBroadcast(c, code, new Intent(c, NotifReceiver.class), flags()));
                    } catch (Exception e) {
                    }
                }
            } else {
                for (String s : old) {
                    try {
                        if (Long.parseLong(s.split("\\|")[1]) > cur) now.add(s);
                    } catch (Exception e) {
                    }
                }
            }

            JSONArray arr = new JSONArray(sp.getString(NOT, "[]"));
            boolean exact = canExact(am);
            HashSet<Integer> used = new HashSet<Integer>();
            int n = 0;
            for (int i = 0; i < arr.length() && n < WINDOW; i++) {
                try {
                    JSONObject o = arr.getJSONObject(i);
                    long ts = o.optLong("ts", 0);
                    if (ts <= cur) continue;
                    String id = o.optString("id");
                    int code = ("n" + id).hashCode();
                    while (!used.add(code)) code++; // bir xil kod to'qnashuvi bo'lsa ikkinchisi yo'qolmasin
                    Intent in = new Intent(c, NotifReceiver.class);
                    in.putExtra("id", code);
                    in.putExtra("sid", id);
                    in.putExtra("ts", ts);
                    in.putExtra("ch", o.optString("ch", "dates"));
                    in.putExtra("title", o.optString("title", ""));
                    in.putExtra("body", o.optString("body", ""));
                    PendingIntent pi = PendingIntent.getBroadcast(c, code, in, flags());
                    if (!setExact(am, ts, pi, exact)) break; // limit – keyingisi chiqqanda yana urinadi
                    now.add(code + "|" + ts);
                    n++;
                } catch (Exception e) {
                }
            }

            // yurak urishi: kamida har 20 daqiqada tekshiradi (kechikkan yoki tizim bekor qilgan signallarni tiklaydi)
            Intent h = new Intent(c, NotifReceiver.class);
            h.putExtra("hb", true);
            PendingIntent hp = PendingIntent.getBroadcast(c, HB_CODE, h, flags());
            if (n > 0 || Live.on(c)) setExact(am, cur + HB_MS, hp, false);
            else am.cancel(hp);
        } catch (Exception e) {
        }
        try {
            p(c).edit().putStringSet(NCODES, now).apply();
        } catch (Exception e) {
        }
        try {
            Live.refresh(c); // jonli bildirishnoma (namoz vaqtlari) har safar tekshiriladi
        } catch (Throwable t) {
        }
    }

    /**
     * Vaqti kelib bo'lgan (45 daqiqagacha), hali ko'rsatilmagan bildirishnomalarni ko'rsatadi.
     * Bir-biriga yaqin bildirishnomalar, Doze kechiktirishi va telefon qayta yoqilishi shu yo'l bilan hal bo'ladi.
     */
    static synchronized void fireDue(Context c) {
        try {
            SharedPreferences sp = p(c);
            JSONArray arr = new JSONArray(sp.getString(NOT, "[]"));
            long cur = System.currentTimeMillis();
            for (int i = 0; i < arr.length(); i++) {
                try {
                    JSONObject o = arr.getJSONObject(i);
                    long ts = o.optLong("ts", 0);
                    if (ts <= 0 || ts > cur || cur - ts > CATCHUP_MS) continue;
                    String id = o.optString("id");
                    String ch = o.optString("ch", "dates");
                    if (!Notif.canShow(c, ch)) continue;
                    if (!claim(c, id, ts)) continue;
                    Notif.show(c, ("n" + id).hashCode(), ch, o.optString("title", ""), o.optString("body", ""), ts);
                } catch (Exception e) {
                }
            }
        } catch (Throwable t) {
        }
    }

    /** "Ko'rsatildi" deb belgilaydi. true = birinchi marta (ko'rsatish kerak), false = allaqachon ko'rsatilgan. Kalit: id|vaqt. */
    static synchronized boolean claim(Context c, String id, long ts) {
        try {
            if (id == null || id.length() == 0) return true;
            String key = id + "|" + ts;
            SharedPreferences sp = p(c);
            JSONArray a = new JSONArray(sp.getString(SHOWN, "[]"));
            long lim = System.currentTimeMillis() - 7L * 24 * 3600 * 1000;
            java.util.ArrayList<String> keep = new java.util.ArrayList<String>();
            for (int i = 0; i < a.length(); i++) {
                String s = a.getString(i);
                if (s.equals(key)) return false;
                int k = s.lastIndexOf('|');
                long t = 0;
                try {
                    t = k >= 0 ? Long.parseLong(s.substring(k + 1)) : 0;
                } catch (Exception e) {
                }
                if (t > 0 && t < lim) continue; // 7 kundan eski yozuvlar o'chiriladi
                keep.add(s);
            }
            keep.add(key);
            JSONArray b = new JSONArray();
            for (int i = Math.max(0, keep.size() - 1500); i < keep.size(); i++) b.put(keep.get(i));
            sp.edit().putString(SHOWN, b.toString()).apply();
        } catch (Exception e) {
        }
        return true;
    }

    /* ---------------- vidjet ---------------- */
    static void saveWidget(Context c, String json) {
        p(c).edit().putString(WID, json).apply();
        TrackerWidget.updateAll(c);
    }

    /* ---------------- budilnik ovozi ---------------- */
    static final String SND = "snd_cfg", SNDN = "snd_name";

    static void saveSnd(Context c, String json) {
        p(c).edit().putString(SND, json == null ? "{}" : json).apply();
    }

    static int sndInt(Context c, String k, int d) {
        try {
            return new JSONObject(p(c).getString(SND, "{}")).optInt(k, d);
        } catch (Exception e) {
            return d;
        }
    }

    static File sndFile(Context c) {
        return new File(c.getFilesDir(), "alarm_sound");
    }

    /** Foydalanuvchi tanlagan musiqa (bo'lmasa tizimning standart budilnik ovozi). */
    static void setSource(Context c, MediaPlayer mp) throws Exception {
        File f = sndFile(c);
        if (f.exists() && f.length() > 0) {
            try {
                mp.setDataSource(f.getAbsolutePath());
                return;
            } catch (Exception e) {
                mp.reset();
            }
        }
        Uri u = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);
        if (u == null) u = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE);
        mp.setDataSource(c, u);
    }

    static AudioAttributes alarmAttrs() {
        return new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ALARM)
                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build();
    }

    /** 0..1 chiziqli qiymatni quloqqa tabiiy eshitiladigan kuchaytirishga aylantiradi. */
    static float gain(float v) {
        return (float) Math.pow(Math.max(0f, Math.min(1f, v)), 1.5);
    }
}
