package uz.sanalar.app;

import android.app.Activity;
import android.app.PendingIntent;
import android.content.Intent;

import com.google.android.gms.auth.api.identity.AuthorizationRequest;
import com.google.android.gms.auth.api.identity.AuthorizationResult;
import com.google.android.gms.auth.api.identity.Identity;
import com.google.android.gms.common.api.Scope;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;

import java.util.ArrayList;
import java.util.List;

/**
 * Google bilan kirish (Android'ning o'z Google Authorization oynasi orqali).
 * Natija JS ga window.__gTok(ok, token, expiresSec, xato) ko'rinishida qaytadi.
 * Token faqat Drive "appDataFolder" va email uchun: ilovaning yashirin zaxira joyi.
 */
final class GAuth {
    static final int REQ = 9101;
    private static boolean interactive = false;

    static void authorize(final Activity a, boolean inter) {
        interactive = inter;
        try {
            List<Scope> sc = new ArrayList<>();
            sc.add(new Scope("https://www.googleapis.com/auth/drive.appdata"));
            sc.add(new Scope("https://www.googleapis.com/auth/userinfo.email"));
            AuthorizationRequest req = AuthorizationRequest.builder().setRequestedScopes(sc).build();
            Identity.getAuthorizationClient(a).authorize(req)
                    .addOnSuccessListener(new OnSuccessListener<AuthorizationResult>() {
                        @Override
                        public void onSuccess(AuthorizationResult r) {
                            try {
                                if (r.hasResolution()) {
                                    if (!interactive) {
                                        done(a, false, "", "NEEDUI");
                                        return;
                                    }
                                    PendingIntent pi = r.getPendingIntent();
                                    a.startIntentSenderForResult(pi.getIntentSender(), REQ, null, 0, 0, 0);
                                } else {
                                    String t = r.getAccessToken();
                                    if (t == null || t.length() == 0) done(a, false, "", "Google token bermadi");
                                    else done(a, true, t, "");
                                }
                            } catch (Throwable t) {
                                done(a, false, "", "Google oynasini ochib bo‘lmadi");
                            }
                        }
                    })
                    .addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(Exception e) {
                            String m = e == null ? "" : String.valueOf(e.getMessage());
                            done(a, false, "", "Google xatosi: " + m);
                        }
                    });
        } catch (Throwable t) {
            done(a, false, "", "Google xizmati topilmadi (Play Services kerak)");
        }
    }

    static void onResult(Activity a, int resultCode, Intent data) {
        try {
            if (resultCode != Activity.RESULT_OK || data == null) {
                done(a, false, "", "Kirish bekor qilindi");
                return;
            }
            AuthorizationResult r = Identity.getAuthorizationClient(a).getAuthorizationResultFromIntent(data);
            String t = r.getAccessToken();
            if (t == null || t.length() == 0) done(a, false, "", "Google token bermadi");
            else done(a, true, t, "");
        } catch (Throwable t) {
            done(a, false, "", "Google xatosi: " + t.getMessage());
        }
    }

    private static String q(String s) {
        return "'" + s.replace("\\", "\\\\").replace("'", "\\'").replace("\n", " ") + "'";
    }

    private static void done(final Activity a, boolean ok, String token, String err) {
        final String js = "try{window.__gTok&&window.__gTok(" + (ok ? "true" : "false") + "," + q(token) + ",3000," + q(err) + ")}catch(e){}";
        a.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                try {
                    ((MainActivity) a).getBridge().getWebView().evaluateJavascript(js, null);
                } catch (Throwable t) {
                }
            }
        });
    }
}
