package uz.sanalar.app;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.provider.MediaStore;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Ma'lumotlar ombori: WebView localStorage'idan mustaqil, atomik yoziladigan fayl + aylanma zaxiralar.
 * Papka: filesDir/vault  (Android Auto Backup orqali Google akkauntga ham avtomatik zaxiralanadi).
 */
final class Vault {
    private static final Object LOCK = new Object();
    private static final ExecutorService EX = Executors.newSingleThreadExecutor();
    private static final String MAIN = "main.json", PREV = "main.prev";
    private static final long AUTO_EVERY = 30L * 60 * 1000;      // oddiy zaxira: 30 daqiqada bir
    private static final long PUBLIC_EVERY = 30L * 60 * 1000;    // ochiq nusxa (Documents/Madeena)

    static File dir(Context c) {
        File d = new File(c.getFilesDir(), "vault");
        if (!d.exists()) d.mkdirs();
        return d;
    }

    private static byte[] readAll(File f) {
        try (InputStream in = new FileInputStream(f)) {
            ByteArrayOutputStream o = new ByteArrayOutputStream((int) Math.max(1024, f.length()));
            byte[] b = new byte[16384];
            int n;
            while ((n = in.read(b)) > 0) o.write(b, 0, n);
            return o.toByteArray();
        } catch (Throwable t) {
            return null;
        }
    }

    private static boolean writeAtomic(File f, byte[] data) {
        File tmp = new File(f.getPath() + ".tmp");
        try (FileOutputStream o = new FileOutputStream(tmp)) {
            o.write(data);
            o.flush();
            o.getFD().sync();
        } catch (Throwable t) {
            try { tmp.delete(); } catch (Throwable z) { }
            return false;
        }
        return tmp.renameTo(f);
    }

    private static boolean valid(byte[] b) {
        if (b == null || b.length < 2) return false;
        try {
            JSONObject o = new JSONObject(new String(b, "UTF-8"));
            return o.optJSONObject("k") != null;
        } catch (Throwable t) {
            return false;
        }
    }

    private static String stamp() {
        return new SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(new Date());
    }

    private static String clean(String s) {
        if (s == null) return "";
        s = s.toLowerCase(Locale.US).replaceAll("[^a-z0-9-]", "");
        return s.length() > 24 ? s.substring(0, 24) : s;
    }

    /** Saqlash. force=true bo'lsa, ayni payt alohida zaxira ham yaratiladi. */
    static String put(Context c, String json, boolean force, String tag) {
        if (json == null || json.length() < 5) return "err:bo'sh";
        final byte[] data;
        try { data = json.getBytes("UTF-8"); } catch (Throwable t) { return "err:kodlash"; }
        if (!valid(data)) return "err:noto'g'ri JSON";
        synchronized (LOCK) {
            File d = dir(c);
            File main = new File(d, MAIN);
            byte[] old = main.exists() ? readAll(main) : null;
            boolean oldOk = valid(old);
            // Oldingi to'g'ri nusxani .prev ga o'tkazamiz
            if (oldOk) writeAtomic(new File(d, PREV), old);
            // Keskin kichrayish bo'lsa, eskisini alohida saqlab qo'yamiz
            if (oldOk && old.length > 20000 && data.length < old.length * 0.5) {
                writeAtomic(new File(d, "bak-" + stamp() + "-kichrayish.json"), old);
            }
            if (!writeAtomic(main, data)) return "err:yozib bo'lmadi";
            boolean due = force;
            if (!due) {
                long newest = 0;
                File[] fs = d.listFiles();
                if (fs != null) for (File f : fs) if (f.getName().startsWith("bak-") && f.lastModified() > newest) newest = f.lastModified();
                due = System.currentTimeMillis() - newest > AUTO_EVERY;
            }
            if (due) {
                String t = clean(tag);
                writeAtomic(new File(d, "bak-" + stamp() + (t.isEmpty() ? "" : "-" + t) + ".json"), data);
                prune(d, data.length);
            }
        }
        final String copy = json;
        final Context app = c.getApplicationContext();
        final boolean f2 = force;
        EX.execute(new Runnable() {
            @Override public void run() { publicCopy(app, copy, f2); }
        });
        return "ok";
    }

    private static void prune(File d, int size) {
        File[] fs = d.listFiles();
        if (fs == null) return;
        ArrayList<String> names = new ArrayList<>();
        for (File f : fs) if (f.getName().startsWith("bak-") && f.getName().endsWith(".json")) names.add(f.getName());
        Collections.sort(names, Collections.reverseOrder());
        int keep = size > 1000000 ? 6 : 24;
        Set<String> days = new HashSet<>();
        long limit = System.currentTimeMillis() - 30L * 24 * 3600 * 1000;
        for (int i = 0; i < names.size(); i++) {
            String n = names.get(i);
            if (i < keep) continue;
            String day = n.length() >= 12 ? n.substring(4, 12) : n;
            File f = new File(d, n);
            // eski nusxalardan har kunga bittasini 30 kun saqlaymiz
            if (!days.contains(day) && f.lastModified() > limit && size < 1000000) { days.add(day); continue; }
            f.delete();
        }
    }

    /** O'qish: asosiy -> .prev -> eng yangi zaxira. */
    static String get(Context c) {
        synchronized (LOCK) {
            File d = dir(c);
            byte[] b = readAll(new File(d, MAIN));
            if (valid(b)) return utf(b);
            b = readAll(new File(d, PREV));
            if (valid(b)) return utf(b);
            File[] fs = d.listFiles();
            if (fs != null) {
                ArrayList<String> names = new ArrayList<>();
                for (File f : fs) if (f.getName().startsWith("bak-")) names.add(f.getName());
                Collections.sort(names, Collections.reverseOrder());
                for (String n : names) {
                    b = readAll(new File(d, n));
                    if (valid(b)) return utf(b);
                }
            }
            return "";
        }
    }

    private static String utf(byte[] b) {
        try { return new String(b, "UTF-8"); } catch (Throwable t) { return ""; }
    }

    static String list(Context c) {
        JSONArray a = new JSONArray();
        try {
            File d = dir(c);
            File[] fs = d.listFiles();
            if (fs == null) return "[]";
            ArrayList<File> l = new ArrayList<>();
            for (File f : fs) {
                String n = f.getName();
                if (n.equals(MAIN) || n.equals(PREV) || (n.startsWith("bak-") && n.endsWith(".json"))) l.add(f);
            }
            Collections.sort(l, new java.util.Comparator<File>() {
                @Override public int compare(File x, File y) { return Long.compare(y.lastModified(), x.lastModified()); }
            });
            for (File f : l) {
                JSONObject o = new JSONObject();
                o.put("n", f.getName());
                o.put("t", f.lastModified());
                o.put("s", f.length());
                a.put(o);
            }
        } catch (Throwable t) { }
        return a.toString();
    }

    static String read(Context c, String name) {
        if (name == null || !name.matches("[A-Za-z0-9._-]+")) return "";
        synchronized (LOCK) {
            File f = new File(dir(c), name);
            if (!f.exists()) return "";
            byte[] b = readAll(f);
            return valid(b) ? utf(b) : "";
        }
    }

    /** Telefon xotirasidagi ochiq nusxa: Documents/Madeena/Madeena-zahira-YYYY-MM-DD.json (ilova o'chsa ham qoladi). */
    private static void publicCopy(Context c, String json, boolean force) {
        if (Build.VERSION.SDK_INT < 29) return;
        try {
            File mark = new File(dir(c), "public.mark");
            long now = System.currentTimeMillis();
            if (!force && mark.exists() && now - mark.lastModified() < PUBLIC_EVERY) return;
            String name = "Madeena-zahira-" + new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date()) + ".json";
            String rel = "Documents/Madeena/";
            ContentResolver cr = c.getContentResolver();
            Uri col = MediaStore.Files.getContentUri("external");
            Uri target = null;
            Cursor q = cr.query(col, new String[]{MediaStore.MediaColumns._ID},
                    MediaStore.MediaColumns.DISPLAY_NAME + "=? AND " + MediaStore.MediaColumns.RELATIVE_PATH + "=?",
                    new String[]{name, rel}, null);
            if (q != null) {
                try { if (q.moveToFirst()) target = android.content.ContentUris.withAppendedId(col, q.getLong(0)); } finally { q.close(); }
            }
            if (target == null) {
                ContentValues v = new ContentValues();
                v.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
                v.put(MediaStore.MediaColumns.MIME_TYPE, "application/json");
                v.put(MediaStore.MediaColumns.RELATIVE_PATH, rel);
                target = cr.insert(col, v);
            }
            if (target == null) return;
            try (OutputStream o = cr.openOutputStream(target, "wt")) {
                if (o == null) return;
                o.write(json.getBytes("UTF-8"));
                o.flush();
            }
            writeAtomic(mark, new byte[]{49});
            // faqat oxirgi 7 kunlik ochiq nusxa qoladi
            Cursor p = cr.query(col, new String[]{MediaStore.MediaColumns._ID, MediaStore.MediaColumns.DISPLAY_NAME},
                    MediaStore.MediaColumns.DISPLAY_NAME + " LIKE ? AND " + MediaStore.MediaColumns.RELATIVE_PATH + "=?",
                    new String[]{"Madeena-zahira-%.json", rel}, null);
            if (p != null) {
                ArrayList<String> ns = new ArrayList<>();
                ArrayList<Long> ids = new ArrayList<>();
                try { while (p.moveToNext()) { ids.add(p.getLong(0)); ns.add(p.getString(1)); } } finally { p.close(); }
                ArrayList<String> sorted = new ArrayList<>(ns);
                Collections.sort(sorted, Collections.reverseOrder());
                for (int i = 7; i < sorted.size(); i++) {
                    int ix = ns.indexOf(sorted.get(i));
                    if (ix >= 0) try { cr.delete(android.content.ContentUris.withAppendedId(col, ids.get(ix)), null, null); } catch (Throwable z) { }
                }
            }
        } catch (Throwable t) {
        }
    }
}
