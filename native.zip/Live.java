package uz.sanalar.app;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.SystemClock;
import android.widget.FrameLayout;
import android.widget.RemoteViews;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Calendar;

/**
 * Jonli bildirishnoma: bugungi namoz vaqtlari bildirishnomalar panelida doimiy turadi.
 * Yopiq: keyingi namoz va unga qolgan vaqt (orqaga sanaladi). Ochilganda: hamma vaqtlar, keyingisi belgilangan.
 * Maxsus ko'rinish ishlamasa, avtomatik oddiy ko'rinishga o'tadi (bildirishnoma baribir chiqadi).
 * Har namoz vaqtida o'zi yangilanadi (ilova ochilmasa ham), telefon qayta yoqilsa ham tiklanadi.
 */
final class Live {
    static final int ID = 7002;
    static final int CODE = 7772;
    static final String CFG = "live_cfg";

    /** Holat matni (JS ga qaytadi): ok | off | noperm | fb:<sabab> | err:<sabab> */
    static String save(Context c, String json) {
        Store.p(c).edit().putString(CFG, json == null ? "{}" : json).apply();
        return refresh(c);
    }

    static boolean on(Context c) {
        try {
            JSONObject o = new JSONObject(Store.p(c).getString(CFG, "{}"));
            JSONArray t = o.optJSONArray("times");
            return o.optInt("on", 0) == 1 && t != null && t.length() > 0;
        } catch (Exception e) {
            return false;
        }
    }

    /** Orqaga sanaydigan taymer: tizim o'zi soniyama-soniya yangilaydi (ilova ishlamasa ham). */
    private static void chr(RemoteViews v, int id, long target) {
        long base = SystemClock.elapsedRealtime() + (target - System.currentTimeMillis());
        v.setChronometer(id, base, null, true);
        if (Build.VERSION.SDK_INT >= 24) v.setChronometerCountDown(id, true);
    }

    private static String shortErr(Throwable e) {
        String s = e.getClass().getSimpleName() + (e.getMessage() == null ? "" : ": " + e.getMessage());
        return s.length() > 90 ? s.substring(0, 90) : s;
    }

    static synchronized String refresh(Context c) {
        try {
            NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
            AlarmManager am = Store.am(c);
            Intent in = new Intent(c, NotifReceiver.class);
            in.putExtra("live", true);
            PendingIntent pi = PendingIntent.getBroadcast(c, CODE, in, Store.flags());
            if (!on(c)) {
                nm.cancel(ID);
                am.cancel(pi);
                return "off";
            }
            JSONArray t = new JSONObject(Store.p(c).getString(CFG, "{}")).optJSONArray("times");
            long cur = System.currentTimeMillis();
            int n = t.length(), nxt = -1;
            long best = Long.MAX_VALUE;
            for (int i = 0; i < n; i++) {
                JSONObject p = t.getJSONObject(i);
                String[] a = p.optString("t").split(":");
                Calendar x = Calendar.getInstance();
                x.set(Calendar.HOUR_OF_DAY, Integer.parseInt(a[0].trim()));
                x.set(Calendar.MINUTE, Integer.parseInt(a[1].trim()));
                x.set(Calendar.SECOND, 0);
                x.set(Calendar.MILLISECOND, 0);
                if (x.getTimeInMillis() <= cur) x.add(Calendar.DAY_OF_YEAR, 1);
                if (x.getTimeInMillis() < best) {
                    best = x.getTimeInMillis();
                    nxt = i;
                }
            }
            if (nxt < 0) return "off";
            // keyingi namoz vaqti kelganda yangilanadi (bildirishnoma chiqmasa ham zanjir uzilmasin)
            Store.setExact(am, best + 1000, pi, Store.canExact(am));
            if (!Notif.canShow(c, "live")) return "noperm";

            JSONObject np = t.getJSONObject(nxt);
            String title = np.optString("n") + " " + np.optString("t");
            Notif.channels(c);
            Notification.Builder b = Notif.builder(c, "live");
            Notif.brand(c, b)
                    .setContentTitle(title)
                    .setContentText("Keyingi namoz")
                    .setContentIntent(PendingIntent.getActivity(c, 2, new Intent(c, MainActivity.class), Store.flags()))
                    .setOngoing(true)
                    .setOnlyAlertOnce(true)
                    .setWhen(best)
                    .setCategory(Notification.CATEGORY_STATUS)
                    .setVisibility(Notification.VISIBILITY_PUBLIC);
            if (Build.VERSION.SDK_INT < 26) b.setPriority(Notification.PRIORITY_LOW);

            String status = "ok";
            boolean custom = false;
            if (Build.VERSION.SDK_INT >= 24) {
                try {
                    String pk = c.getPackageName();
                    RemoteViews sm = new RemoteViews(pk, R.layout.live_small);
                    sm.setTextViewText(R.id.ls_sub, "Keyingi namoz");
                    sm.setTextViewText(R.id.ls_title, title);
                    chr(sm, R.id.ls_chr, best);
                    RemoteViews bg = new RemoteViews(pk, R.layout.live_big);
                    bg.setTextViewText(R.id.lb_sub, "Namoz vaqtlari");
                    chr(bg, R.id.lb_chr, best);
                    int[] col = {R.id.lb_c0, R.id.lb_c1, R.id.lb_c2, R.id.lb_c3, R.id.lb_c4, R.id.lb_c5};
                    int[] nam = {R.id.lb_n0, R.id.lb_n1, R.id.lb_n2, R.id.lb_n3, R.id.lb_n4, R.id.lb_n5};
                    int[] tim = {R.id.lb_t0, R.id.lb_t1, R.id.lb_t2, R.id.lb_t3, R.id.lb_t4, R.id.lb_t5};
                    int[] und = {R.id.lb_u0, R.id.lb_u1, R.id.lb_u2, R.id.lb_u3, R.id.lb_u4, R.id.lb_u5};
                    for (int i = 0; i < 6; i++) {
                        if (i >= n) {
                            bg.setViewVisibility(col[i], android.view.View.INVISIBLE);
                            continue;
                        }
                        JSONObject p = t.getJSONObject(i);
                        bg.setTextViewText(nam[i], p.optString("n"));
                        bg.setTextViewText(tim[i], p.optString("t"));
                        if (i == nxt) {
                            bg.setTextColor(nam[i], Notif.COLOR);
                            bg.setInt(und[i], "setBackgroundColor", Notif.COLOR);
                            bg.setViewVisibility(und[i], android.view.View.VISIBLE);
                        }
                    }
                    // bildirishnomaga berishdan oldin shu yerning o'zida sinab ko'riladi: ochilmasa zaxira ko'rinishga o'tadi
                    sm.apply(c, new FrameLayout(c));
                    bg.apply(c, new FrameLayout(c));
                    b.setStyle(new Notification.DecoratedCustomViewStyle());
                    b.setCustomContentView(sm);
                    b.setCustomBigContentView(bg);
                    b.setShowWhen(false);
                    custom = true;
                } catch (Throwable e) {
                    status = "fb:" + shortErr(e);
                }
            }
            if (!custom) {
                StringBuilder sb = new StringBuilder();
                for (int i = 0; i < n; i++) {
                    JSONObject p = t.getJSONObject(i);
                    if (i > 0) sb.append('\n');
                    sb.append(i == nxt ? "\u203A " : "   ").append(p.optString("n")).append("  ").append(p.optString("t"));
                }
                b.setStyle(new Notification.BigTextStyle().bigText(sb.toString()));
                b.setShowWhen(true);
                b.setUsesChronometer(true);
                if (Build.VERSION.SDK_INT >= 24) b.setChronometerCountDown(true);
            }
            nm.notify(ID, b.build());
            return status;
        } catch (Throwable e) {
            return "err:" + shortErr(e);
        }
    }
}
