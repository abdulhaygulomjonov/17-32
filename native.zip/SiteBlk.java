package uz.sanalar.app;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/**
 * Sayt bloklash (yashirin bo'lim): ro'yxat va holat. Ro'yxatni foydalanuvchi o'zi kiritadi, tayyor ro'yxat yo'q.
 * Ikki qatlam ishlaydi: SiteVpn (DNS filtr, barcha ilovalar) va BlkService (brauzer manzil satri, qo'shimcha himoya).
 */
final class SiteBlk {
    private static String raw = null;
    private static Set<String> cache = new HashSet<String>();

    static SharedPreferences p(Context c) {
        return Store.p(c);
    }

    static boolean on(Context c) {
        // avtomatik yoqilgan: yashirin bo'limdan o'chirilgandagina o'chiq turadi
        return p(c).getBoolean("sb_on", true);
    }

    static void setOn(Context c, boolean v) {
        p(c).edit().putBoolean("sb_on", v).apply();
    }

    /** VPN (DNS filtr) kerakmi; false bo'lsa faqat maxsus imkoniyat (boshqa VPN bilan birga ishlash uchun). */
    static boolean vpn(Context c) {
        // standart: VPN (DNS filtr) ham avtomatik yoqiladi (ruxsat berilgach); faqat maxsus imkoniyat rejimi qo'lda tanlanadi
        return p(c).getBoolean("sb_vpn", true);
    }

    static void setVpn(Context c, boolean v) {
        p(c).edit().putBoolean("sb_vpn", v).apply();
    }

    /** Boshqa VPN ilovalarni (va tizimning VPN so'rov oynasini) bloklash; standart yoniq. */
    static boolean noVpn(Context c) {
        return p(c).getBoolean("sb_novpn", true);
    }

    static void setNoVpn(Context c, boolean v) {
        p(c).edit().putBoolean("sb_novpn", v).apply();
    }

    /** Tizim VPN sozlamalariga kirishga vaqtincha ruxsat (ms vaqt belgisi); faqat yashirin bo'limdagi tugma beradi. */
    static long grace(Context c) {
        return p(c).getLong("sb_grace", 0);
    }

    static void setGrace(Context c, long until) {
        p(c).edit().putLong("sb_grace", until).apply();
    }

    /** "https://www.Example.com/yo'l?x=1" -> "example.com" */
    static String norm(String x) {
        if (x == null) return "";
        String s = x.trim().toLowerCase(Locale.ROOT);
        s = s.replaceFirst("^[a-z][a-z0-9+.-]*://", "");
        int e = s.length();
        for (int i = 0; i < s.length(); i++) {
            char ch = s.charAt(i);
            if (ch == '/' || ch == '?' || ch == '#' || ch == ':' || ch == ' ') {
                e = i;
                break;
            }
        }
        s = s.substring(0, e);
        while (s.startsWith("www.")) s = s.substring(4);
        while (s.startsWith(".")) s = s.substring(1);
        while (s.endsWith(".")) s = s.substring(0, s.length() - 1);
        if (s.length() < 3 || s.length() > 120 || s.indexOf('.') < 0) return "";
        for (int i = 0; i < s.length(); i++) {
            char ch = s.charAt(i);
            boolean ok = (ch >= 'a' && ch <= 'z') || (ch >= '0' && ch <= '9') || ch == '-' || ch == '.' || ch > 127;
            if (!ok) return "";
        }
        return s;
    }

    static synchronized List<String> list(Context c) {
        List<String> out = new ArrayList<String>();
        try {
            JSONArray a = new JSONArray(p(c).getString("sb_domains", "[]"));
            for (int i = 0; i < a.length(); i++) {
                String d = norm(a.optString(i, ""));
                if (d.length() > 0 && !out.contains(d)) out.add(d);
            }
        } catch (Exception e) {
        }
        return out;
    }

    /** Ro'yxatni almashtiradi (JSON massiv). */
    static synchronized String setList(Context c, String json) {
        try {
            JSONArray a = new JSONArray(json);
            JSONArray o = new JSONArray();
            List<String> seen = new ArrayList<String>();
            for (int i = 0; i < a.length() && seen.size() < 2000; i++) {
                String d = norm(a.optString(i, ""));
                if (d.length() > 0 && !seen.contains(d)) {
                    seen.add(d);
                    o.put(d);
                }
            }
            p(c).edit().putString("sb_domains", o.toString()).apply();
            raw = null;
            return "ok";
        } catch (Exception e) {
            return "err";
        }
    }

    /** Tez tekshirish uchun xotiradagi to'plam (DNS har so'rovda chaqiradi). */
    static synchronized Set<String> set(Context c) {
        String s = p(c).getString("sb_domains", "[]");
        if (!s.equals(raw)) {
            Set<String> n = new HashSet<String>();
            try {
                JSONArray a = new JSONArray(s);
                for (int i = 0; i < a.length(); i++) {
                    String d = norm(a.optString(i, ""));
                    if (d.length() > 0) n.add(d);
                }
            } catch (Exception e) {
            }
            cache = n;
            raw = s;
        }
        return cache;
    }

    /** Faqat yoqilgan paytdagi to'plam (accessibility uchun); o'chiq bo'lsa bo'sh. */
    static Set<String> active(Context c) {
        return on(c) ? set(c) : new HashSet<String>();
    }

    /** Host ro'yxatdagi domen yoki uning quyi domeni bo'lsa true. */
    static boolean blocked(Context c, String host) {
        if (host == null) return false;
        String h = host.trim().toLowerCase(Locale.ROOT);
        while (h.endsWith(".")) h = h.substring(0, h.length() - 1);
        if (h.length() == 0) return false;
        for (String d : set(c)) {
            if (h.equals(d) || h.endsWith("." + d)) return true;
        }
        return false;
    }

    /** Brauzer manzil satridagi matn bloklangan domenga tegishlimi (so'z chegarasi bilan: "x.com" "dropbox.com"ni ushlamaydi). */
    static String urlHit(String urlText, Set<String> doms) {
        if (urlText == null || doms == null || doms.isEmpty()) return null;
        String s = urlText.trim().toLowerCase(Locale.ROOT);
        if (s.length() == 0 || s.indexOf(' ') >= 0) return null;
        s = s.replaceFirst("^[a-z][a-z0-9+.-]*://", "");
        int e = s.length();
        for (int i = 0; i < s.length(); i++) {
            char ch = s.charAt(i);
            if (ch == '/' || ch == '?' || ch == '#' || ch == ':' || ch == '\u2026') {
                e = i;
                break;
            }
        }
        String host = s.substring(0, e);
        for (String d : doms) {
            if (host.equals(d) || host.endsWith("." + d)) return d;
        }
        return null;
    }
}
