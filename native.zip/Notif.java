package uz.sanalar.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.Icon;
import android.os.Build;
import android.widget.FrameLayout;
import android.widget.RemoteViews;

final class Notif {
    /** Bildirishnoma rangi: kichik ikonka shu rangda doira ichida ko'rinadi. */
    static final int COLOR = 0xFF1F8A5B;
    static final long SNOOZE_MS = 10 * 60 * 1000L;

    private static void ch(NotificationManager nm, String id, String name, int imp, boolean sound) {
        NotificationChannel c = new NotificationChannel(id, name, imp);
        c.setShowBadge(true);
        c.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
        if (imp >= NotificationManager.IMPORTANCE_DEFAULT) c.enableVibration(true);
        if (!sound) c.setSound(null, null);
        nm.createNotificationChannel(c);
    }

    static void channels(Context c) {
        if (Build.VERSION.SDK_INT < 26) return;
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        ch(nm, "dates", "Sanalar", NotificationManager.IMPORTANCE_HIGH, true);
        ch(nm, "tasks", "Vazifalar", NotificationManager.IMPORTANCE_HIGH, true);
        ch(nm, "virds", "Virdlar", NotificationManager.IMPORTANCE_DEFAULT, true);
        ch(nm, "news", "Yangiliklar", NotificationManager.IMPORTANCE_DEFAULT, true);
        ch(nm, "alarm", "Uyg'otgich", NotificationManager.IMPORTANCE_HIGH, false);
        ch(nm, "memo", "Maxsus bildirishnoma", NotificationManager.IMPORTANCE_HIGH, true);
        ch(nm, "live", "Jonli bildirishnoma", NotificationManager.IMPORTANCE_LOW, false);
    }

    static Notification.Builder builder(Context c, String ch) {
        if (Build.VERSION.SDK_INT >= 26) return new Notification.Builder(c, ch);
        return new Notification.Builder(c);
    }

    /**
     * Hamma bildirishnomaga umumiy ko'rinish: faqat chap tomondagi (yashil kvadrat) kichik ikonka qoladi;
     * o'ng tomonda hech qanday katta ikonka (setLargeIcon) QO'YILMAYDI. Live, Uyg'otgich, oddiy va maxsus – hammasi shu orqali o'tadi.
     */
    static Notification.Builder brand(Context c, Notification.Builder b) {
        b.setSmallIcon(R.drawable.ic_stat);
        return b;
    }

    private static android.graphics.Bitmap iconCache;

    /** Ilovaning haqiqiy (launcher) ikonkasi: oddiy eslatmalarda katta ikonka sifatida ko'rsatiladi. */
    static synchronized android.graphics.Bitmap appIcon(Context c) {
        if (iconCache != null && !iconCache.isRecycled()) return iconCache;
        android.graphics.drawable.Drawable d = c.getPackageManager().getApplicationIcon(c.getApplicationInfo());
        int s = 128;
        android.graphics.Bitmap bm = android.graphics.Bitmap.createBitmap(s, s, android.graphics.Bitmap.Config.ARGB_8888);
        android.graphics.Canvas cv = new android.graphics.Canvas(bm);
        d.setBounds(0, 0, s, s);
        d.draw(cv);
        iconCache = bm;
        return bm;
    }

    /** Bildirishnomalar umuman (yoki shu kanal) o'chirilgan bo'lsa false. */
    static boolean canShow(Context c, String ch) {
        try {
            NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
            if (Build.VERSION.SDK_INT >= 24 && !nm.areNotificationsEnabled()) return false;
            if (Build.VERSION.SDK_INT >= 26 && ch != null && ch.length() > 0) {
                NotificationChannel x = nm.getNotificationChannel(ch);
                if (x != null && x.getImportance() == NotificationManager.IMPORTANCE_NONE) return false;
            }
        } catch (Throwable t) {
        }
        return true;
    }

    static boolean show(Context c, int id, String ch, String title, String body) {
        return show(c, id, ch, title, body, System.currentTimeMillis());
    }

    static boolean show(Context c, int id, String ch, String title, String body, long when) {
        try {
            channels(c);
            if (ch == null || ch.length() == 0) ch = "dates";
            if (title == null) title = "";
            if (body == null) body = "";
            PendingIntent pi = PendingIntent.getActivity(c, 2, new Intent(c, MainActivity.class), Store.flags());
            Notification.Builder b = builder(c, ch);
            brand(c, b)
                    .setContentTitle(title)
                    .setContentText(body)
                    .setStyle(new Notification.BigTextStyle().bigText(body))
                    .setContentIntent(pi)
                    .setWhen(when)
                    .setShowWhen(true)
                    .setAutoCancel(true);
            if (Build.VERSION.SDK_INT >= 21) b.setCategory(Notification.CATEGORY_REMINDER).setVisibility(Notification.VISIBILITY_PUBLIC);
            if (Build.VERSION.SDK_INT < 26) b.setPriority(Notification.PRIORITY_HIGH).setDefaults(Notification.DEFAULT_ALL);
            if (Build.VERSION.SDK_INT >= 24) {
                // matn to'liq ko'rinadi; ilova ikonkasi chap tomonda brand() orqali qo'yilgan
                try {
                    boolean mm = "memo".equals(ch);
                    RemoteViews v = new RemoteViews(c.getPackageName(), mm ? R.layout.memo : R.layout.std);
                    if (mm) {
                        v.setTextViewText(R.id.mm_text, body);
                    } else {
                        v.setTextViewText(R.id.st_title, title);
                        v.setTextViewText(R.id.st_text, body);
                    }
                    v.apply(c, new FrameLayout(c));
                    b.setStyle(new Notification.DecoratedCustomViewStyle());
                    b.setCustomContentView(v);
                    b.setCustomBigContentView(v);
                } catch (Throwable e) {
                }
            }
            // "10 daqiqadan keyin" tugmasi: maxsus bildirishnomada YO'Q (matn o'zi keladi), qolganlarida bor
            if (!"memo".equals(ch)) {
                Intent si = new Intent(c, NotifReceiver.class);
                si.putExtra("act", "snooze").putExtra("id", id).putExtra("ch", ch).putExtra("title", title).putExtra("body", body);
                PendingIntent sp = PendingIntent.getBroadcast(c, id * 31 + 17, si, Store.flags());
                b.addAction(new Notification.Action.Builder(Icon.createWithResource(c, R.drawable.ic_stat), "10 daqiqadan keyin", sp).build());
            }
            NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
            nm.notify(id, b.build());
            return true;
        } catch (Throwable e) {
            return false;
        }
    }
}
